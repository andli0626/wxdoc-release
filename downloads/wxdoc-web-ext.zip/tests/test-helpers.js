// 测试基础设施：轻量级 assert + 浏览器/Chrome API Mock
'use strict';

// ===== Assert =====
var passed = 0, failed = 0;
var failures = [];

function assert(condition, msg) {
  if (condition) { passed++; console.log('  OK ' + msg); }
  else { failed++; failures.push(msg); console.log('  FAIL: ' + msg); }
}
function assertEq(actual, expected, msg) {
  var eq = JSON.stringify(actual) === JSON.stringify(expected);
  if (eq) { passed++; console.log('  OK ' + msg); }
  else {
    failed++; failures.push(msg + ' | expected=' + JSON.stringify(expected) + ' got=' + JSON.stringify(actual));
    console.log('  FAIL: ' + msg + ' expected=' + JSON.stringify(expected) + ' got=' + JSON.stringify(actual));
  }
}
function assertThrows(fn, pat, msg) {
  try { fn(); failed++; failures.push(msg + ' (no throw)'); console.log('  FAIL: ' + msg + ' (no throw)'); }
  catch (e) {
    if (pat && !pat.test(e.message)) { failed++; failures.push(msg + ' (wrong: ' + e.message + ')'); console.log('  FAIL: ' + msg + ' wrong: ' + e.message); }
    else { passed++; console.log('  OK ' + msg + ' (threw: ' + e.message + ')'); }
  }
}
function section(name) { console.log('\n=== ' + name + ' ==='); }
function summary() {
  console.log('\n========================================');
  console.log('Total: ' + (passed + failed) + ' | Pass: ' + passed + ' | Fail: ' + failed);
  if (failures.length) { console.log('Failures:'); failures.forEach(function(f, i) { console.log('  ' + (i + 1) + '. ' + f); }); process.exit(1); }
  console.log('========================================\n');
}

// ===== Chrome Storage Mock =====
function createStorageMock(init) {
  var data = Object.assign({}, init || {});
  return {
    local: {
      get: function(keys, cb) {
        var result = {};
        var dk = Array.isArray(keys) ? null : (typeof keys === 'object' ? keys : {});
        var kl = Array.isArray(keys) ? keys : Object.keys(dk);
        kl.forEach(function(k) { result[k] = k in data ? data[k] : (dk ? dk[k] : undefined); });
        if (cb) cb(result);
        return Promise.resolve(result);
      },
      set: function(items, cb) { Object.assign(data, items); if (cb) cb(); return Promise.resolve(); },
      _data: function() { return data; }
    }
  };
}

// ===== Runtime Mock =====
function createRuntimeMock() {
  var listeners = [];
  return {
    onMessage: { addListener: function(fn) { listeners.push(fn); } },
    _dispatch: function(msg, sender, onResp) {
      var resp = null;
      var sendResponse = function(r) { resp = r; if (onResp) onResp(r); };
      listeners.forEach(function(fn) { fn(msg && msg.type ? msg : msg, sender || {}, sendResponse); });
      return resp;
    }
  };
}

// ===== Tabs Mock =====
function createTabsMock() {
  var sendFns = [];
  return {
    sendMessage: function(tabId, msg, cb) { sendFns.forEach(function(fn) { fn(tabId, msg); }); if (cb) cb(); return Promise.resolve(); },
    _onSend: function(fn) { sendFns.push(fn); }
  };
}

module.exports = { assert: assert, assertEq: assertEq, assertThrows: assertThrows, section: section, summary: summary,
  createStorageMock: createStorageMock, createRuntimeMock: createRuntimeMock, createTabsMock: createTabsMock };
