'use strict';
var fs = require('fs');
var path = require('path');
var T = require('./test-helpers');
var section = T.section;
var assert = T.assert;
var assertEq = T.assertEq;
var assertMatch = T.assertMatch;

// ---- 加载 background.js 到隔离 realm（模拟 Chrome 运行时）----
var bgSource = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

var lastNotify = null;

// 预装载背景依赖的 UMD 模块到 globalThis（与 importScripts 等效）
function preloadDeps() {
  if (!globalThis.WxdocShared) {
    var shared = require('../shared.js');
    globalThis.WxdocShared = shared;
  }
  if (!globalThis.WxdocSyncChannel) {
    var channel = require('../sync-channel.js');
    globalThis.WxdocSyncChannel = channel;
  }
  if (!globalThis.WxdocOutbox) {
    var outbox = require('../outbox.js');
    globalThis.WxdocOutbox = outbox;
  }
}
preloadDeps();

function mkResp(body, status) {
  return {
    ok: status >= 200 && status < 300, status: status,
    json: function () { return Promise.resolve(body); },
    text: function () { return Promise.resolve(JSON.stringify(body)); }
  };
}
function blobResp(size, type) {
  return Promise.resolve({
    ok: true, status: 200, type: type,
    blob: function () { return Promise.resolve({ size: size || 10, type: type || 'image/jpeg' }); },
    text: function () { return Promise.resolve(''); }
  });
}

function freshContext(settings) {
  var ctxData = Object.assign({
    mode: 'auto',
    serverUrl: 'http://10.9.8.7:16688',
    apiToken: 'tok',
    baseUrl: 'http://127.0.0.1:17321',
    token: 'desk',
    deviceId: 'dev-1',
    saveLocation: '微文存阅导出',
    dirNameTemplate: '{title}_{ts}',
    duplicatePolicy: 'new',
    askEveryTime: false,
    notifyOnDone: true
  }, settings || {});
  var fetchLog = [];
  var fetchTable = {};
  lastNotify = null;

  var msgListeners = [];
  var tabSendFns = [];

  globalThis.self = globalThis;
  globalThis.console = console;
  globalThis.TextEncoder = globalThis.TextEncoder || require('util').TextEncoder;
  globalThis.chrome = {
    runtime: {
      id: 'ext',
      lastError: null,
      onMessage: { addListener: function (fn) { msgListeners.push(fn); } },
      onInstalled: { addListener: function () {} }
    },
    storage: { local: ctxStorage() },
    tabs: { sendMessage: function (t, m) { tabSendFns.forEach(function (fn) { fn(t, m); }); return Promise.resolve(); } },
    commands: { onCommand: { addListener: function () {} } },
    alarms: { create: function () {}, onAlarm: { addListener: function () {} } },
    downloads: { download: function (opts, cb) { if (cb) cb(999); return Promise.resolve(999); } }
  };
  // chrome.* 收敛到 self 上(UMD 装载用)
  Object.keys(globalThis.chrome).forEach(function (k) { globalThis[k] = globalThis[k] || globalThis.chrome[k]; });

  globalThis.fetch = function (u, o) {
    fetchLog.push(u);
    if (fetchTable[u]) return Promise.resolve(mkResp(fetchTable[u].body, fetchTable[u].status));
    if (/mmbiz\.qpic\.cn|twimg\.com|video\.|\.jpg|\.png|\.mp4/.test(u)) return blobResp(80, 'image/jpeg');
    return mkResp({ ok: true }, 200);
  };

  // 模拟 content script：对 EXTRACT_REQUEST / BUILD_MD 用 Fixture 回复
  var tabRepliers = {};
  globalThis.chrome.tabs.sendMessage = function (tabId, msg, cb) {
    var r = tabRepliers[msg.type];
    var out = r ? r(msg) : { ok: false, error: 'no-replier' };
    if (typeof cb === 'function') { try { cb(out); } catch (e) {} }
    return Promise.resolve(out);
  };

  function ctxStorage() {
    return {
      get: function (k) {
        var dk = Array.isArray(k) ? null : (typeof k === 'object' ? k : null);
        var r = {};
        if (dk) Object.keys(dk).forEach(function (key) { r[key] = (key in ctxData) ? ctxData[key] : dk[key]; });
        else if (Array.isArray(k)) k.forEach(function (key) { r[key] = ctxData[key]; });
        else if (typeof k === 'string') r[k] = ctxData[k];
        return Promise.resolve(r);
      },
      set: function (items) { Object.assign(ctxData, items); return Promise.resolve(); }
    };
  }

  // 加载 UMD：把 background.js 用 new Function 执行，注入 chrome/fetch/Blob/... 等全局
  var wrapped = '(function(chrome,fetch,setTimeout,Blob,URL,console,JSON){\n' + bgSource + '\n})';
  var fn = new Function('return ' + wrapped)();
  fn(globalThis.chrome, globalThis.fetch, setTimeout, globalThis.Blob, globalThis.URL, console, JSON);
  // UMD 挂在 background.js 内部把 root 解析到 globalThis，取之即可
  var api = globalThis.WxdocBackground;

  return {
    api: api,
    onTabSend: function (fn) { tabSendFns.push(fn); },
    replyTab: function (type, fn) { tabRepliers[type] = fn; },
    msgListeners: msgListeners,
    data: ctxData,
    fetchLog: fetchLog,
    setFetch: function (url, body, status) { fetchTable[url] = { body: body, status: status }; }
  };
}

// 一个通用 content script fixture：对 EXTRACT_REQUEST 返回文章快照；对 BUILD_MD 返回占位 md
function attachContentFixture(ctx) {
  ctx.replyTab('EXTRACT_REQUEST', function () { return { ok: true, article: articleFixture() }; });
  ctx.replyTab('BUILD_MD', function () { return { ok: true, md: '# hi\n\nhello', blocks: [], media: [] }; });
}

// 触发背景消息监听器（模拟 chrome.runtime.onMessage 派发）
function dispatchMsg(ctx, msg) {
  var captured = null;
  ctx.msgListeners.forEach(function (fn) { fn(msg, { tab: { id: 1 } }, function (r) { captured = r; }); });
  return captured;
}

function dispatchMsgAsync(ctx, msg) {
  return new Promise(function (resolve) {
    var done = false;
    var t = setTimeout(function () { if (!done) { done = true; resolve({ timeout: true }); } }, 3000);
    ctx.msgListeners.forEach(function (fn) {
      var ret = fn(msg, { tab: { id: 1 } }, function (r) {
        if (!done) { done = true; clearTimeout(t); resolve(r); }
      });
      if (ret === true) { /* 异步：等待 sendResponse */ }
    });
  });
}

function articleFixture(n) {
  n = n || 1;
  var media = [], blocks = [{ kind: 'paragraph', text: 'hi' }];
  for (var i = 0; i < n; i++) {
    media.push({ url: 'https://mmbiz.qpic.cn/img' + i + '.jpg', media_type: 'image', description: 'd' + i });
    blocks.push({ kind: 'image', media_index: i });
  }
  return {
    title: 'T-' + Date.now(), author_name: 'pub', blocks: blocks, media: media,
    original_url: 'https://mp.weixin.qq.com/s/abc', source: 'wechat'
  };
}

// 背景闭包 root===globalThis，root.fetch 运行时读全局槽位；
// 并发跑段会踩后一个上下文的桩，故 A–F 串行执行，上下文随段延迟创建。
var chain = Promise.resolve();

chain = chain.then(function () {
  section('A. 编排：download 通道（无后端无桌面）');
  var c1 = freshContext({ mode: 'download', serverUrl: '' });
  attachContentFixture(c1);
  c1.onTabSend(function (tabId, msg) { lastNotify = msg; });
  return (async function () {
    var result = await c1.api.runDownloadExport({ id: 1 }, { saveLocation: '导出', dirNameTemplate: '{title}_{ts}', duplicatePolicy: 'new', askEveryTime: false });
    assertEq(result.channel, 'download', 'download 通道返回 channel');
    assert(result.dirPath, 'download 通道产出 jobDir');
    assertEq(result.mediaTotal, 1, '媒体计数');
    c1.api.flushOutbox; // 可调用即可
  })();
}).catch(function (e) { console.log('A.ERR ' + e.message); process.exit(1); });

chain = chain.then(function () {
  section('B. 编排：backend auto 失败 → desktop');
  var c2 = freshContext({ mode: 'auto', serverUrl: 'http://10.9.8.7:16688', apiToken: 'tok' });
  attachContentFixture(c2);
  // push /articles/sync/push：405 端点未实现 → unavailable（§3.3）→ 降级桌面
  c2.setFetch('http://10.9.8.7:16688/api/articles/sync/push', { error: 'no impl' }, 405);
  // health / probe ok → 选 backend；push 后降级
  c2.setFetch('http://10.9.8.7:16688/api/health', { ok: true }, 200);
  // 桌面桥 /api/download 202 → 任务；/api/tasks/{id} → completed
  c2.setFetch('http://127.0.0.1:17321/api/download', { taskId: 'task-1', status: 'queued' }, 202);
  c2.setFetch('http://127.0.0.1:17321/api/tasks/task-1', { status: 'completed', article_id: 'art-9', title: 'T' }, 200);
  c2.onTabSend(function () {});
  return (async function () {
    var result = await c2.api.runExport({ id: 1 });
    assert(result, 'runExport 返回结果');
    // 入队 flush
    var flush = await c2.api.flushOutbox();
    assert(flush && typeof flush.tried === 'number', 'flushOutbox 返回汇总');
  })();
}).catch(function (e) { console.log('B.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('C. 互斥锁');
  var c3 = freshContext({ mode: 'download', serverUrl: '' });
  attachContentFixture(c3);
  c3.onTabSend(function () {});
  return (async function () {
    var ok1 = c3.api.handleMessage({ type: 'EXPORT_START', tabId: 1 }, { tab: { id: 1 } }, function () {});
    // 立刻再锁同一 tab，应被拒
    var responses = [];
    c3.msgListeners.forEach(function (fn) {
      fn({ type: 'EXPORT_START', tabId: 1 }, { tab: { id: 1 } }, function (r) { responses.push(r); });
    });
    // sendResponse 经 wrapAsync 微任务送达，等一轮事件循环再断言
    await new Promise(function (r) { setTimeout(r, 50); });
    var hasReject = responses.some(function (r) { return r && r.data && r.data.code === 'locked'; });
    assert(hasReject, '同一 tabId 并发 EXPORT_START 被锁拒绝');
  })();
}).catch(function (e) { console.log('C.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('D. UI_PROBE 返回通道状态');
  var c4 = freshContext({ mode: 'auto', serverUrl: '', baseUrl: 'http://127.0.0.1:17321' });
  return (async function () {
    var probe = await new Promise(function (resolve) {
      var done = false;
      var t = setTimeout(function () { if (!done) resolve({ timeout: true }); }, 2000);
      c4.msgListeners.forEach(function (fn) {
        fn({ type: 'UI_PROBE' }, { tab: { id: 1 } }, function (r) {
          if (!done) { done = true; clearTimeout(t); resolve(r); }
        });
      });
    });
    assert(probe && probe.ok === true, 'UI_PROBE 返回 ok:true');
  })();
}).catch(function (e) { console.log('D.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('E. flushOutbox：空队列直接返回');
  var c5 = freshContext({ serverUrl: 'http://10.9.8.7:16688', apiToken: 'tok' });
  return (async function () {
    var r = await c5.api.flushOutbox();
    assert(r.empty === true || r.remaining === 0, '空队列 flush 返回 empty/0');
  })();
}).catch(function (e) { console.log('E.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('F. 未知消息类型应回错误信封');
  var c6 = freshContext();
  return (async function () {
    var r = await new Promise(function (resolve) {
      c6.msgListeners.forEach(function (fn) {
        fn({ type: 'NOPE' }, { tab: { id: 1 } }, function (resp) { resolve(resp); });
      });
    });
    assert(r && r.ok === false, '未知 type 返回 ok:false');
  })();
}).catch(function (e) { console.log('F.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('G. decideChannel 矩阵');
  var c7 = freshContext();
  assertEq(c7.api.decideChannel({ mode: 'auto' }, { backend: { ok: true } }), 'backend', 'auto+后端可用→backend');
  assertEq(c7.api.decideChannel({ mode: 'auto' }, { desktop: { ok: true } }), 'desktop', 'auto+仅桌面→desktop');
  assertEq(c7.api.decideChannel({ mode: 'auto' }, {}), 'download', 'auto+都不可用→download');
  assertEq(c7.api.decideChannel({ mode: 'backend' }, {}), 'backend', 'mode=backend 强选');
  assertEq(c7.api.decideChannel({ mode: 'desktop' }, {}), 'desktop', 'mode=desktop 强选');
  assertEq(c7.api.decideChannel({ mode: 'download' }, { backend: { ok: true } }), 'download', 'mode=download 强选覆盖可用性');
}).catch(function (e) { console.log('G.ERR ' + e.stack); process.exit(1); });

chain = chain.then(function () {
  section('H. resolveChannel 错误文案');
  var c8 = freshContext();
  var s1 = c8.api.resolveChannelState({ mode: 'backend', serverUrl: '' }, { backend: { ok: false } });
  assert(!!s1.reason, 'mode=backend 无地址时报错因');
  assertEq(s1.channel, 'error', '非法模式落到 error');
  var s2 = c8.api.resolveChannelState({ mode: 'auto', serverUrl: 'http://10.9.8.7:16688' }, { backend: { ok: true } });
  assertEq(s2.channel, 'backend', 'auto+后端 ok→backend');
}).catch(function (e) { console.log('H.ERR ' + e.stack); process.exit(1); });

