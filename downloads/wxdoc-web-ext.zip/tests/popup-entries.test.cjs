// 真实 Chrome 加载未打包扩展，验证 popup 的「访问入口」环境集渲染、切换持久化与打开行为
// 说明：入口目标用本机 echo HTTP 服务（响应体回显请求路径）断言真实打开的页面；
//      指向 16702/27788 等真实端点的用例只核对按钮 title，不发点击，避免依赖现场服务是否在跑。
'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const {chromium} = require('../../wxdoc-desk/tests/node_modules/playwright');
const extension = path.resolve(__dirname, '..');
const {defaultChrome} = require('./helpers/chrome-path');
const executable = defaultChrome();

async function startEchoServer(t) {
 const server = http.createServer((req, res) => {
  res.setHeader('content-type', 'text/html; charset=utf-8');
  res.end(`<!doctype html><meta charset="utf-8"><title>entry</title><h1 id="echo">${req.url}</h1>`);
 });
 await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
 t.after(() => { server.closeAllConnections(); return new Promise((resolve) => server.close(resolve)); });
 return `http://127.0.0.1:${server.address().port}`;
}

async function openPopup(t, state) {
 const profile = await fs.mkdtemp(path.join(os.tmpdir(), 'WWCN-popup-'));
 const context = await chromium.launchPersistentContext(profile, {
  ...(executable ? {executablePath: executable} : {}),
  headless: true,
  args: [`--disable-extensions-except=${extension}`, `--load-extension=${extension}`]
 });
 t.after(async () => { await context.close(); await fs.rm(profile, {recursive: true, force: true}); });
 const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 const url = `chrome-extension://${new URL(worker.url()).host}/popup.html`;
 const page = await context.newPage();
 const errors = [];
 page.on('pageerror', e => errors.push(e.message));
 await page.goto(url);
 if (state) {
  await page.evaluate((s) => new Promise((resolve) => chrome.storage.local.set(s, resolve)), state);
  await page.reload();
 }
 await page.waitForSelector('#entryProfile');
 t.after(() => assert.deepEqual(errors, [], 'popup 页不应有脚本错误'));
 return {context, page};
}

const btn = (key) => `.entry-open[data-entry="${key}"]`;
const attr = (page, key, name) =>
 page.evaluate(([k, n]) => document.querySelector(`.entry-open[data-entry="${k}"]`).getAttribute(n), [key, name]);
const profileValue = (page) => page.inputValue('#entryProfile');

test('popup 默认跟随服务端地址，点击入口在 new tab 打开推导出的页面', async t => {
 const base = await startEchoServer(t);
 const {context, page} = await openPopup(t, {mode: 'direct', serverUrl: `${base}/api`});

 assert.equal(await profileValue(page), 'follow');
 assert.equal(await attr(page, 'web', 'title'), `${base}/（自动推导）`);

 const [tab] = await Promise.all([context.waitForEvent('page'), page.click(btn('web'))]);
 await tab.waitForLoadState('load');
 assert.equal(await tab.locator('#echo').textContent(), '/');
});

test('popup 切到 NAS 环境：Web 走前端 27788，H5 指向本机网关并说明来源', async t => {
 const base = await startEchoServer(t);
 const {page} = await openPopup(t, {mode: 'direct', serverUrl: `${base}/api`});
 await page.selectOption('#entryProfile', 'nas');

 assert.equal(await attr(page, 'web', 'title'), 'http://192.168.10.222:27788/（环境预设）');
 // NAS 栈未部署 H5，入口借本机统一网关：可点，但 title 与提示必须写清指向别处
 assert.equal(await attr(page, 'h5', 'disabled'), null, 'NAS 的 H5 入口应可点');
 assert.equal(await attr(page, 'h5', 'title'),
  'http://127.0.0.1:16702/h5/（环境预设） · NAS 栈未部署 H5（compose 仅 backend 26690 + frontend 27788），此入口指向本机 Docker 统一网关，打开的是本机库');
 assert.match(await page.textContent('#entryMsg'), /指向本机 Docker 统一网关/);
});

test('环境选择即时落库，popup 重开后仍是所选环境', async t => {
 const {page} = await openPopup(t, {mode: 'direct'});
 await page.selectOption('#entryProfile', 'local-gw');
 assert.equal(await attr(page, 'h5', 'title'), 'http://127.0.0.1:16702/h5/（环境预设）');

 // 重渲染不得往环境下拉里重复追加选项
 await page.selectOption('#entryProfile', 'nas');
 await page.selectOption('#entryProfile', 'local-gw');
 assert.equal(await page.locator('#entryProfile option').count(), 5, '环境选项不应累积');

 await page.reload();
 await page.waitForSelector('#entryProfile');
 assert.equal(await profileValue(page), 'local-gw', '环境选择应持久化');
});

test('未配置服务端地址时 Web 入口置灰并给出可操作的提示', async t => {
 const {context, page} = await openPopup(t, {mode: 'direct', serverUrl: ''});

 assert.equal(await attr(page, 'web', 'disabled'), '');
 assert.match(await page.textContent('#entryMsg'), /请到「设置/);

 const tabsBefore = context.pages().length;
 // 绕过 Playwright 的可点击性等待，直发 DOM 点击：置灰按钮不应绑定任何打开逻辑
 await page.$eval(btn('web'), (el) => el.click());
 await page.waitForTimeout(300);
 assert.equal(context.pages().length, tabsBefore, '置灰按钮不应开新标签');
});
