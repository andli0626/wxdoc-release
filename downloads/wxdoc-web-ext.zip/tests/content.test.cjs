const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const {JSDOM} = require('jsdom');
const source = fs.readFileSync(require('node:path').join(__dirname,'../content.js'),'utf8');
const wechatUrl = 'https://mp.weixin.qq.com/s/hULi0iGg9xYP5DZF_Dkamg';
const wechatHtml = '<main><h1 class="rich_media_title">微信文章标题</h1><div id="js_content">微信正文</div></main>';
const url = wechatUrl;
const article = wechatHtml;
function setup(t, {html=article, href=url, saved={}, response}={}) {
 const dom = new JSDOM(html,{url:href,runScripts:'outside-only',pretendToBeVisual:true});
 const w = dom.window, calls=[], messages=[], roots=[], observers=[], storageListeners=[];
 const attach = w.Element.prototype.attachShadow;
 w.Element.prototype.attachShadow=function(options){const root=attach.call(this,options);roots.push(root);return root;};
 const MO=w.MutationObserver;
 w.MutationObserver=class extends MO{constructor(cb){super(cb);observers.push(this);}};
 w.chrome = {storage:{local:{get:(defaults,cb)=>cb({...defaults,...saved}),set:async v=>Object.assign(saved,v)},onChanged:{addListener:fn=>{storageListeners.push(fn);}}},runtime:{sendMessage:async m=>{calls.push(m);return response ? response(m) : {ok:true,data:{taskId:'test-task',status:'queued'}};},onMessage:{addListener:fn=>{messages.push(fn);}}}};
 w.eval(source); t.after(()=>{w.dispatchEvent(new w.Event('pagehide'));observers.forEach(o=>o.disconnect());w.close();});
 const root = () => roots.at(-1);
 const ptr = (type,x,y) => {const e=new w.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y});e.pointerId=1;return e;};
 return {w,calls,messages,saved,root,storageListeners,ptr,button:()=>root().querySelector('.wx-main'),mini:()=>root().querySelector('.wx-mini'),wxRoot:()=>root().querySelector('.wx'),notice:()=>root().querySelector('.notice'),panel:()=>root().querySelector('.panel'),host:()=>w.document.querySelector('#WWCN-floating-host')};
}
const tick = () => new Promise(resolve=>setTimeout(resolve,30));
test('WeChat article URL mounts the save button',t=>{const c=setup(t);assert.ok(c.host());assert.equal(c.button().disabled,false);});
test('non-WeChat pages never mount the floating button',t=>{for (const href of ['https://x.com/miles_mazy/status/2097603040169885855','https://x.com/i/article/123','https://example.com/blog/post-1']) { const c=setup(t,{href,html:'<main><div data-testid="twitterArticleRichTextView">其他站点的文章正文</div></main>'});assert.ok(!c.host(),href);}});
test('SPA navigation mounts exactly once and only on the WeChat article',async t=>{
 const c=setup(t,{html:'<main>正在加载</main>',href:'https://mp.weixin.qq.com/'});assert.ok(!c.host());
 c.w.document.body.innerHTML=article;await tick();assert.ok(!c.host());
 c.w.history.pushState({},'',wechatUrl);c.w.dispatchEvent(new c.w.PopStateEvent('popstate'));await tick();assert.ok(c.host());
 c.w.history.pushState({},'','/home');c.w.dispatchEvent(new c.w.PopStateEvent('popstate'));await tick();assert.ok(!c.host());
 c.w.history.pushState({},'',wechatUrl);c.w.dispatchEvent(new c.w.PopStateEvent('popstate'));await tick();
 assert.equal(c.w.document.querySelectorAll('#WWCN-floating-host').length,1);
});
test('offscreen saved position is clamped inside the viewport',t=>{const c=setup(t,{saved:{position:{left:99999,top:99999}}});assert.ok(parseFloat(c.host().style.left)<c.w.innerWidth-48);assert.ok(parseFloat(c.host().style.top)<c.w.innerHeight-48);});
test('keyboard click submits only once while pending',async t=>{
 const c=setup(t);const b=c.button();b.click();b.click();await tick();
 assert.deepEqual(c.calls.filter(m=>m.type==='download').map(m=>m.url),[url]);assert.match(b.title,/已提交|排队|下载/);assert.doesNotMatch(b.title,/已完成/);
});
test('extension reload errors show a refresh instruction',async t=>{
 const c=setup(t,{response:()=>{throw Error('Extension context invalidated');}});const b=c.button();b.click();await tick();assert.match(b.title,/刷新|失效/);assert.ok(!b.classList.contains('busy'));
});
test('poll failure cleans tracking so the article can be resubmitted',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});
 const flush=()=>new Promise(r=>setImmediate(r));
 const c=setup(t,{response:async m=>{
  if (m.type==='download') return {ok:true,data:{taskId:'t1',status:'queued'}};
  if (m.type==='task') throw Error('微文存阅客户端未启动');
  if (m.type==='recent') return {ok:true,data:[]};
  return {ok:true};
 }});
 const b=c.button();b.click();await flush();
 assert.match(b.title,/已提交/);
 t.mock.timers.tick(1100);await flush();   // 首个 poll 触发并失败
 assert.match(b.title,/未启动/);assert.ok(b.classList.contains('err'));
 t.mock.timers.tick(8000);await flush();   // 不应再有轮询/死锁
 b.click();await flush();                  // active 已清理，可再次提交
 assert.equal(c.calls.filter(m=>m.type==='download').length,2);
});
test('completed task clears tracking and allows same article again',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});
 const flush=()=>new Promise(r=>setImmediate(r));
 let taskStatus='queued';
 const c=setup(t,{response:async m=>{
  if (m.type==='download') return {ok:true,data:{taskId:'t1',status:'queued'}};
  if (m.type==='task') return {ok:true,data:{status:taskStatus}};
  if (m.type==='recent') return {ok:true,data:[]};
  return {ok:true};
 }});
 const b=c.button();b.click();await flush();
 t.mock.timers.tick(1100);await flush();
 taskStatus='completed';t.mock.timers.tick(2000);await flush();
 assert.match(b.title,/完成/);
 b.click();await flush();
 assert.equal(c.calls.filter(m=>m.type==='download').length,2);
});
test('client not open reminds the user to start the desktop client',async t=>{
 const offline = {ok:false, error:'Failed to fetch', code:'offline'};
 const c=setup(t,{response:async ()=>offline});
 await tick();
 const b=c.button();
 assert.match(b.title,/请先打开微文存阅客户端/);        // 悬停即可看到原因
 assert.ok(c.notice().hidden);                        // 空闲状态不打扰页面
 assert.match(c.panel().innerHTML,/请先打开微文存阅客户端/); // 任务面板给出离线说明
 b.click();await tick();
 assert.ok(b.classList.contains('err'));
 assert.match(c.notice().textContent,/请先打开微文存阅客户端/);
 assert.equal(c.notice().hidden,false);
});
test('failed submit while the client is closed flips the panel offline',async t=>{
 const c=setup(t,{response:async m=>m.type==='recent' ? {ok:true,data:[]} : {ok:false,error:'Failed to fetch',code:'offline'}});
 await tick();
 assert.match(c.panel().innerHTML,/暂无下载任务/);
 const b=c.button();b.click();await tick();
 assert.ok(b.classList.contains('err'));
 assert.match(c.panel().innerHTML,/请先打开微文存阅客户端/);
});
test('starting the client clears the offline reminder',async t=>{
 t.mock.timers.enable({apis:['setTimeout','setInterval']});
 const flush=()=>new Promise(r=>setImmediate(r));
 let up=false;
 const c=setup(t,{response:async m=>{
  if (m.type==='recent') return up ? {ok:true,data:[]} : {ok:false,error:'Failed to fetch',code:'offline'};
  return {ok:true};
 }});
 await flush();
 const b=c.button();assert.match(b.title,/请先打开微文存阅客户端/);
 up=true;t.mock.timers.tick(5000);await flush();
 assert.equal(b.title,'保存到微文存阅');
});
test('finished tasks render status, actions and clear button in the panel',async t=>{
 const tasks=[
  {id:'t-done',title:'已完成的长文',status:'completed',items:[{status:'completed'}]},
  {id:'t-fail',title:'失败的文章',status:'failed',error:'下载出错',items:[{status:'failed',error:'404'}]},
  {id:'t-run',title:'下载中的文章',status:'running',phase:'正在下载图片',items:[{status:'running'}]}
 ];
 const c=setup(t,{response:async m=>m.type==='recent'?{ok:true,data:tasks}:{ok:true}});
 await tick();
 const panel=c.panel().innerHTML;
 assert.match(panel,/已完成的长文/);
 assert.match(panel,/data-task-action="retry"/);       // 失败任务可重试
 assert.match(panel,/data-task-action="delete"/);      // 结束任务可删除
 assert.match(panel,/data-task-action="clearFinished"/);
 assert.match(panel,/progress-bar/);                   // 运行中任务显示进度条
});
test('panel retry needs no confirm; delete/clear require confirmation',async t=>{
 const c=setup(t,{response:async m=>{
  if (m.type==='recent') return {ok:true,data:[{id:'t1',title:'失败任务',status:'failed',items:[{status:'failed'}]}]};
  return {ok:true};
 }});
 await tick();
 const root=c.root();
 root.querySelector('[data-task-action="retry"]').click();
 await tick();
 assert.ok(c.calls.some(m=>m.type==='retry'&&m.taskId==='t1'));
 assert.equal(root.querySelector('.cfm-mask'),null);                    // 重试不弹确认
 root.querySelector('[data-task-action="delete"]').click();
 await tick();
 assert.equal(root.querySelectorAll('.cfm-mask').length,1);             // 删除先弹二次确认
 assert.match(root.querySelector('.cfm-detail').textContent,/失败任务/); // 文案点明被删条目
 root.querySelector('.cfm-btn').click();                                 // 取消
 await tick();
 assert.equal(root.querySelector('.cfm-mask'),null);
 assert.ok(!c.calls.some(m=>m.type==='deleteTask'));                     // 取消则无操作
 root.querySelector('[data-task-action="delete"]').click();
 await tick();
 root.querySelector('.cfm-btn.danger').click();                          // 确认后删除
 await tick();
 assert.ok(c.calls.some(m=>m.type==='deleteTask'&&m.taskId==='t1'));
 root.querySelector('[data-task-action="clearFinished"]').click();
 await tick();
 assert.match(root.querySelector('.cfm-detail').textContent,/1 条/);     // 清空文案展示条数
 root.querySelector('.cfm-btn.danger').click();
 await tick();
 assert.ok(c.calls.some(m=>m.type==='clearFinished'));
});
test('WeChat short link enables the WeChat save button',t=>{
 const c=setup(t,{html:wechatHtml,href:wechatUrl});
 assert.ok(c.host());assert.equal(c.button().disabled,false);
 assert.equal(c.button().textContent,'存阅');
 assert.match(c.button().querySelector('.ic-wechat').innerHTML,/stroke-linejoin="round"/);
 assert.equal(c.button().title,'保存到微文存阅');
});
test('WeChat long link submits the canonical four-element URL',async t=>{
 const href='https://mp.weixin.qq.com/s?__biz=MzA5MjMzOTc4Mw%3D%3D&mid=2650123456&idx=1&sn=abc123def&scene=27#wechat_redirect';
 const c=setup(t,{html:wechatHtml,href});
 const b=c.button();assert.equal(b.disabled,false);
 b.click();await tick();
 assert.deepEqual(c.calls.filter(m=>m.type==='download').map(m=>m.url),
   ['https://mp.weixin.qq.com/s?__biz=MzA5MjMzOTc4Mw==&mid=2650123456&idx=1&sn=abc123def']);
});
test('WeChat non-article pages show no floating button',t=>{
 const c=setup(t,{html:'<main>微信公众平台首页</main>',href:'https://mp.weixin.qq.com/'});
 assert.ok(!c.host());
});
test('wechat page probes the server video gap once and renders a backfill row',async t=>{
 t.mock.timers.enable({apis:['setTimeout','setInterval']});
 const flush=()=>new Promise(r=>setImmediate(r));
 const c=setup(t,{html:wechatHtml,href:wechatUrl,response:async m=>{
  if (m.type==='recent') return {ok:true,data:[]};
  if (m.type==='VIDEO_GAP_CHECK') return {ok:true,data:{checked:true,found:true,videoCount:2,videoReady:1,desktopOk:true}};
  return {ok:true};
 }});
 await flush();
 const probes=c.calls.filter(m=>m.type==='VIDEO_GAP_CHECK');
 assert.equal(probes.length,1);assert.equal(probes[0].url,wechatUrl);
 t.mock.timers.tick(5000);await flush();       // 周期刷新渲染面板行
 assert.match(c.panel().innerHTML,/data-task-action="videoBackfill"/);
 assert.match(c.panel().innerHTML,/1\/2/);
});
test('backfill row falls back to a disabled hint when the desktop client is offline',async t=>{
 t.mock.timers.enable({apis:['setTimeout','setInterval']});
 const flush=()=>new Promise(r=>setImmediate(r));
 const c=setup(t,{html:wechatHtml,href:wechatUrl,response:async m=>{
  if (m.type==='recent') return {ok:true,data:[]};
  if (m.type==='VIDEO_GAP_CHECK') return {ok:true,data:{checked:true,found:true,videoCount:1,videoReady:0,desktopOk:false}};
  return {ok:true};
 }});
 await flush();
 t.mock.timers.tick(5000);await flush();
 const row=c.panel().querySelector('[data-task-action="videoBackfill"]');
 assert.ok(row);assert.equal(row.disabled,true);
 assert.match(row.textContent,/需桌面端在线/);
});
test('SPA navigation on WeChat keeps one host and mounts only on the article',async t=>{
 const c=setup(t,{html:wechatHtml,href:wechatUrl});
 assert.equal(c.button().textContent,'存阅');assert.equal(c.button().disabled,false);
 c.w.history.pushState({},'','/home');c.w.dispatchEvent(new c.w.PopStateEvent('popstate'));await tick();
 assert.equal(c.w.document.querySelectorAll('#WWCN-floating-host').length,0);
 c.w.history.pushState({},'','/s/hULi0iGg9xYP5DZF_Dkamg');c.w.dispatchEvent(new c.w.PopStateEvent('popstate'));await tick();
 assert.equal(c.w.document.querySelectorAll('#WWCN-floating-host').length,1);
 assert.equal(c.button().textContent,'存阅');assert.equal(c.button().disabled,false);
});
test('the idle button carries only the WeChat glyph',t=>{
 const c=setup(t);
 assert.equal(c.button().textContent,'存阅');
 assert.match(c.button().querySelector('.ic-wechat').innerHTML,/stroke-linejoin="round"/);
 assert.equal(c.button().querySelector('.ic-x'),null);
});
test('legacy {left,top} position loads as the expanded form',t=>{
 const c=setup(t,{saved:{position:{left:300,top:400}}});
 assert.equal(c.host().style.left,'300px');assert.equal(c.host().style.top,'400px');
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'0');
});
test('stored collapsed:true mounts the collapsed circle',t=>{
 const c=setup(t,{saved:{position:{left:300,top:400,collapsed:true}}});
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'1');
 assert.ok(c.button().querySelector('.wx-label').hasAttribute('hidden'));
});
test('mini button toggles forms with right-edge anchoring and persists',t=>{
 const c=setup(t,{saved:{position:{left:300,top:400}}});
 c.mini().click();                                    // 展开→收起：右缘锚定 300+172-74
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'1');
 assert.equal(c.host().style.left,'398px');
 assert.equal(c.saved.position.collapsed,true);assert.equal(c.saved.position.left,398);
 c.mini().click();                                    // 收起→展开：右缘仍不动
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'0');
 assert.equal(c.host().style.left,'300px');
 assert.equal(c.saved.position.collapsed,false);assert.equal(c.saved.position.left,300);
});
test('storage onChanged syncs position and collapsed form across tabs',t=>{
 const c=setup(t);
 c.storageListeners.at(-1)({position:{newValue:{left:222,top:333,collapsed:true}}},'local');
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'1');
 assert.equal(c.host().style.left,'222px');assert.equal(c.host().style.top,'333px');
 c.storageListeners.at(-1)({position:{newValue:{left:222,top:333}}},'local');
 assert.equal(c.wxRoot().getAttribute('data-collapsed'),'0');
});
test('long press opens the task panel instead of saving',async t=>{
 t.mock.timers.enable({apis:['setTimeout','setInterval']});
 const flush=()=>new Promise(r=>setImmediate(r));
 const c=setup(t);
 const b=c.button();
 b.dispatchEvent(c.ptr('pointerdown',500,400));
 t.mock.timers.tick(600);
 assert.equal(c.panel().hidden,false);
 c.w.dispatchEvent(c.ptr('pointerup',500,400));
 b.click();await flush();
 assert.equal(c.calls.filter(m=>m.type==='download').length,0);
});
test('sub-threshold jitter still saves; crossing threshold drags and persists',async t=>{
 const flush=()=>new Promise(r=>setImmediate(r));
 const c=setup(t);const b=c.button();
 b.dispatchEvent(c.ptr('pointerdown',500,400));
 c.w.dispatchEvent(c.ptr('pointermove',502,402));     // |dx|+|dy|=4，未越阈值
 c.w.dispatchEvent(c.ptr('pointerup',502,402));
 b.click();await flush();
 assert.equal(c.calls.filter(m=>m.type==='download').length,1);
 assert.equal(c.saved.position,undefined);             // 未移动：不写存储（旧版每次 pointerup 都裸写）
 b.dispatchEvent(c.ptr('pointerdown',500,400));        // JSDOM 里 host rect 全 0：落点=指针-抓取偏移
 c.w.dispatchEvent(c.ptr('pointermove',560,460));
 c.w.dispatchEvent(c.ptr('pointerup',560,460));
 assert.equal(c.panel().hidden,true);                  // 越过阈值即取消长按，面板不弹
 b.click();await flush();
 assert.equal(c.calls.filter(m=>m.type==='download').length,1); // 拖拽不触发保存
 assert.equal(c.saved.position.left,60);assert.equal(c.saved.position.top,60);
});
test('hover on the expanded pill reveals the summary line',async t=>{
 const tasks=[{id:'t1',title:'运行中任务',status:'running',items:[{status:'running'}]}];
 const c=setup(t,{response:async m=>m.type==='recent'?{ok:true,data:tasks}:{ok:true}});
 await tick();
 const sum=c.root().querySelector('.wx-sum');
 c.button().dispatchEvent(new c.w.Event('pointerenter'));
 assert.equal(sum.hasAttribute('hidden'),false);
 assert.match(sum.textContent,/微信 · 进行中 1/);
 c.button().dispatchEvent(new c.w.Event('pointerleave'));
 assert.equal(sum.hasAttribute('hidden'),true);
 assert.equal(c.button().querySelector('.wx-label').textContent,'存阅');
 assert.equal(c.button().querySelector('.badge').textContent,'1'); // 进行中任务角标随摘要一起可见
});
/* ===== 通道着色：UI_PROBE 实际生效通道驱动按钮背景色/tooltip/面板徽标 ===== */
const chanSetup=(t,channel,extra={})=>setup(t,{response:async m=>m.type==='UI_PROBE'?{ok:true,data:{channel,...extra}}:{ok:true,data:[]}});
test('backend channel tints the button and labels the idle tooltip',async t=>{
 const c=chanSetup(t,'backend',{mode:'backend'});
 await tick();
 assert.equal(c.host().getAttribute('data-channel'),'backend');
 assert.match(c.button().title,/保存到微文存阅 · 直连服务端/);
});
test('desktop channel labels the tooltip and renders the panel chip',async t=>{
 const c=chanSetup(t,'desktop',{mode:'desktop'});
 await tick();
 assert.equal(c.host().getAttribute('data-channel'),'desktop');
 assert.match(c.button().title,/保存到微文存阅 · 桌面客户端/);
 assert.match(c.panel().innerHTML,/chan-desktop/);
 assert.match(c.panel().innerHTML,/桌面客户端/);
});
test('error channel tooltip surfaces the probe reason',async t=>{
 const c=chanSetup(t,'error',{mode:'backend',reason:'后端探活失败（地址不可达或返回异常），请检查后端服务与地址配置'});
 await tick();
 assert.equal(c.host().getAttribute('data-channel'),'error');
 assert.match(c.button().title,/后端探活失败/);
});
test('unknown probe response keeps the default tint and idle tooltip',async t=>{
 const c=setup(t,{response:async m=>m.type==='UI_PROBE'?{ok:true}:{ok:true,data:[]}});
 await tick();
 assert.equal(c.host().hasAttribute('data-channel'),false);
 assert.equal(c.button().title,'保存到微文存阅');
});
test('storage mode backend (v2) takes the direct submit path',async t=>{
 const c=setup(t,{html:wechatHtml,href:wechatUrl,saved:{mode:'backend'}});
 c.w.WxdocAdapter={WECHAT_ADAPTER:{extract:()=>({original_url:wechatUrl,title:'微信文章',blocks:[{type:'text'}],media:[]})}};
 const b=c.button();b.click();await tick();
 assert.ok(c.calls.some(m=>m.type==='directSubmit'));
 assert.ok(!c.calls.some(m=>m.type==='download'));
});
