const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {chromium} = require('../../wxdoc-desk/tests/node_modules/playwright');
const extension = path.resolve(__dirname, '..');
// 浏览器发现逻辑统一放 helpers/chrome-path.js：headless 下只有 Playwright 自带 chromium 完整构建会加载 MV3 扩展
const {defaultChrome} = require('./helpers/chrome-path');
const executable = defaultChrome();
const url='https://mp.weixin.qq.com/s/hULi0iGg9xYP5DZF_Dkamg';
const otherFixture='<!doctype html><html lang="zh"><meta charset="utf-8"><title>其他站点文章测试页面</title><style>body{margin:80px auto;max-width:650px;font:18px/1.8 sans-serif}</style><main><h1>非微信文章页面</h1><div data-testid="twitterArticleRichTextView">这是使用真实 Chrome 扩展加载的本地测试页面，不是微信内容。</div></main></html>';
const wechatFixture='<!doctype html><html lang="zh"><meta charset="utf"><title>微信文章测试页面</title><style>body{margin:80px auto;max-width:650px;font:18px/1.8 sans-serif}</style><main><h1 class="rich_media_title">微信公众号文章回归测试</h1><div id="js_content">这是微信公众号文章测试页面，不是真实微信内容。</div></main></html>';
const wechatHomeFixture=wechatFixture.replace('微信公众号文章回归测试','微信公众平台首页').replace('这是微信公众号文章测试页面，不是真实微信内容。','这不是文章页面。');
async function mockWechat(context,body=wechatFixture) {
 await context.route('https://mp.weixin.qq.com/**',route=>route.fulfill({contentType:'text/html',body}));
}
async function launch(t, prefix) {
 const profile=await fs.mkdtemp(path.join(os.tmpdir(),`${prefix}-`));
 const context=await chromium.launchPersistentContext(profile,{...(executable?{executablePath:executable}:{}),headless:true,args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]});
 t.after(async()=>{await context.close();await fs.rm(profile,{recursive:true,force:true});});
 return context;
}
function stubWorker(worker) {
 return worker.evaluate(()=>{globalThis.requests=[];globalThis.fetch=async (url,options={})=>{globalThis.requests.push({url,method:options.method||'GET',body:options.body});const u=String(url);if(u.endsWith('/api/download'))return new Response(JSON.stringify({taskId:'fixture-task',status:'queued'}),{status:200,headers:{'Content-Type':'application/json'}});if(u.includes('/api/tasks/fixture-task'))return new Response(JSON.stringify({id:'fixture-task',status:'completed',phase:'本地下载完成（测试桩）'}),{status:200,headers:{'Content-Type':'application/json'}});if(u.endsWith('/api/tasks/recent'))return new Response('[]',{status:200,headers:{'Content-Type':'application/json'}});return new Response('{"ok":true}',{status:200,headers:{'Content-Type':'application/json'}});};});
}
test('loaded MV3 extension renders on a WeChat article, drags, persists and submits through worker (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-test-');
 const errors=[];const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await mockWechat(context);
 await page.goto(url);const button=page.locator('#WWCN-floating-host .wx-main');await button.waitFor({state:'visible',timeout:10000});
 const start=await button.boundingBox();await page.mouse.move(start.x+24,start.y+24);await page.mouse.down();await page.mouse.move(350,350,{steps:10});await page.mouse.up();
 // 采样前把鼠标移开并等过渡 settle：拖拽缩放下沉与 hover 上浮的 transform 会污染 boundingBox
 await page.mouse.move(20,20);await page.waitForTimeout(400);
 const moved=await button.boundingBox();assert.ok(moved.x>300 && moved.y>300);
 const worker=context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 await stubWorker(worker);
 await page.reload();await button.waitFor();await page.waitForTimeout(400);const restored=await button.boundingBox();assert.ok(Math.abs(restored.x-moved.x)<2 && Math.abs(restored.y-moved.y)<2);
 await button.click();await page.waitForFunction(()=>document.querySelector('#WWCN-floating-host')?.shadowRoot.querySelector('.wx-main').classList.contains('ok'));
 const requests=await worker.evaluate(()=>globalThis.requests);const downloads=requests.filter(r=>r.url.endsWith('/api/download'));
 assert.equal(downloads.length,1);assert.equal(JSON.parse(downloads[0].body).url,url);
 await page.screenshot({path:'/tmp/WWCN-extension-wechat-status-fixture.png'});
 await page.evaluate(()=>{history.pushState({},'', '/home');window.dispatchEvent(new PopStateEvent('popstate'));});
 // 离开文章页即卸载悬浮按钮：微信非文章页不保留常驻按钮
 await page.waitForFunction(()=>!document.querySelector('#WWCN-floating-host'), null, {timeout:5000});
 assert.deepEqual(errors,[]);
});
test('other sites show no floating button (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-other-');
 const page=await context.newPage();
 await context.route('https://x.com/**',route=>route.fulfill({contentType:'text/html',body:otherFixture}));
 await mockWechat(context,wechatHomeFixture);
 await page.goto('https://x.com/miles_mazy/status/2097603040169885855');
 await page.waitForTimeout(1500);
 assert.equal(await page.locator('#WWCN-floating-host').count(),0,'非微信站点不应出现悬浮按钮');
 await page.goto('https://mp.weixin.qq.com/');
 await page.waitForTimeout(1500);
 assert.equal(await page.locator('#WWCN-floating-host').count(),0,'微信非文章页不应出现悬浮按钮');
});
test('collapsed form survives drag and reload (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-collapse-');
 const errors=[];const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await mockWechat(context);
 await page.goto(url);
 const main=page.locator('#WWCN-floating-host .wx-main');await main.waitFor({state:'visible',timeout:10000});
 const wxRoot=page.locator('#WWCN-floating-host .wx');
 assert.equal(await wxRoot.getAttribute('data-collapsed'),'0');
 await page.locator('#WWCN-floating-host .wx-mini').click();     // 展开态右缘辅助钮 → 收起
 assert.equal(await wxRoot.getAttribute('data-collapsed'),'1');
 const start=await main.boundingBox();await page.mouse.move(start.x+19,start.y+19);await page.mouse.down();await page.mouse.move(220,240,{steps:8});await page.mouse.up();
 const moved=await main.boundingBox();assert.ok(moved.x>180 && moved.x<225 && moved.y>200 && moved.y<245);
 await page.reload();
 await main.waitFor();await page.waitForTimeout(400);
 assert.equal(await page.locator('#WWCN-floating-host .wx').getAttribute('data-collapsed'),'1');
 const restored=await main.boundingBox();assert.ok(Math.abs(restored.x-moved.x)<2 && Math.abs(restored.y-moved.y)<2);
 assert.deepEqual(errors,[]);
});
test('WeChat article page renders the WeChat button and submits the short-link URL (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-wechat-');
 const errors=[];const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await context.route('https://mp.weixin.qq.com/**',route=>route.fulfill({contentType:'text/html',body:wechatFixture}));
 const wechatUrl='https://mp.weixin.qq.com/s/hULi0iGg9xYP5DZF_Dkamg';
 await page.goto(wechatUrl);
 const button=page.locator('#WWCN-floating-host .wx-main');await button.waitFor({state:'visible',timeout:10000});
 assert.equal((await button.locator('.wx-label').textContent()).trim(),'存阅');
 const worker=context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 await stubWorker(worker);
 await button.click();await page.waitForFunction(()=>document.querySelector('#WWCN-floating-host')?.shadowRoot.querySelector('.wx-main').classList.contains('ok'));
 const requests=await worker.evaluate(()=>globalThis.requests);const downloads=requests.filter(r=>r.url.endsWith('/api/download'));
 assert.equal(downloads.length,1);assert.equal(JSON.parse(downloads[0].body).url,wechatUrl);
 await page.screenshot({path:'/tmp/WWCN-extension-wechat-fixture.png'});
 assert.deepEqual(errors,[]);
});
test('client not running shows an open-client reminder instead of a raw fetch error (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-offline-');
 const page=await context.newPage();
 await mockWechat(context,wechatFixture.replace('微信公众号文章回归测试','客户端未打开时的提示回归测试').replace('这是微信公众号文章测试页面，不是真实微信内容。','这是离线提示测试页面，不是真实微信内容。'));
 await page.goto(url);const button=page.locator('#WWCN-floating-host .wx-main');await button.waitFor({state:'visible',timeout:10000});
 const worker=context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 await worker.evaluate(()=>{globalThis.fetch=async()=>{throw new TypeError('Failed to fetch');};}); // 模拟客户端未启动：本机端口无响应
 await button.click();
 await page.waitForFunction(()=>document.querySelector('#WWCN-floating-host')?.shadowRoot.querySelector('.wx-main').classList.contains('err'),null,{timeout:10000});
 const state=await page.evaluate(()=>{const root=document.querySelector('#WWCN-floating-host').shadowRoot;const n=root.querySelector('.notice'),r=n.getBoundingClientRect();return {title:root.querySelector('.wx-main').title,notice:n.textContent,noticeHidden:n.hidden,noticeRect:{left:Math.round(r.left),right:Math.round(r.right),bottom:Math.round(r.bottom)},viewport:{w:innerWidth,h:innerHeight},panel:root.querySelector('.panel').innerHTML};});
 assert.match(state.title,/请先打开微文存阅客户端/);
 assert.match(state.notice,/请先打开微文存阅客户端/);assert.equal(state.noticeHidden,false);
 assert.match(state.panel,/请先打开微文存阅客户端/);
 assert.ok(state.noticeRect.left>=0 && state.noticeRect.right<=state.viewport.w && state.noticeRect.bottom<=state.viewport.h,'提示气泡应完整显示在视口内，不能被屏幕边缘裁掉');
 await page.screenshot({path:'/tmp/WWCN-extension-offline.png'});
 const popup=await context.newPage();
 await popup.goto(`chrome-extension://${new URL(worker.url()).host}/popup.html`);
 await popup.waitForFunction(()=>/未连接/.test(document.getElementById('status').textContent));
 assert.match(await popup.textContent('#status'),/请先打开微文存阅(桌面)?客户端/);
});
test('floating button tints by the effective channel (fixture)',async t=>{
 const context=await launch(t,'WWCN-ext-chan-');
 const errors=[];const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await mockWechat(context);
 await page.goto(url);
 const main=page.locator('#WWCN-floating-host .wx-main');await main.waitFor({state:'visible',timeout:10000});
 const worker=context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 // 桌面端 /health 恒在线、无后端地址：auto 稳态通道 = desktop
 await worker.evaluate(()=>{globalThis.fetch=async(url)=>{const u=String(url);if(u.includes('/health'))return new Response(JSON.stringify({ok:true,version:'test'}),{status:200,headers:{'Content-Type':'application/json'}});return new Response('{"ok":true}',{status:200,headers:{'Content-Type':'application/json'}});};});
 const bg=()=>page.evaluate(()=>getComputedStyle(document.querySelector('#WWCN-floating-host').shadowRoot.querySelector('.wx-main')).backgroundColor);
 await page.waitForFunction(()=>document.querySelector('#WWCN-floating-host')?.getAttribute('data-channel')==='desktop',null,{timeout:10000});
 assert.match(await main.getAttribute('title'),/保存到微文存阅 · 桌面客户端/);
 await page.waitForFunction(()=>getComputedStyle(document.querySelector('#WWCN-floating-host').shadowRoot.querySelector('.wx-main')).backgroundColor==='rgb(7, 193, 96)',null,{timeout:5000});
 assert.equal(await bg(),'rgb(7, 193, 96)');
 await page.screenshot({path:'/tmp/WWCN-extension-channel-desktop.png'});
 // 锁后端但未配地址：通道判定为 error，按钮变红且 tooltip 播报原因
 await worker.evaluate(()=>chrome.storage.local.set({mode:'backend'}));
 await page.waitForFunction(()=>document.querySelector('#WWCN-floating-host')?.getAttribute('data-channel')==='error',null,{timeout:10000});
 assert.match(await main.getAttribute('title'),/后端地址/);
 await page.waitForFunction(()=>getComputedStyle(document.querySelector('#WWCN-floating-host').shadowRoot.querySelector('.wx-main')).backgroundColor==='rgb(217, 45, 32)',null,{timeout:5000});
 assert.equal(await bg(),'rgb(217, 45, 32)');
 await page.screenshot({path:'/tmp/WWCN-extension-channel-error.png'});
 assert.deepEqual(errors,[]);
});
