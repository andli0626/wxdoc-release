// 访问入口环境集（entries.js）纯函数测试：地址口径对照 docs/03-验收文档/36-端口矩阵与接口服务地址.md
'use strict';
var T = require('./test-helpers');
var section = T.section, assert = T.assert, assertEq = T.assertEq, summary = T.summary;
var E = require('../entries.js');

var APP = 'https://www.pgyer.com/wxdoc';

section('环境集清单与标签齐备');
assertEq(E.ENTRY_KEYS, ['web', 'h5', 'app', 'apiDoc', 'admin'], '入口维度固定 5 项');
['follow', 'local-gw', 'local-test-gw', 'local-direct', 'nas'].forEach(function (id) {
  var p = E.profileById(id);
  assert(p, '环境 ' + id + ' 存在');
  assert(p && p.label, '环境 ' + id + ' 有展示名');
});
assertEq(E.profileById('nope'), null, '未知环境返回 null');

section('本机 Docker 统一网关：四入口同源');
(function () {
  var r = E.resolveEntries({ entryProfile: 'local-gw' });
  assertEq(r.urls.web, 'http://127.0.0.1:16702/', 'web');
  assertEq(r.urls.h5, 'http://127.0.0.1:16702/h5/', 'h5');
  assertEq(r.urls.apiDoc, 'http://127.0.0.1:16702/api-doc', 'api-doc');
  assertEq(r.urls.admin, 'http://127.0.0.1:16702/service-addresses', 'service-addresses');
  assertEq(r.sources.web, '环境预设', '具名环境来源标注');
})();

section('本机 Docker 测试栈网关：26702 段');
(function () {
  var r = E.resolveEntries({ entryProfile: 'local-test-gw' });
  assertEq(r.urls.web, 'http://127.0.0.1:26702/', 'web = 26702');
  assertEq(r.urls.h5, 'http://127.0.0.1:26702/h5/', 'h5 = 26702/h5/');
})();

section('本机 Docker 前端直连：PC 16699 与 H5 16701 端口不同');
(function () {
  var r = E.resolveEntries({ entryProfile: 'local-direct' });
  assertEq(r.urls.web, 'http://127.0.0.1:16699/', 'web = 16699');
  assertEq(r.urls.h5, 'http://127.0.0.1:16701/h5/', 'h5 = 独立端口 16701');
  assertEq(r.urls.apiDoc, 'http://127.0.0.1:16699/api-doc', 'api-doc 随 PC 前端');
  assertEq(r.urls.admin, 'http://127.0.0.1:16699/service-addresses', '管理页随 PC 前端');
})();

section('NAS：前端 27788 可达，H5 借本机网关并说明打开的是本机库');
(function () {
  var r = E.resolveEntries({ entryProfile: 'nas' });
  assertEq(r.urls.web, 'http://192.168.10.222:27788/', 'web = 27788（非后端 26690）');
  assertEq(r.urls.apiDoc, 'http://192.168.10.222:27788/api-doc', 'api-doc');
  assertEq(r.urls.admin, 'http://192.168.10.222:27788/service-addresses', 'admin');
  // NAS 的 nginx 无 /h5/ 路由，同源地址会被 SPA 兜底成 PC 页（假打开），故给本机网关
  assertEq(r.urls.h5, 'http://127.0.0.1:16702/h5/', 'NAS H5 = 本机统一网关');
  assertEq(r.sources.h5, '环境预设', 'NAS H5 来源');
  assert(/NAS 栈未部署 H5/.test(r.notes.h5 || ''), 'H5 说明: ' + r.notes.h5);
  assert(/本机库/.test(r.notes.h5 || ''), '说明须点明打开的是本机库: ' + r.notes.h5);
})();

section('具名环境不受手填值与服务端地址影响（单一口径）');
(function () {
  var r = E.resolveEntries({
    entryProfile: 'nas',
    serverUrl: 'http://172.20.239.21:16688',
    entryWebUrl: 'http://10.1.2.3:9999/'
  });
  assertEq(r.urls.web, 'http://192.168.10.222:27788/', '环境表优先于手填');
})();

section('follow 环境保持现状口径：手填优先、其次按服务端地址推导');
(function () {
  var derived = E.resolveEntries({ entryProfile: 'follow', serverUrl: 'http://127.0.0.1:16702/api' });
  assertEq(derived.urls.web, 'http://127.0.0.1:16702/', '推导取 origin');
  assertEq(derived.urls.h5, 'http://127.0.0.1:16702/h5/', '推导 h5');
  assertEq(derived.sources.web, '自动推导', '来源标注为推导');

  var manual = E.resolveEntries({ entryProfile: 'follow', serverUrl: 'http://127.0.0.1:16702', entryH5Url: 'http://192.168.10.91:16701/h5/' });
  assertEq(manual.urls.h5, 'http://192.168.10.91:16701/h5/', '手填优先于推导');
  assertEq(manual.sources.h5, '手动设置', '来源标注为手填');
})();

section('follow 环境缺服务端地址时不编造地址');
(function () {
  var r = E.resolveEntries({ entryProfile: 'follow' });
  assertEq(r.urls.web, '', 'web 空');
  assertEq(r.urls.admin, '', 'admin 空');
  assertEq(r.urls.app, APP, 'APP 短链与服务端地址无关');
})();

section('默认环境为 follow，未指定 entryProfile 时保持旧行为');
(function () {
  var r = E.resolveEntries({ serverUrl: 'http://192.168.10.222:26690' });
  assertEq(r.profile, 'follow', '缺省 profile = follow');
  assertEq(r.urls.web, 'http://192.168.10.222:26690/', '沿用 origin 推导');
})();

section('手填值缺协议时判为无效地址');
assertEq(E.isHttpUrl('127.0.0.1:16702'), false, '缺协议 -> 无效');
assertEq(E.isHttpUrl('http://127.0.0.1:16702/'), true, 'http 有效');
assertEq(E.isHttpUrl('https://a.test/x'), true, 'https 有效');
assertEq(E.isHttpUrl(''), false, '空串无效');

section('未知环境回落到 follow 而不是崩');
(function () {
  var r = E.resolveEntries({ entryProfile: 'mars', serverUrl: 'http://127.0.0.1:16702' });
  assertEq(r.profile, 'follow', '未知环境按 follow 处理');
  assertEq(r.urls.web, 'http://127.0.0.1:16702/', '仍能推导');
})();

summary();
