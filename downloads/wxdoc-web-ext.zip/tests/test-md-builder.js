'use strict';

/*
 * tests/test-md-builder.js — WxdocMd 单元测试（node --test）
 * 覆盖：guessMediaExt 扩展名推断链、frontmatter 字段规则、blocksToHtml 媒体/表格重建、
 * buildMarkdown 端到端、setMediaPrefix、mediaFileMap、buildReport 计数与告警。
 * 依赖 tests/helpers/dom-setup.js 在 Node 中装配 Turndown + GFM 全局（与浏览器同一代码路径）。
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const { setupDom } = require('./helpers/dom-setup.js');

function freshMd() {
  setupDom();
  // 每个用例拿全新模块实例，避免 mediaPrefix 等模块级状态串场
  delete require.cache[require.resolve('../md-builder.js')];
  return require('../md-builder.js');
}

const baseSnapshot = () => ({
  title: '测试标题',
  author_name: '作者甲',
  author_handle: '',
  publish_time: '2024-05-20T10:30:00.000',
  original_url: 'https://mp.weixin.qq.com/s/abc123',
  source: 'wechat',
  blocks: [
    { kind: 'heading', level: 2, html: '<h2>小标题</h2>' },
    { kind: 'paragraph', html: '<p>正文<strong>加粗</strong>。</p>' },
    { kind: 'image', media_index: 0 }
  ],
  media: [
    { url: 'https://mmbiz.qpic.cn/mmbiz_png/x/640?wx_fmt=png', media_type: 'image', description: '配图' }
  ]
});

/* ==================== guessMediaExt ==================== */

test('guessMediaExt：wx_fmt 查询参数优先', () => {
  const W = freshMd();
  const r = W.guessMediaExt('https://mmbiz.qpic.cn/mmbiz_png/abc/640?wx_fmt=png', 'image');
  assert.equal(r.ext, 'png');
  assert.equal(r.guessed, false);
});

test('guessMediaExt：data: mime 映射', () => {
  const W = freshMd();
  assert.deepEqual(W.guessMediaExt('data:image/jpeg;base64,AAAA', 'image'), { ext: 'jpg', guessed: false });
  assert.deepEqual(W.guessMediaExt('data:video/mp4;base64,AAAA', 'video'), { ext: 'mp4', guessed: false });
  // 未知 mime 回退
  assert.deepEqual(W.guessMediaExt('data:image/tiff;base64,AAAA', 'image'), { ext: 'png', guessed: true });
});

test('guessMediaExt：路径扩展名', () => {
  const W = freshMd();
  assert.equal(W.guessMediaExt('https://example.com/a/b.mp4', 'video').ext, 'mp4');
  assert.equal(W.guessMediaExt('https://example.com/a/b.webp', 'image').ext, 'webp');
  // 过长/过短或非扩展名片段按回退处理
  assert.equal(W.guessMediaExt('https://example.com/a/index', 'image').ext, 'png');
  assert.equal(W.guessMediaExt('https://example.com/a.file.toolongext', 'image').ext, 'png');
});

test('guessMediaExt：无 URL 或不可识别时按类型回退', () => {
  const W = freshMd();
  assert.deepEqual(W.guessMediaExt('', 'video'), { ext: 'mp4', guessed: true });
  assert.deepEqual(W.guessMediaExt(null, 'image'), { ext: 'png', guessed: true });
  assert.deepEqual(W.guessMediaExt('https://mmbiz.qpic.cn/sz/0', 'video'), { ext: 'mp4', guessed: true });
});

/* ==================== buildFrontmatter ==================== */

test('buildFrontmatter：空字符串字段省略，数字字段含 0 必写', () => {
  const W = freshMd();
  const fm = W.buildFrontmatter({
    title: '标题',
    author_name: '',
    author_handle: '',
    source: 'wechat',
    publish_time: '',
    original_url: '',
    exported_at: '2026-09-23T12:00:00.000',
    image_count: 0,
    video_count: 0
  });
  const lines = fm.split('\n');
  assert.equal(lines[0], '---');
  assert.equal(lines[lines.length - 1], '---');
  assert.ok(fm.includes('title: "标题"'));
  assert.ok(!fm.includes('author_name'));
  assert.ok(!fm.includes('author_handle'));
  assert.ok(!fm.includes('publish_time'));
  assert.ok(!fm.includes('original_url'));
  assert.ok(fm.includes('source: "wechat"'));
  assert.ok(fm.includes('exported_at: "2026-09-23T12:00:00.000"'));
  assert.ok(fm.includes('image_count: 0'));
  assert.ok(fm.includes('video_count: 0'));
});

test('buildFrontmatter：特殊字符走 YAML 双引号转义', () => {
  const W = freshMd();
  const fm = W.buildFrontmatter({ title: '含"引号"和\\反斜杠', source: 'wechat', exported_at: 'x', image_count: 1, video_count: 0 });
  assert.ok(fm.includes('title: "含\\"引号\\"和\\\\反斜杠"'), fm);
});

test('buildFrontmatter：exported_at 缺省时自动填充墙钟时间', () => {
  const W = freshMd();
  const fm = W.buildFrontmatter({ title: 't', image_count: 1, video_count: 0 });
  assert.match(fm, /exported_at: "\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}"/);
});

/* ==================== blocksToHtml ==================== */

test('blocksToHtml：图片块替换为 images/image_N 相对路径', () => {
  const W = freshMd();
  const html = W.blocksToHtml(
    [{ kind: 'image', media_index: 0 }],
    [{ url: 'https://mmbiz.qpic.cn/x/640?wx_fmt=png', media_type: 'image', description: '图' }]
  );
  assert.match(html, /<img src="images\/image_0\.png" alt="图">/);
});

test('blocksToHtml：视频块输出本地文件链接 + 封面图', () => {
  const W = freshMd();
  const html = W.blocksToHtml(
    [{ kind: 'video', media_index: 0 }],
    [{ url: 'https://example.com/v.mp4', media_type: 'video', poster: 'https://mmbiz.qpic.cn/p/640?wx_fmt=jpeg' }]
  );
  assert.match(html, /<a href="videos\/video_0\.mp4">视频 · 本地文件<\/a>/);
  assert.match(html, /<img src="videos\/video_0_poster\.jpg" alt="视频封面">/);
});

test('blocksToHtml：站外视频/音频块转为链接（绕开 iframe 丢失）', () => {
  const W = freshMd();
  const html = W.blocksToHtml([
    { kind: 'video_embed', embed_url: 'https://v.qq.com/x/page/a.html' },
    { kind: 'audio', embed_url: 'https://example.com/a.mp3' }
  ], []);
  assert.match(html, /<a href="https:\/\/v\.qq\.com\/x\/page\/a\.html">视频 · 站外播放<\/a>/);
  assert.match(html, /<a href="https:\/\/example\.com\/a\.mp3">音频 · 站外播放<\/a>/);
  assert.ok(!html.includes('<iframe'));
});

test('blocksToHtml：media_index 越界时输出占位', () => {
  const W = freshMd();
  assert.equal(W.blocksToHtml([{ kind: 'image', media_index: 5 }], []), '<p>[媒体缺失]</p>');
});

test('blocksToHtml：表格用 rows 重建规范表，无 rows 回落 html', () => {
  const W = freshMd();
  const rebuilt = W.blocksToHtml([{ kind: 'table', rows: [['A', 'B'], ['1', '2']] }], []);
  assert.match(rebuilt, /<table><thead><tr><th>A<\/th><th>B<\/th><\/tr><\/thead><tbody><tr><td>1<\/td><td>2<\/td><\/tr><\/tbody><\/table>/);
  assert.match(
    W.blocksToHtml([{ kind: 'table', html: '<table><tr><td>x</td></tr></table>' }], []),
    /^<table><tr><td>x<\/td><\/tr><\/table>$/
  );
});

test('blocksToHtml：默认块取 html，缺失时回落转义文本', () => {
  const W = freshMd();
  assert.equal(W.blocksToHtml([{ kind: 'paragraph', html: '<p>a</p>' }], []), '<p>a</p>');
  assert.equal(W.blocksToHtml([{ kind: 'paragraph', text: 'a<b' }], []), '<p>a&lt;b</p>');
  assert.equal(W.blocksToHtml([{ kind: 'paragraph' }], []), '');
});

/* ==================== buildMarkdown ==================== */

test('buildMarkdown：frontmatter + 正文端到端', () => {
  const W = freshMd();
  const md = W.buildMarkdown(baseSnapshot());
  assert.match(md, /^---\n/);
  assert.ok(md.endsWith('\n'));
  assert.match(md, /title: "测试标题"/);
  assert.match(md, /author_name: "作者甲"/);
  assert.match(md, /image_count: 1/);
  assert.match(md, /video_count: 0/);
  assert.match(md, /## 小标题/);
  assert.match(md, /正文\*\*加粗\*\*。/);
  assert.match(md, /!\[配图\]\(images\/image_0\.png\)/);
});

test('buildMarkdown：空 blocks 仅输出 frontmatter', () => {
  const W = freshMd();
  const md = W.buildMarkdown({ title: 't', source: 'wechat', blocks: [], media: [] });
  assert.match(md, /^---\n/);
  assert.ok(md.trim().endsWith('---'));
  assert.ok(!md.includes('##'));
});

test('buildMarkdown：GFM 表格与代码块转换', () => {
  const W = freshMd();
  const md = W.buildMarkdown({
    title: 't',
    source: 'wechat',
    blocks: [
      { kind: 'table', rows: [['列一', '列二'], ['a', 'b']] },
      { kind: 'code', html: '<pre><code>const a = 1;</code></pre>' }
    ],
    media: []
  });
  assert.match(md, /\| 列一 \| 列二 \|\n\| --- \| --- \|\n\| a \| b \|/);
  assert.match(md, /```\nconst a = 1;\n```/);
});

/* ==================== mediaPrefix ==================== */

test('setMediaPrefix：下载通道前缀影响 md 引用与文件清单', () => {
  const W = freshMd();
  assert.equal(W.getMediaPrefix(), '');
  const snap = baseSnapshot();
  const before = W.buildMarkdown(snap);
  assert.ok(before.includes('(images/image_0.png)'));

  W.setMediaPrefix('测试文章_media');
  assert.equal(W.getMediaPrefix(), '测试文章_media/');
  const after = W.buildMarkdown(snap);
  assert.ok(after.includes('(测试文章_media/images/image_0.png)'));
  assert.equal(W.mediaFileMap(snap)[0].rel_path, '测试文章_media/images/image_0.png');
  const report = W.buildReport(snap, '/tmp/j');
  assert.equal(report.files[1].path, '/tmp/j/测试文章_media/images/image_0.png');

  // 反斜杠归一化与空值复位
  W.setMediaPrefix('a\\b');
  assert.equal(W.getMediaPrefix(), 'a/b/');
  W.setMediaPrefix('');
  assert.equal(W.getMediaPrefix(), '');
});

/* ==================== mediaFileMap ==================== */

test('mediaFileMap：视频带 poster 映射，图片不带', () => {
  const W = freshMd();
  const map = W.mediaFileMap({
    media: [
      { url: 'https://mmbiz.qpic.cn/a/0?wx_fmt=gif', media_type: 'image' },
      { url: 'https://e.com/v.mov', media_type: 'video', poster: 'https://mmbiz.qpic.cn/p/0?wx_fmt=webp' }
    ]
  });
  assert.deepEqual(map[0], { index: 0, kind: 'image', rel_path: 'images/image_0.gif', url: 'https://mmbiz.qpic.cn/a/0?wx_fmt=gif' });
  assert.equal(map[1].kind, 'video');
  assert.equal(map[1].rel_path, 'videos/video_1.mov');
  assert.equal(map[1].poster_rel_path, 'videos/video_1_poster.webp');
  assert.equal(map[1].poster_url, 'https://mmbiz.qpic.cn/p/0?wx_fmt=webp');
});

/* ==================== buildReport ==================== */

test('buildReport：计数、文件清单与告警', () => {
  const W = freshMd();
  const snap = baseSnapshot();
  snap.blocks.push({ kind: 'video', media_index: 1 });
  snap.media.push({ url: 'https://e.com/v.mp4', media_type: 'video', poster: 'https://mmbiz.qpic.cn/p/0?wx_fmt=jpeg' });
  snap.warnings = ['提取期告警'];

  const r = W.buildReport(snap, '/jobs/abc');
  assert.equal(r.job_dir, '/jobs/abc');
  assert.equal(r.title, '测试标题');
  assert.equal(r.markdown_file, '/jobs/abc/article.md');
  assert.deepEqual(r.counts.blocks, 4);
  assert.deepEqual(r.counts.images, 1);
  assert.deepEqual(r.counts.videos, 1);
  assert.ok(r.counts.chars > 0);
  assert.deepEqual(r.files.map((f) => f.kind), ['markdown', 'image', 'video', 'poster']);
  assert.deepEqual(r.files.map((f) => f.path), [
    '/jobs/abc/article.md',
    '/jobs/abc/images/image_0.png',
    '/jobs/abc/videos/video_1.mp4',
    '/jobs/abc/videos/video_1_poster.jpg'
  ]);
  assert.ok(r.warnings.includes('提取期告警'));
  assert.ok(!r.warnings.some((w) => w.includes('扩展名')));
});

test('buildReport：无 jobDir 时用相对路径，拼接各类告警', () => {
  const W = freshMd();
  const r = W.buildReport(
    {
      title: '',
      original_url: '',
      blocks: [],
      media: [{ url: 'https://mmbiz.qpic.cn/sz/0', media_type: 'image' }],
      warnings: []
    },
    ''
  );
  assert.equal(r.job_dir, '');
  assert.equal(r.markdown_file, 'article.md');
  assert.equal(r.files[1].path, 'images/image_0.png');
  assert.ok(r.warnings.some((w) => w.includes('无法识别扩展名')));
  assert.ok(r.warnings.includes('正文为空，未生成正文内容'));
  assert.ok(r.warnings.includes('未找到文章标题'));
  assert.ok(r.warnings.includes('未找到原文链接'));
});

/* ==================== UMD 与杂项 ==================== */

test('UMD：全局 WxdocMd 与 module.exports 一致', () => {
  const W = freshMd();
  const mod = require('../md-builder.js');
  assert.equal(typeof globalThis.WxdocMd, 'object');
  assert.equal(globalThis.WxdocMd.buildMarkdown, W.buildMarkdown);
  assert.equal(mod.buildMarkdown, W.buildMarkdown);
  assert.equal(typeof mod.buildReport, 'function');
});

test('wallClockNow：本地墙钟格式 yyyy-MM-ddTHH:mm:ss.SSS', () => {
  const W = freshMd();
  const now = W.wallClockNow();
  assert.match(now, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}$/);
  // 与本地时间差在秒级以内（避免跨秒边界的偶发不等）
  assert.ok(Math.abs(Date.parse(now) - Date.now()) < 2000, 'wallClockNow 应接近当前本地时间');
});

test('buildMarkdown：容错 null / 缺字段输入', () => {
  const W = freshMd();
  const md = W.buildMarkdown({});
  assert.match(md, /^---\n/);
  assert.equal(typeof W.buildMarkdown(null), 'string');
  assert.equal(W.blocksToHtml(null, null), '');
});
