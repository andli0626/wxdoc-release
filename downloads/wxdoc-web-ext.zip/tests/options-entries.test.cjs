// 真实 Chrome 加载未打包扩展，验证设置页「访问入口」分区的推导、打开与持久化
// 说明：Playwright 的请求拦截对 chrome.tabs.create 新建的标签页不生效，
// 因此入口目标统一用本机 echo HTTP 服务（响应体回显请求路径）来断言真实打开的页面。
'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const {chromium} = require('../../wxdoc-desk/tests/node_modules/playwright');
const extension = path.resolve(__dirname, '..');

// 浏览器发现统一走 helpers/chrome-path.js：headless 下只有 Playwright 自带 chromium 完整构建会加载 MV3 扩展
const {defaultChrome} = require('./helpers/chrome-path');
const executable = defaultChrome();

// 回显请求路径的本地服务，充当"统一网关"：/ = PC Web，/h5/ = H5，/api-doc、/service-addresses 同理
async function startEchoServer(t) {
 const server = http.createServer((req, res) => {
  res.setHeader('content-type', 'text/html; charset=utf-8');
  res.end(`<!doctype html><meta charset="utf-8"><title>entry</title><h1 id="echo">${req.url}</h1>`);
 });
 await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
 // 标签页与服务端之间是 keep-alive 长连接：只调 server.close() 会等连接自然断开而永不回调
 t.after(() => { server.closeAllConnections(); return new Promise((resolve) => server.close(resolve)); });
 return `http://127.0.0.1:${server.address().port}`;
}

async function openOptions(t, prefix, apiBase) {
 const profile = await fs.mkdtemp(path.join(os.tmpdir(), `${prefix}-`));
 const context = await chromium.launchPersistentContext(profile, {
  ...(executable ? {executablePath: executable} : {}),
  headless: true,
  args: [`--disable-extensions-except=${extension}`, `--load-extension=${extension}`]
 });
 t.after(async () => { await context.close(); await fs.rm(profile, {recursive: true, force: true}); });
 const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 const page = await context.newPage();
 const errors = [];
 page.on('pageerror', e => errors.push(e.message));
 await page.goto(`chrome-extension://${new URL(worker.url()).host}/options.html`);
 await page.waitForSelector('#entrySection');
 if (apiBase) await page.fill('#serverUrl', apiBase);
 t.after(() => assert.deepEqual(errors, [], 'options 页不应有脚本错误'));
 return {context, page};
}

const autoText = (page, key) =>
 page.evaluate(k => document.getElementById(`entry${k.charAt(0).toUpperCase() + k.slice(1)}Auto`).textContent, key);
const openBtn = key => `.entry-row[data-entry="${key}"] .entry-open`;

// 点击"打开"：返回新标签页（已加载完成）
async function clickOpen(context, page, key) {
 const [tab] = await Promise.all([context.waitForEvent('page'), page.click(openBtn(key))]);
 await tab.waitForLoadState('load');
 return tab;
}

async function openedPath(context, page, key) {
 const tab = await clickOpen(context, page, key);
 return tab.locator('#echo').textContent();
}

test('服务端地址自动推导 Web/H5/API 文档/服务地址入口，点击各自打开对应页面', async t => {
 const base = await startEchoServer(t);
 const {context, page} = await openOptions(t, 'WWCN-options-auto-', `${base}/api`);

 assert.equal(await autoText(page, 'web'), `自动推导 · 将打开 ${base}/`);
 assert.equal(await autoText(page, 'h5'), `自动推导 · 将打开 ${base}/h5/`);

 assert.equal(await openedPath(context, page, 'web'), '/');
 assert.match(await page.textContent('#entryStatus'), new RegExp(`已在新标签页打开 ${base}/$`));
 assert.equal(await openedPath(context, page, 'h5'), '/h5/');
 assert.equal(await openedPath(context, page, 'apiDoc'), '/api-doc');
 assert.equal(await openedPath(context, page, 'admin'), '/service-addresses');
});

test('手机 APP 下载入口默认蒲公英固定短链，可手动改为自有地址后立即打开', async t => {
 const base = await startEchoServer(t);
 const {context, page} = await openOptions(t, 'WWCN-options-app-', `${base}/api`);

 // 默认短链与服务端地址无关：点击应开新标签并在状态栏回显目标地址
 const statusBefore = await page.textContent('#entryStatus');
 assert.equal(await autoText(page, 'app'), '内置默认 · 将打开 https://www.pgyer.com/wxdoc');
 const tabsBefore = context.pages().length;
 const [pgyerTab] = await Promise.all([context.waitForEvent('page'), page.click(openBtn('app'))]);
 assert.ok(pgyerTab, 'APP 入口应新建标签页');
 assert.equal(context.pages().length, tabsBefore + 1, 'APP 入口应新建标签页');
 assert.match(await page.textContent('#entryStatus'), /已在新标签页打开 https:\/\/www\.pgyer\.com\/wxdoc$/);
 assert.notEqual(await page.textContent('#entryStatus'), statusBefore);

 // 手填安装地址（与桌面端可改短链的能力对齐）后优先使用手填值
 await page.fill('#entryAppUrl', `${base}/download.apk`);
 assert.equal(await autoText(page, 'app'), `手动设置 · 将打开 ${base}/download.apk`);
 assert.equal(await openedPath(context, page, 'app'), '/download.apk');
});

test('H5 入口手动地址优先于推导，保存后重载仍生效', async t => {
 // 用 manifest 已授权的 origin（localhost:17321）：保存路径会申请 host 权限，
 // 无头环境下无人应答新 origin 的授权弹窗，会让保存一直挂起（真机由用户点允许）
 const base = 'http://localhost:17321';
 const {page} = await openOptions(t, 'WWCN-options-manual-', base);
 await page.fill('#entryH5Url', `${base}/m/`);
 assert.equal(await autoText(page, 'h5'), `手动设置 · 将打开 ${base}/m/`);

 await page.click('#save');
 await page.waitForFunction(() => document.getElementById('msg').textContent.includes('已保存'), null, {timeout: 10000});
 await page.reload();
 await page.waitForSelector('#entrySection');
 assert.equal(await page.inputValue('#entryH5Url'), `${base}/m/`);
 assert.equal(await page.inputValue('#serverUrl'), base);
 assert.equal(await autoText(page, 'h5'), `手动设置 · 将打开 ${base}/m/`);
 assert.equal(await autoText(page, 'web'), `自动推导 · 将打开 ${base}/`);
});

test('未填服务端地址时页面入口给出提示，点击不打开无效地址', async t => {
 const base = await startEchoServer(t);
 const {context, page} = await openOptions(t, 'WWCN-options-empty-', base);
 await page.fill('#serverUrl', '');
 assert.match(await autoText(page, 'web'), /未填写服务端地址/);
 assert.match(await autoText(page, 'apiDoc'), /未填写服务端地址/);

 const tabsBefore = context.pages().length;
 await page.click(openBtn('web'));
 assert.match(await page.textContent('#entryStatus'), /地址无效/);
 await page.waitForTimeout(300);
 assert.equal(context.pages().length, tabsBefore, '地址无效时不应开新标签页');
});

test('入口地址缺少协议时保存被拦截且不落库', async t => {
 const base = await startEchoServer(t);
 const {page} = await openOptions(t, 'WWCN-options-invalid-', `${base}/api`);
 await page.fill('#entryWebUrl', '127.0.0.1:16702');
 await page.click('#save');
 assert.match(await page.textContent('#msg'), /http:\/\/ 或 https:\/\//);
 await page.reload();
 await page.waitForSelector('#entrySection');
 assert.equal(await page.inputValue('#entryWebUrl'), '', '非法地址不应写入存储');
});

// ===== 环境集（entries.js PROFILES）=====
const entryInputDisabled = (page, key) =>
 page.evaluate(k => document.getElementById(`entry${k.charAt(0).toUpperCase() + k.slice(1)}Url`).disabled, key);

test('NAS 环境按前端端口 27788 给出入口，未部署的 H5 借本机网关并说明来源', async t => {
 const {context, page} = await openOptions(t, 'WWCN-options-nas-', 'http://192.168.10.222:26690');
 await page.selectOption('#entryProfile', 'nas');

 // 后端 26690 不是页面入口：环境表须给前端 27788，而不是跟着服务端地址推导
 assert.equal(await autoText(page, 'web'), '环境预设 · 将打开 http://192.168.10.222:27788/');
 assert.equal(await autoText(page, 'admin'), '环境预设 · 将打开 http://192.168.10.222:27788/service-addresses');
 // NAS 未部署 H5，入口指向本机统一网关，且必须写明打开的是本机库
 assert.match(await autoText(page, 'h5'), /将打开 http:\/\/127\.0\.0\.1:16702\/h5\//);
 assert.match(await autoText(page, 'h5'), /NAS 栈未部署 H5/);

 // 具名环境下手填框禁用，避免设置页与 popup 打开不同页面
 assert.equal(await entryInputDisabled(page, 'web'), true, '具名环境应禁用入口手填框');

 const tabsBefore = context.pages().length;
 await page.click(openBtn('h5'));
 assert.match(await page.textContent('#entryStatus'), /已在新标签页打开 http:\/\/127\.0\.0\.1:16702\/h5\//);
 await page.waitForTimeout(300);
 assert.equal(context.pages().length, tabsBefore + 1, 'H5 入口应开出新标签');
});

test('环境选择落库，重载后仍指向所选环境且不受服务端地址影响', async t => {
 // 同 H5 手填用例：走 manifest 已授权的 origin，否则保存时的 host 权限弹窗在无头下无人应答
 const {page} = await openOptions(t, 'WWCN-options-profile-', 'http://localhost:17321/api');
 await page.selectOption('#entryProfile', 'local-gw');
 assert.equal(await autoText(page, 'web'), '环境预设 · 将打开 http://127.0.0.1:16702/');

 await page.click('#save');
 await page.waitForFunction(() => document.getElementById('msg').textContent.includes('已保存'), null, {timeout: 10000});
 await page.reload();
 await page.waitForSelector('#entrySection');
 assert.equal(await page.inputValue('#entryProfile'), 'local-gw');
 assert.equal(await autoText(page, 'h5'), '环境预设 · 将打开 http://127.0.0.1:16702/h5/');
 assert.equal(await entryInputDisabled(page, 'h5'), true);
});
