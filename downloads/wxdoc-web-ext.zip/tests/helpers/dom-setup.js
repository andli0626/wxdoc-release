'use strict';
// Node 测试环境装配。
// vendor/ 下的 turndown 与 turndown-plugin-gfm 是浏览器全局脚本形态（非 UMD/CJS），
// 直接 require 只会得到空对象。这里用 jsdom 提供 window/DOMParser，
// 再以 vm.runInThisContext 执行脚本，使 TurndownService / turndownPluginGfm
// 落到 globalThis，供被测模块以「浏览器全局」方式消费。
// jsdom 仅存在于 devDependencies，不进入扩展产物（manifest 不引用 node_modules）。
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..', '..');

class JsdomDOMParser {
  constructor() {
    this.dom = new JSDOM('');
  }
  parseFromString(html) {
    this.dom = new JSDOM(String(html == null ? '' : html));
    return this.dom.window.document;
  }
}

function setupDom() {
  if (!globalThis.window) globalThis.window = globalThis;
  if (!globalThis.DOMParser) globalThis.DOMParser = JsdomDOMParser;
  if (!globalThis.TurndownService) {
    vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'vendor/turndown.js'), 'utf8'), { filename: 'vendor/turndown.js' });
  }
  if (!globalThis.turndownPluginGfm) {
    vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'vendor/turndown-plugin-gfm.js'), 'utf8'), { filename: 'vendor/turndown-plugin-gfm.js' });
  }
  return globalThis;
}

module.exports = { setupDom, ROOT };
