// 跨平台找出"能加载 MV3 扩展"的 Chromium 可执行文件。
// 关键坑：系统安装的 Chrome/Edge 在 headless 下不加载 --load-extension，
// 只有 Playwright 自带的 chromium 完整构建（非 headless_shell）可以，
// 所以优先取 ms-playwright 缓存里的构建目录，系统浏览器仅作品最后兜底。
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

function playwrightRoots() {
  if (process.platform === 'darwin') {
    return [path.join(os.homedir(), 'Library', 'Caches', 'ms-playwright')];
  }
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return [path.join(local, 'ms-playwright')];
  }
  return [path.join(os.homedir(), '.cache', 'ms-playwright')];
}

// 每个构建目录里的相对可执行路径，按平台顺序尝试
function relativeBins() {
  if (process.platform === 'darwin') {
    return ['chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
      'chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
      'chrome-mac/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'];
  }
  if (process.platform === 'win32') {
    return ['chrome-win64/chrome.exe', 'chrome-win/chrome.exe', 'chrome-win-x64/chrome.exe'];
  }
  return ['chrome-linux64/chrome', 'chrome-linux/chrome'];
}

function systemBins() {
  if (process.platform === 'darwin') {
    return ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
  }
  if (process.platform === 'win32') {
    const dirs = [process.env['PROGRAMFILES'], process.env['PROGRAMFILES(X86)'],
      process.env['LOCALAPPDATA']].filter(Boolean);
    const out = [];
    for (const d of dirs) {
      out.push(path.join(d, 'Google', 'Chrome', 'Application', 'chrome.exe'));
      out.push(path.join(d, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
    }
    return out;
  }
  return ['/usr/bin/google-chrome', '/usr/bin/chromium-browser', '/usr/bin/chromium'];
}

function defaultChrome() {
  if (process.env.WWCN_TEST_CHROME) return process.env.WWCN_TEST_CHROME;
  for (const root of playwrightRoots()) {
    let builds = [];
    try {
      builds = fs.readdirSync(root).filter((d) => /^chromium-\d+$/.test(d))
        .sort((a, b) => Number(b.split('-')[1]) - Number(a.split('-')[1]));
    } catch { }
    for (const build of builds) {
      for (const rel of relativeBins()) {
        const bin = path.join(root, build, ...rel.split('/'));
        try { if (fs.existsSync(bin)) return bin; } catch { }
      }
    }
  }
  for (const bin of systemBins()) {
    try { if (fs.existsSync(bin)) return bin; } catch { }
  }
  return '';
}

module.exports = {defaultChrome};
