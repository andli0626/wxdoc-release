'use strict';
/**
 * tests/test-desktop-proxy.js — v1 兼容代理（桌面桥）回归测试
 *
 * 背景：v2.0.0 重写 background 后，content.js 浮动按钮桌面端链路
 * （download/recent/task/retry/deleteTask/clearFinished）与 popup 的 health
 * 均无接收端 → 本测试锁定代理路由、桥响应透传与离线口径。
 */
var fs = require('fs');
var path = require('path');
var T = require('./test-helpers');
var section = T.section;
var assert = T.assert;
var assertEq = T.assertEq;

var bgSource = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

require('../shared.js');
require('../sync-channel.js');
require('../outbox.js');

var BASE = 'http://127.0.0.1:17321';

function mkResp(body, status) {
  return {
    ok: status >= 200 && status < 300, status: status,
    json: function () { return Promise.resolve(body); },
    text: function () { return Promise.resolve(JSON.stringify(body)); }
  };
}

function freshContext(settings, fetchImpl) {
  var ctxData = Object.assign({
    mode: 'desktop',
    baseUrl: BASE,
    token: '',
    serverUrl: '',
    apiToken: '',
    autoSync: true
  }, settings || {});
  var fetchLog = [];
  var fetchTable = {};

  globalThis.self = globalThis;
  globalThis.chrome = {
    runtime: {
      id: 'ext', lastError: null,
      onMessage: { addListener: function () {} },
      onInstalled: { addListener: function () {} }
    },
    storage: {
      local: {
        get: function (k, cb) {
          var r = {};
          if (k && typeof k === 'object' && !Array.isArray(k)) {
            Object.keys(k).forEach(function (key) { r[key] = (key in ctxData) ? ctxData[key] : k[key]; });
          }
          if (typeof cb === 'function') cb(r);
          return Promise.resolve(r);
        },
        set: function (items) { Object.assign(ctxData, items); return Promise.resolve(); }
      }
    },
    tabs: { sendMessage: function () { return Promise.resolve(); } },
    commands: { onCommand: { addListener: function () {} } },
    alarms: { create: function () {}, onAlarm: { addListener: function () {} } },
    downloads: { download: function (o, cb) { if (cb) cb(1); return Promise.resolve(1); } }
  };

  globalThis.fetch = fetchImpl || function (u, o) {
    fetchLog.push({ url: u, opts: o });
    if (fetchTable[u]) {
      var e = fetchTable[u];
      return Promise.resolve(mkResp(e.body, e.status));
    }
    return mkResp({ error: 'not found' }, 404);
  };

  var wrapped = '(function(chrome,fetch,setTimeout,Blob,URL,console,JSON){\n' + bgSource + '\n})';
  var fn = new Function('return ' + wrapped)();
  fn(globalThis.chrome, globalThis.fetch, setTimeout, globalThis.Blob, globalThis.URL, console, JSON);

  return {
    data: ctxData, fetchLog: fetchLog,
    setFetch: function (url, body, status) { fetchTable[url] = { body: body, status: status }; },
    api: globalThis.WxdocBackground
  };
}

function send(ctx, msg) {
  return new Promise(function (resolve) {
    ctx.api.handleMessage(msg, { tab: { id: 3 } }, resolve);
  });
}

async function main() {
  section('A. recent：桥裸数组透传给面板');
  await (async function () {
    var ctx = freshContext();
    var tasks = [{ id: 't1', status: 'running', title: '文章一', progress: 40 }];
    ctx.setFetch(BASE + '/api/tasks/recent', tasks, 200);
    var resp = await send(ctx, { type: 'recent' });
    assert(resp.ok, 'recent 响应 ok');
    assertEq(resp.data.length, 1, '任务数组透传');
    assertEq(resp.data[0].id, 't1', '任务字段完整');
  })();

  section('B. download：提交建单（202 裸 JSON）');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(BASE + '/api/download', { taskId: 't9', status: 'queued', duplicate: false }, 202);
    var resp = await send(ctx, { type: 'download', url: 'https://mp.weixin.qq.com/s/abc' });
    assert(resp.ok, 'download 响应 ok');
    assertEq(resp.data.taskId, 't9', 'taskId 透传（content.js 据此轮询）');
    var req = ctx.fetchLog.filter(function (r) { return r.url === BASE + '/api/download'; })[0];
    var body = JSON.parse(req.opts.body);
    assertEq(body.url, 'https://mp.weixin.qq.com/s/abc', '提交带 url');
    assertEq(body.autoSync, true, 'autoSync 取自设置');
  })();

  section('C. duplicate：无 taskId 的重复响应');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(BASE + '/api/download', { taskId: null, status: 'duplicate', duplicate: true }, 200);
    var resp = await send(ctx, { type: 'download', url: 'https://mp.weixin.qq.com/s/abc' });
    assert(resp.ok && resp.data.duplicate === true && !resp.data.taskId, '重复口径透传');
  })();

  section('D. 任务操作：retry/delete/clearFinished');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(BASE + '/api/tasks/t1/retry', { ok: true }, 200);
    ctx.setFetch(BASE + '/api/tasks/t1', { ok: true }, 200);
    ctx.setFetch(BASE + '/api/tasks/clear-finished', { ok: true }, 200);
    var r1 = await send(ctx, { type: 'retry', taskId: 't1' });
    var r2 = await send(ctx, { type: 'deleteTask', taskId: 't1' });
    var r3 = await send(ctx, { type: 'clearFinished' });
    assert(r1.ok && r2.ok && r3.ok, '三个操作均成功（DELETE 走同一路径需区分方法）');
    var del = ctx.fetchLog.filter(function (r) { return r.url === BASE + '/api/tasks/t1' && r.opts.method === 'DELETE'; });
    assertEq(del.length, 1, 'deleteTask 发 DELETE');
    var retry = ctx.fetchLog.filter(function (r) { return r.url === BASE + '/api/tasks/t1/retry'; })[0];
    assertEq(retry.opts.method, 'POST', 'retry 发 POST');
  })();

  section('E. 桥业务错误：409 → desktop_http');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(BASE + '/api/tasks/t1/retry', { error: '任务不可重试' }, 409);
    var resp = await send(ctx, { type: 'retry', taskId: 't1' });
    assert(!resp.ok, '失败响应');
    assertEq(resp.code, 'desktop_http', 'code=desktop_http');
    assertEq(resp.error, '任务不可重试', '桥 error 文案透传');
  })();

  section('F. 客户端未启动 → offline + v1 离线文案');
  await (async function () {
    var ctx = freshContext({}, function () { return Promise.reject(new Error('Connection refused')); });
    var resp = await send(ctx, { type: 'recent' });
    assert(!resp.ok, '失败响应');
    assertEq(resp.code, 'offline', 'code=offline（content.js isOffline 判定口径）');
    assert(/未检测到微文存阅客户端/.test(resp.error), 'v1 离线文案：' + resp.error);
  })();

  section('G. health：popup 桌面端状态展示');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(BASE + '/health', { ok: true, status: 'online', version: '2.3.1' }, 200);
    var resp = await send(ctx, { type: 'health' });
    assert(resp.ok, 'health ok');
    assertEq(resp.data.version, '2.3.1', 'popup 读 data.version');
  })();

  section('H. 未知消息仍返回 unknown_type');
  await (async function () {
    var ctx = freshContext();
    var resp = await send(ctx, { type: 'bogus' });
    assert(!resp.ok && resp.code === 'unknown_type', '未知类型兜底不变');
  })();

  T.summary();
}

main().catch(function (e) { console.log('MAIN.ERR ' + (e && e.stack || e)); process.exit(1); });
