// options.js preset linkage logic tests
'use strict';
var T = require('./test-helpers');
var section = T.section, assert = T.assert, assertEqual = T.assertEq, summary = T.summary;

var SERVER_PRESETS = [
  { key: 'mac-epoint', label: 'mac-epoint', url: 'http://172.20.239.21:16688' },
  { key: 'mac-visitor', label: 'mac-visitor', url: 'http://172.20.237.106:16688' },
  { key: 'mac-home',   label: 'mac-home',   url: 'http://192.168.10.91:16688' },
  { key: 'mac-zero',   label: 'mac-zero',   url: 'http://172.26.199.169:16688' },
  { key: 'hw-epoint',  label: '华为-epoint', url: 'http://172.20.244.228:16688' },
  { key: 'hw-zero',    label: '华为-zero',  url: 'http://172.26.172.248:16688' },
  { key: 'oldmac-zero', label: '旧mac-zero', url: 'http://172.26.98.131:16688' },
  { key: 'nas-local',  label: 'NAS-local',  url: 'http://192.168.10.222:26690' },
  { key: 'nas-zero',   label: 'NAS-zero',   url: 'http://172.26.98.131:16688' },
  { key: 'local',      label: '本机调试',    url: 'http://127.0.0.1:16688' },
  { key: 'emulator',    label: '模拟器',      url: 'http://10.0.0.2:16688' },
  { key: 'nas-latest', label: 'NAS-latest',  url: 'http://192.168.10.222:26690' },
  { key: 'web',        label: 'Web端',       url: 'http://192.168.10.222:27788' }
];

function matchPreset(url) {
  var norm = (url || '').replace(/\/$/, '').toLowerCase();
  if (!norm) return '__custom__';
  for (var i = 0; i < SERVER_PRESETS.length; i++) {
    if (SERVER_PRESETS[i].url.replace(/\/$/, '').toLowerCase() === norm) {
      return SERVER_PRESETS[i].key;
    }
  }
  return '__custom__';
}

section('matchPreset: exact match');
assertEqual(matchPreset('http://172.20.239.21:16688'), 'mac-epoint', 'match mac-epoint');
assertEqual(matchPreset('http://172.20.246.65:16689'), '__custom__', 'dead mac-yp preset removed -> custom');
assertEqual(matchPreset('http://172.20.246.65:16699'), '__custom__', 'old mac-epoint preset removed -> custom');
assertEqual(matchPreset('http://172.20.239.21:16688/'), 'mac-epoint', 'trailing slash tolerant');
assertEqual(matchPreset('HTTP://172.20.239.21:16688'), 'mac-epoint', 'case insensitive');

section('matchPreset: unknown / empty');
assertEqual(matchPreset('http://10.1.2.3:9999'), '__custom__', 'unknown URL -> custom');
assertEqual(matchPreset(''), '__custom__', 'empty string -> custom');
assertEqual(matchPreset(undefined), '__custom__', 'undefined -> custom');
assertEqual(matchPreset(null), '__custom__', 'null -> custom');

section('matchPreset: remaining presets');
assertEqual(matchPreset('http://192.168.10.37:16688'), '__custom__', 'old mac-home preset removed -> custom');
// nas-local 与 nas-latest 因 cc69c48 把 nas-local 改到 26690 而指向同一地址，
// matchPreset 按列表顺序取第一个，回填下拉框时显示 NAS-local（两个选项点出来的地址相同）。
assertEqual(matchPreset('http://192.168.10.222:26690'), 'nas-local', 'duplicate NAS url resolves to first preset');
assertEqual(matchPreset('http://192.168.10.222:27788'), 'web', 'match Web');
assertEqual(matchPreset('http://127.0.0.1:16688'), 'local', 'match local');
assertEqual(matchPreset('http://192.168.10.91:16688'), 'mac-home', 'match mac-home');
assertEqual(matchPreset('http://10.0.0.2:16688'), 'emulator', 'match emulator');

section('preset list contract');
assertEqual(SERVER_PRESETS.length, 13, 'preset count = 13');
SERVER_PRESETS.forEach(function (p) {
  assert(p.key && p.label && p.url, 'preset ' + (p.key || '?') + ' has all 3 fields');
  assert(/^https?:\/\/[^:\/]+:\d+$/.test(p.url), 'preset ' + p.key + ' url format valid');
});

// ---- 访问入口推导：直接引用扩展实际加载的 entries.js，避免测试与实现两套口径 ----
var deriveEntryUrls = require('../entries.js').deriveEntryUrls;
var DEFAULT_APP_INSTALL_URL = 'https://www.pgyer.com/wxdoc';

section('deriveEntryUrls: 统一网关地址同源直达三端');
(function () {
  var e = deriveEntryUrls('http://127.0.0.1:16702');
  assertEqual(e.web, 'http://127.0.0.1:16702/', 'web = origin');
  assertEqual(e.h5, 'http://127.0.0.1:16702/h5/', 'h5 = origin + /h5/');
  assertEqual(e.apiDoc, 'http://127.0.0.1:16702/api-doc', 'api-doc');
  assertEqual(e.admin, 'http://127.0.0.1:16702/service-addresses', 'service-addresses');
})();

section('deriveEntryUrls: 只取 origin，忽略路径与尾部斜杠');
(function () {
  var a = deriveEntryUrls('http://172.20.239.21:16688/api/');
  assertEqual(a.web, 'http://172.20.239.21:16688/', 'path stripped');
  var b = deriveEntryUrls('https://example.com:8443');
  assertEqual(b.h5, 'https://example.com:8443/h5/', 'https origin kept');
})();

section('deriveEntryUrls: APP 下载入口与服务端地址无关');
assertEqual(deriveEntryUrls('http://127.0.0.1:16702').app, DEFAULT_APP_INSTALL_URL, 'app = pgyer short link');
assertEqual(deriveEntryUrls('').app, DEFAULT_APP_INSTALL_URL, 'app kept without server url');

section('deriveEntryUrls: 空/非法服务端地址不推导页面入口');
['', undefined, null, 'not-a-url'].forEach(function (bad) {
  var e = deriveEntryUrls(bad);
  assertEqual(e.web, '', 'web empty for ' + bad);
  assertEqual(e.h5, '', 'h5 empty for ' + bad);
  assertEqual(e.apiDoc, '', 'api-doc empty for ' + bad);
  assertEqual(e.admin, '', 'admin empty for ' + bad);
});

section('chrome.storage mock');
  (function () {
  var mockStorage = T.createStorageMock({});
  mockStorage.local.set({ serverUrl: 'http://172.20.246.65:16689' }).then(function () {
    mockStorage.local.get({ serverUrl: '' }).then(function (got) {
      assertEqual(got.serverUrl, 'http://172.20.246.65:16689', 'set/get round-trip');

      mockStorage.local.get({ mode: 'desktop' }).then(function (def) {
        assertEqual(def.mode, 'desktop', 'default mode fallback');

        mockStorage.local.set({ mode: 'direct', serverUrl: 'http://x.com:1234', apiToken: 'tok-abc' }).then(function () {
          mockStorage.local.get({ mode: 'desktop', serverUrl: '', apiToken: '' }).then(function (d) {
            assertEqual(d.mode, 'direct', 'mode=direct persisted');
            assertEqual(d.serverUrl, 'http://x.com:1234', 'custom serverUrl persisted');
            assertEqual(d.apiToken, 'tok-abc', 'apiToken persisted');
            summary();
          });
        });
      });
    });
  });
})();
