'use strict';
/**
 * tests/test-direct-submit.js — 直连上传通道（directSubmit）回归测试
 *
 * 背景：v2.0.0 重写 background 时丢失了 v1 的 directSubmit 消息处理，
 * content.js 直连模式提交无接收端 → 本测试锁定消息路由、multipart 契约与错误口径。
 * 各用例通过 freshContext 重写全局 chrome/fetch，必须串行执行。
 */
var fs = require('fs');
var path = require('path');
var T = require('./test-helpers');
var section = T.section;
var assert = T.assert;
var assertEq = T.assertEq;

var bgSource = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

require('../shared.js');
require('../sync-channel.js');
require('../outbox.js');

var SUBMIT_URL = 'http://10.9.8.7:16688/api/articles/direct/submit';

function mkResp(body, status) {
  return {
    ok: status >= 200 && status < 300, status: status,
    json: function () { return Promise.resolve(body); },
    text: function () { return Promise.resolve(JSON.stringify(body)); }
  };
}

function freshContext(settings) {
  var ctxData = Object.assign({
    mode: 'direct',
    serverUrl: 'http://10.9.8.7:16688',
    apiToken: 'tok',
    baseUrl: 'http://127.0.0.1:17321',
    token: 'desk',
    deviceId: 'dev-1'
  }, settings || {});
  var fetchLog = [];
  var fetchTable = {};
  var tabSends = [];

  globalThis.self = globalThis;
  globalThis.chrome = {
    runtime: {
      id: 'ext', lastError: null,
      onMessage: { addListener: function () {} },
      onInstalled: { addListener: function () {} }
    },
    storage: {
      local: {
        get: function (k) {
          var r = {};
          if (k && typeof k === 'object' && !Array.isArray(k)) {
            Object.keys(k).forEach(function (key) { r[key] = (key in ctxData) ? ctxData[key] : k[key]; });
          }
          return Promise.resolve(r);
        },
        set: function (items) { Object.assign(ctxData, items); return Promise.resolve(); }
      }
    },
    tabs: {
      sendMessage: function (tabId, msg) {
        tabSends.push({ tabId: tabId, msg: msg });
        return Promise.resolve();
      }
    },
    commands: { onCommand: { addListener: function () {} } },
    alarms: { create: function () {}, onAlarm: { addListener: function () {} } },
    downloads: { download: function (o, cb) { if (cb) cb(1); return Promise.resolve(1); } }
  };

  globalThis.fetch = function (u, o) {
    fetchLog.push({ url: u, opts: o });
    if (fetchTable[u]) return Promise.resolve(mkResp(fetchTable[u].body, fetchTable[u].status));
    if (/mmbiz\.qpic\.cn|\.png|\.jpg/.test(u)) {
      return Promise.resolve({
        ok: true, status: 200,
        blob: function () { return Promise.resolve(new Blob([new Uint8Array(80)], { type: 'image/png' })); }
      });
    }
    return mkResp({ ok: true }, 200);
  };

  var wrapped = '(function(chrome,fetch,setTimeout,Blob,URL,console,JSON){\n' + bgSource + '\n})';
  var fn = new Function('return ' + wrapped)();
  fn(globalThis.chrome, globalThis.fetch, setTimeout, globalThis.Blob, globalThis.URL, console, JSON);

  return {
    data: ctxData, fetchLog: fetchLog, tabSends: tabSends,
    setFetch: function (url, body, status) { fetchTable[url] = { body: body, status: status }; },
    api: globalThis.WxdocBackground
  };
}

function articleContent() {
  return {
    title: '测试文章',
    author_name: '测试号',
    author_handle: '',
    publish_time: '2025-01-20T08:00:00.000',
    original_url: 'https://mp.weixin.qq.com/s/abc123',
    source: 'wechat',
    source_block_count: 2,
    blocks: [
      { kind: 'paragraph', text: '第一段', html: '<p>第一段</p>' },
      { kind: 'image', media_index: 0, text: '', html: '' }
    ],
    media: [
      { url: 'https://mmbiz.qpic.cn/pic/0.png', kind: 'image', media_type: 'image', description: null, poster: null }
    ]
  };
}

function submit(ctx, content) {
  return new Promise(function (resolve) {
    var asyncResp = ctx.api.handleMessage(
      { type: 'directSubmit', url: 'https://mp.weixin.qq.com/s/abc123', content: content || articleContent() },
      { tab: { id: 7 } },
      resolve
    );
    assert(asyncResp === true, 'directSubmit 走异步响应（返回 true）');
  });
}

async function main() {
  section('A. 正常直传：媒体下载 → multipart 上传 → R 信封解包');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(SUBMIT_URL, { code: 0, message: 'success', data: { articleId: 'a-1', savedMediaCount: 1, failedMediaCount: 0, duplicate: false } }, 200);
    var resp = await submit(ctx);
    assert(resp.ok, '响应 ok：' + JSON.stringify(resp));
    assertEq(resp.data.articleId, 'a-1', 'articleId 透传');
    assertEq(resp.data.savedMediaCount, 1, 'savedMediaCount');
    assertEq(resp.data.duplicate, false, '非重复');

    var mediaReq = ctx.fetchLog.filter(function (r) { return /mmbiz/.test(r.url); });
    assertEq(mediaReq.length, 1, '媒体已下载');
    assertEq(mediaReq[0].opts.headers.Referer, 'https://mp.weixin.qq.com/', '媒体下载带微信 Referer');

    var up = ctx.fetchLog.filter(function (r) { return r.url === SUBMIT_URL; })[0];
    assert(up, '已请求 direct/submit');
    assertEq(up.opts.method, 'POST', 'POST');
    assertEq(up.opts.headers.Authorization, 'Bearer tok', 'Bearer 令牌');
    assert(up.opts.body instanceof FormData, 'multipart FormData');
    var parts = [];
    up.opts.body.forEach(function (v, k) { parts.push(k); });
    assertEq(parts.filter(function (p) { return p === 'content'; }).length, 1, 'content part 恰一个');
    assertEq(parts.filter(function (p) { return p === 'media'; }).length, 1, 'media part（服务端 MultipartFile[] 同名绑定）');
    var payload = JSON.parse(await up.opts.body.get('content').text());
    assertEq(payload.source, 'wechat', 'source 由 host 派生');
    assertEq(payload.original_url, 'https://mp.weixin.qq.com/s/abc123', 'original_url 透传');
    assertEq(payload.media[0].index, 0, '媒体 index 配对字段');
    assertEq(payload.media[0].media_type, 'image', 'media_type 兼容字段');

    var progress = ctx.tabSends.filter(function (s) { return s.msg.type === 'directSubmitProgress'; });
    assert(progress.length >= 1, '进度消息已发内容帧');
    assertEq(progress[0].msg.url, 'https://mp.weixin.qq.com/s/abc123', '进度消息带 url（content.js 据此匹配）');
  })();

  section('B. 重复文章：duplicate 短路');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(SUBMIT_URL, { code: 0, data: { duplicate: true, articleId: 'a-dup' } }, 200);
    var resp = await submit(ctx);
    assert(resp.ok && resp.data.duplicate === true, 'duplicate 透传给 UI');
  })();

  section('C. 401 → unauthorized（UI 提示重配 Token）');
  await (async function () {
    var ctx = freshContext();
    ctx.setFetch(SUBMIT_URL, { code: 401, message: 'API Token 无效' }, 401);
    var resp = await submit(ctx);
    assert(!resp.ok, '响应失败');
    assertEq(resp.code, 'unauthorized', 'code=unauthorized');
  })();

  section('D. 网络不可达 → offline（UI 走离线提示口径）');
  await (async function () {
    var ctx = freshContext();
    var orig = globalThis.fetch;
    globalThis.fetch = function (u, o) {
      if (u === SUBMIT_URL) return Promise.reject(new Error('Failed to fetch'));
      return orig(u, o);
    };
    var resp = await submit(ctx);
    assert(!resp.ok, '响应失败');
    assertEq(resp.code, 'offline', 'code=offline');
    assert(/无法连接服务端/.test(resp.error), '错误文案含离线提示：' + resp.error);
  })();

  section('E. 未配置服务端/令牌 → config 错误');
  await (async function () {
    var ctx = freshContext({ serverUrl: '', apiToken: '' });
    var resp = await submit(ctx);
    assert(!resp.ok && resp.code === 'config', '缺配置返回 config：' + JSON.stringify(resp));
  })();

  T.summary();
}

main().catch(function (e) { console.log('MAIN.ERR ' + (e && e.stack || e)); process.exit(1); });
