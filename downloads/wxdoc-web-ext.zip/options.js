// 扩展配置默认值（默认直连模式）；访问入口相关默认值见 entries.js
const defaults = Object.assign({
  baseUrl: 'http://127.0.0.1:17321',
  token: '',
  autoSync: true,
  mode: 'direct',
  serverUrl: '',
  apiToken: ''
}, WwcnEntries.STORAGE_DEFAULTS);

const ENTRY_KEYS = WwcnEntries.ENTRY_KEYS;

// 预设服务端地址（与桌面端同步服务地址列表对齐；口径：docs/03-验收文档/36-端口矩阵与接口服务地址.md 2026-09-26 统一）
const SERVER_PRESETS = [
  { key: 'mac-epoint', label: 'mac-epoint', url: 'http://172.20.239.21:16688' },
  { key: 'mac-visitor', label: 'mac-visitor', url: 'http://172.20.237.106:16688' },
  { key: 'mac-home',   label: 'mac-home',   url: 'http://192.168.10.91:16688' },
  { key: 'mac-zero',   label: 'mac-zero',   url: 'http://172.26.199.169:16688' },
  { key: 'hw-epoint',  label: '华为-epoint', url: 'http://172.20.244.228:16688' },
  { key: 'hw-zero',    label: '华为-zero',  url: 'http://172.26.172.248:16688' },
  { key: 'oldmac-zero', label: '旧mac-zero', url: 'http://172.26.98.131:16688' },
  { key: 'nas-local',  label: 'NAS-local',  url: 'http://192.168.10.222:26690' },
  { key: 'nas-zero',   label: 'NAS-zero',   url: 'http://172.26.98.131:16688' },
  { key: 'local',      label: '本机调试',    url: 'http://127.0.0.1:16688' },
  { key: 'emulator',    label: '模拟器',      url: 'http://10.0.0.2:16688' },
  // 扩展专属附加项（非 API 直连，保留原端口）
  { key: 'nas-latest', label: 'NAS-latest',  url: 'http://192.168.10.222:26690' },
  { key: 'web',        label: 'Web端',       url: 'http://192.168.10.222:27788' }
];

// 远程内置接口服务地址列表（background 缓存于 chrome.storage.local 'serviceAddressesCache'），
// 预设下拉优先展示；SERVER_PRESETS 仅作兜底。
var remoteItems = [];
var remoteCacheMeta = null;
var SERVICE_ADDR_TTL_MS = 60 * 60 * 1000; // 缓存超过 1h 视为过期，打开设置页触发一次拉取

// 根据 URL 匹配远程列表项索引，不匹配返回 -1
function matchRemoteIndex(url) {
  var norm = (url || '').replace(/\/$/, '').toLowerCase();
  if (!norm) return -1;
  for (var i = 0; i < remoteItems.length; i++) {
    var u = String((remoteItems[i] && remoteItems[i].url) || '').replace(/\/$/, '').toLowerCase();
    if (u && u === norm) return i;
  }
  return -1;
}

// 根据 URL 匹配预设 key（远程项为 'remote:<idx>'），不匹配返回 '__custom__'
function matchPreset(url) {
  var ri = matchRemoteIndex(url);
  if (ri !== -1) return 'remote:' + ri;
  var norm = (url || '').replace(/\/$/, '').toLowerCase();
  if (!norm) return '__custom__';
  for (var i = 0; i < SERVER_PRESETS.length; i++) {
    if (SERVER_PRESETS[i].url.replace(/\/$/, '').toLowerCase() === norm) {
      return SERVER_PRESETS[i].key;
    }
  }
  return '__custom__';
}

function formatCacheTime(ts) {
  var d = new Date(Number(ts) || 0);
  function p(n) { return (n < 10 ? '0' : '') + n; }
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
    ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

// 初始化预置地址下拉框：远程服务列表优先，内置预设兜底，最后自定义
function initPresets(selectEl) {
  while (selectEl.options.length) selectEl.remove(0);
  if (remoteItems.length) {
    var gRemote = document.createElement('optgroup');
    gRemote.label = '服务列表';
    remoteItems.forEach(function (it, i) {
      var opt = document.createElement('option');
      opt.value = 'remote:' + i;
      opt.textContent = (it && (it.name || it.url)) || ('服务 ' + (i + 1));
      if (it && it.url) opt.title = it.url + (it.note ? '（' + it.note + '）' : '');
      gRemote.appendChild(opt);
    });
    selectEl.appendChild(gRemote);
  }
  var gPreset = document.createElement('optgroup');
  gPreset.label = '内置预设';
  SERVER_PRESETS.forEach(function(p) {
    var opt = document.createElement('option');
    opt.value = p.key;
    opt.textContent = p.label;
    gPreset.appendChild(opt);
  });
  selectEl.appendChild(gPreset);
  var custom = document.createElement('option');
  custom.value = '__custom__';
  custom.textContent = '自定义';
  selectEl.appendChild(custom);
}

// 申请服务端地址的动态 host 权限（optional_host_permissions）：
// 未授权时扩展页/SW 对第三方服务端地址的 fetch 走普通网页 CORS 口径，
// 私有网段地址还会触发 Chrome 的 Private Network Access 拦截（表现为 Failed to fetch）。
function ensureHostPermission(url) {
  return new Promise(function (resolve) {
    if (!chrome.permissions || !chrome.permissions.request) { resolve(false); return; }
    var origin = '';
    try { origin = new URL(url).origin; } catch (e) { resolve(false); return; }
    var perms = { origins: [origin + '/*'] };
    chrome.permissions.contains(perms, function (has) {
      if (chrome.runtime.lastError || has) { resolve(!!has); return; }
      chrome.permissions.request(perms, function (granted) {
        resolve(!!granted && !chrome.runtime.lastError);
      });
    });
  });
}

document.addEventListener('DOMContentLoaded', function() {
  var baseUrlEl = document.getElementById('baseUrl');
  var serverUrlEl = document.getElementById('serverUrl');
  var apiTokenEl = document.getElementById('apiToken');
  var modeDesktopEl = document.getElementById('modeDesktop');
  var directModeEl = document.getElementById('directMode');
  var desktopConfig = document.getElementById('desktopConfig');
  var directConfig = document.getElementById('directConfig');
  var modeHint = document.getElementById('modeHint');
  var msgEl = document.getElementById('msg');
  var connectStatus = document.getElementById('connectStatus');
  var serverPreset = document.getElementById('serverPreset');
  var autoSyncEl = document.getElementById('autoSync');
  var entryStatus = document.getElementById('entryStatus');

  // ===== 访问入口：环境集 + Web / H5 / APP 下载 / API 文档 / 服务地址管理 =====
  var entryProfileEl = document.getElementById('entryProfile');
  var entryInputs = {}, entryAutoEls = {};
  WwcnEntries.PROFILES.forEach(function (p) {
    var opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.label;
    entryProfileEl.appendChild(opt);
  });
  ENTRY_KEYS.forEach(function (key) {
    var name = key.charAt(0).toUpperCase() + key.slice(1);
    entryInputs[key] = document.getElementById('entry' + name + 'Url');
    entryAutoEls[key] = document.getElementById('entry' + name + 'Auto');
    if (entryInputs[key]) entryInputs[key].oninput = renderEntries;
  });
  entryProfileEl.onchange = renderEntries;

  // 从当前表单状态解析入口地址（输入框未保存的编辑即时生效）
  function currentEntryState() {
    var s = { entryProfile: entryProfileEl.value, serverUrl: serverUrlEl.value || '' };
    ENTRY_KEYS.forEach(function (key) {
      var input = entryInputs[key];
      if (input) s[WwcnEntries.manualKey(key)] = input.value;
    });
    return s;
  }

  // 展示每行实际会打开的地址。具名环境（本机 Docker / NAS）以环境表为准并禁用输入框，
  // 避免设置页与 popup 因手填值不同而打开不同页面。
  function renderEntries() {
    var r = WwcnEntries.resolveEntries(currentEntryState());
    var dynamic = !!(WwcnEntries.profileById(r.profile) || {}).dynamic;
    ENTRY_KEYS.forEach(function (key) {
      var autoEl = entryAutoEls[key];
      if (!autoEl) return;
      var input = entryInputs[key];
      if (input) input.disabled = !dynamic;
      autoEl.className = 'entry-auto';
      if (!r.urls[key]) {
        autoEl.className = 'entry-auto entry-none';
        autoEl.textContent = r.notes[key] ||
          (dynamic ? '未填写服务端地址，请在上方输入完整页面地址' : '该环境未提供此入口');
        return;
      }
      autoEl.textContent = r.sources[key] + ' · 将打开 ' + r.urls[key] +
        (r.notes[key] ? ' · ' + r.notes[key] : '');
    });
  }

  // 状态语义交给 CSS（data-state → 明暗两套语义色），不再往 DOM 上写死浅色系颜色
  var setMsg = function (el, text, state) {
    if (!el) return;
    el.textContent = text || '';
    el.dataset.state = state || 'idle';
  };
  (function fillVersion() {
    var el = document.getElementById('verLine');
    if (!el) return;
    try { el.textContent = '浏览器扩展 · v' + chrome.runtime.getManifest().version; } catch (e) { /* 保留静态文案 */ }
  })();

  Array.prototype.forEach.call(document.querySelectorAll('.entry-open'), function (btn) {
    btn.onclick = function () {
      var url = WwcnEntries.resolveEntries(currentEntryState()).urls[btn.getAttribute('data-entry')];
      if (!WwcnEntries.isHttpUrl(url)) {
        setMsg(entryStatus, '地址无效：请先填写服务端地址，或在入口框输入完整页面地址', 'bad');
        return;
      }
      setMsg(entryStatus, '已在新标签页打开 ' + url, 'ok');
      WwcnEntries.openEntry(url);
    };
  });

  renderEntries();

  // 初始化预设
  initPresets(serverPreset);

  // 远程服务列表提示（"来自服务列表 · 更新于 xxx"）
  function updatePresetHint() {
    var el = document.getElementById('presetSourceHint');
    if (!el) return;
    if (!remoteItems.length || !remoteCacheMeta || !remoteCacheMeta.fetchedAt) {
      el.style.display = 'none';
      el.textContent = '';
      return;
    }
    el.style.display = '';
    el.textContent = '来自服务列表 · 更新于 ' + formatCacheTime(remoteCacheMeta.fetchedAt) +
      '（共 ' + remoteItems.length + ' 项）';
  }

  // 应用缓存重渲染下拉框，并保持与当前 URL 输入框的联动选中
  function renderFromCache(cache) {
    remoteCacheMeta = cache || null;
    remoteItems = (cache && Array.isArray(cache.items)) ? cache.items : [];
    initPresets(serverPreset);
    serverPreset.value = matchPreset(serverUrlEl.value || '');
    updatePresetHint();
  }

  // 读服务地址缓存：缺失或超 1h 时让 background 拉一次，回来后重渲染
  chrome.storage.local.get({ serviceAddressesCache: null }, function (r) {
    var cache = r && r.serviceAddressesCache;
    var stale = !cache || !Array.isArray(cache.items) || !cache.fetchedAt ||
      (Date.now() - (Number(cache.fetchedAt) || 0) > SERVICE_ADDR_TTL_MS);
    renderFromCache(cache);
    if (stale) {
      try {
        chrome.runtime.sendMessage({ type: 'SERVICE_ADDRESSES_REFRESH', force: true }, function () {
          if (chrome.runtime.lastError) return;
          chrome.storage.local.get({ serviceAddressesCache: null }, function (r2) {
            renderFromCache(r2 && r2.serviceAddressesCache);
          });
        });
      } catch (e) { /* background 不可用时保留现有缓存展示 */ }
    }
  });

  // 更新 API Token 获取链接（指向服务端 /api-doc，页内顶部即令牌卡片）
  function updateTokenLink() {
    renderEntries();
    var existing = document.getElementById('tokenDocLink');
    var url = (serverUrlEl.value || '').replace(/\/$/, '');
    if (!url) return;
    var docUrl = url + '/api-doc';
    if (existing) {
      existing.href = docUrl;
    } else {
      var link = document.createElement('a');
      link.id = 'tokenDocLink';
      link.className = 'token-link';
      link.href = docUrl;
      link.target = '_blank';
      link.rel = 'noopener';
      link.textContent = '→ 点击获取 API Token（打开 Web 端 API 文档页）';
      // 挂在 Token 字段自己的说明之后；没有该说明时退回 section 里的第一条 hint
      var scope = apiTokenEl.closest ? (apiTokenEl.closest('.section') || apiTokenEl.parentNode) : apiTokenEl.parentNode;
      var hintEl = document.getElementById('apiTokenHint') || scope.querySelector('.hint');
      if (hintEl && hintEl.parentNode) {
        hintEl.parentNode.insertBefore(link, hintEl.nextSibling);
      } else {
        scope.appendChild(link);
      }
    }
  }

  // 加载设置
  chrome.storage.local.get(defaults, function(s) {
    // 旧版服务地址已迁移/废弃（mac-epoint 换机、16689 转发口下线），自动校正历史存储值
    var legacyKey = (s.serverUrl || '').replace(/\/+$/, '').toLowerCase();
    var LEGACY = ['http://172.20.246.65:16688', 'http://172.20.246.65:16689', 'http://172.20.246.65:16699'];
    if (LEGACY.indexOf(legacyKey) !== -1) {
      s.serverUrl = 'http://172.20.239.21:16688';
      chrome.storage.local.set({ serverUrl: s.serverUrl });
    }
    baseUrlEl.value = s.baseUrl;
    if (autoSyncEl) autoSyncEl.checked = s.autoSync;
    if (!s.serverUrl && SERVER_PRESETS[0]) {
      s.serverUrl = SERVER_PRESETS[0].url;
    }
    serverUrlEl.value = s.serverUrl || '';
    apiTokenEl.value = s.apiToken;
    ENTRY_KEYS.forEach(function (key) {
      var input = entryInputs[key];
      if (input) input.value = s[WwcnEntries.manualKey(key)] || '';
    });
    entryProfileEl.value = s.entryProfile || 'follow';

    // 匹配预设（仅用于选中对应下拉项，URL 框始终可编辑）
    var matchedKey = matchPreset(serverUrlEl.value);
    serverPreset.value = matchedKey;

    // 插入 API Token 帮助链接
    updateTokenLink();

    // v2 的 'backend'（直连服务端）即 v1 'direct' 语义，展示口径需同时识别
    if (s.mode === 'direct' || s.mode === 'backend') {
      directModeEl.checked = true;
      showDirectMode();
    } else {
      modeDesktopEl.checked = true;
      showDesktopMode();
    }
  });

  // 模式切换
  modeDesktopEl.onclick = function() { showDesktopMode(); };
  directModeEl.onclick = function() { showDirectMode(); };

  // 预设切换：选中预设后填充 URL，但仍可手动编辑
  serverPreset.onchange = function() {
    var key = serverPreset.value;
    if (key === '__custom__') {
      serverUrlEl.value = '';
      serverUrlEl.focus();
    } else if (key.lastIndexOf('remote:', 0) === 0) {
      var it = remoteItems[Number(key.slice(7))];
      if (it && it.url) {
        serverUrlEl.value = it.url;
        // 远程地址大概率不在静态 manifest 里：在用户手势内即时申请动态 host 权限
        ensureHostPermission(it.url);
      }
    } else {
      for (var i = 0; i < SERVER_PRESETS.length; i++) {
        if (SERVER_PRESETS[i].key === key) {
          serverUrlEl.value = SERVER_PRESETS[i].url;
          break;
        }
      }
    }
    updateTokenLink();
    updatePresetHint();
  };

  // 用户手动修改 URL 内容时，自动切到"自定义"预设
  serverUrlEl.oninput = function() {
    if (serverPreset.value !== '__custom__') {
      serverPreset.value = '__custom__';
    }
    updateTokenLink();
  };

  // 测试连接
  document.getElementById('checkConnection').onclick = async function() {
    var url = serverUrlEl.value.replace(/\/$/, '');
    var token = apiTokenEl.value.trim();
    if (!url) {
      setMsg(connectStatus, '请先填写服务端地址', 'bad');
      return;
    }
    setMsg(connectStatus, '连接中...', 'idle');
    try {
      // 先补齐该地址的 host 权限，再发探测请求
      await ensureHostPermission(url);
      // 填写了令牌：调用校验接口，可真正识别"地址可达但令牌无效"
      var r;
      if (token) {
        r = await fetch(url + '/api/auth/token/verify', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token }
        });
      } else {
        r = await fetch(url + '/api/health');
      }
      if (r.ok) {
        setMsg(connectStatus, (token ? '连接成功，Token 有效' : '地址可访问（未设置 Token，直连上传将被拒绝）') + await healthEnvLabel(url), token ? 'ok' : 'warn');
      } else if (r.status === 401) {
        setMsg(connectStatus, '地址可访问，Token 无效' + await healthEnvLabel(url), 'warn');
      } else {
        setMsg(connectStatus, '服务端返回 HTTP ' + r.status, 'bad');
      }
    } catch (e) {
      setMsg(connectStatus, '连接失败: ' + e.message, 'bad');
    }
  };

  // /api/health 的 env/db 用于标识所连环境；旧服务端无此字段时返回空串
  async function healthEnvLabel(baseUrl) {
    try {
      var h = await fetch(baseUrl + '/api/health');
      if (!h.ok) return '';
      var j = await h.json();
      var d = j && j.data;
      if (!d || !d.env) return '';
      return '（环境 ' + d.env + (d.db ? ' · 库 ' + d.db : '') + '）';
    } catch (e) {
      return '';
    }
  }

  // 保存
  document.getElementById('save').onclick = async function() {
    var config = {
      baseUrl: baseUrlEl.value.replace(/\/$/, ''),
      autoSync: autoSyncEl ? autoSyncEl.checked : true,
      mode: directModeEl.checked ? 'direct' : 'desktop',
      serverUrl: serverUrlEl.value.replace(/\/$/, ''),
      apiToken: apiTokenEl.value.trim(),
      entryProfile: entryProfileEl.value
    };
    var invalidEntry = null;
    ENTRY_KEYS.forEach(function (key) {
      var input = entryInputs[key];
      if (!input) return;
      var value = input.value.trim();
      if (value && !WwcnEntries.isHttpUrl(value)) invalidEntry = invalidEntry || key;
      config[WwcnEntries.manualKey(key)] = value;
    });
    if (invalidEntry) {
      setMsg(msgEl, '入口地址需以 http:// 或 https:// 开头（留空表示自动推导）', 'bad');
      return;
    }
    setMsg(msgEl, '', 'idle');
    if (config.mode === 'direct' && config.serverUrl) {
      // 用户手势内申请服务端 host 权限，直连上传（SW fetch）才能免 CORS/PNA 拦截
      await ensureHostPermission(config.serverUrl);
    }
    await chrome.storage.local.set(config);
    setMsg(msgEl, '已保存', 'ok');
    setTimeout(function() { setMsg(msgEl, '', 'idle'); }, 1500);
  };
});

function showDesktopMode() {
  document.getElementById('desktopConfig').style.display = '';
  document.getElementById('directConfig').classList.remove('active');
  document.getElementById('modeHint').textContent = '桌面端模式需要安装并运行微文存阅桌面客户端。';
}

function showDirectMode() {
  document.getElementById('desktopConfig').style.display = 'none';
  document.getElementById('directConfig').classList.add('active');
  document.getElementById('modeHint').textContent = '直连模式将直接在浏览器中提取文章并上传到服务端，无需桌面客户端。';
}
