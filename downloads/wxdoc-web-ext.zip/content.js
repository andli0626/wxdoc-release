(() => {
  const HOST_ID = 'WWCN-floating-host';
  if (document.getElementById(HOST_ID)) return;
  // 微信公众号文章 URL 形态（仅微信文章显示悬浮按钮）
  const WECHAT_HOST = 'mp.weixin.qq.com';
  const WECHAT_SHORT = /^\/s\/[A-Za-z0-9_-]+\/?$/;
  const WECHAT_LONG = /^\/s$/;
  let host, button, mini, notice, badge, panel, suppressClick = false, pressTimer;
  let wxRoot, label, sum, chevL, chevR, glyphs = null;
  let enabled = true, position = null, collapsed = false, phase = '', activeCount = 0, currentUrl = '', directModeEnabled = false, recentTimer, panelRefreshTimer, resetTimer, chanTimer;
  let channelName = '', channelReason = '';
  // 视频补齐（桌面通道）：打开文章页探测一次服务器缺口；扩展无 ffmpeg，补齐一律经桌面端
  let videoGap = null, videoGapCheckedUrl = '';
  const DRAG_THRESHOLD = 4, LONG_PRESS_MS = 600, EDGE_MARGIN = 16;
  const active = new Map();
  const pollTimers = new Set();
  const pollTracker = new Map(); // taskId -> {url, button}
  const IDLE_TEXT = '保存到微文存阅';
  const OFFLINE_HINT_DESKTOP = '未检测到微文存阅客户端，请先打开微文存阅客户端后重试';
  const OFFLINE_HINT_DIRECT = '无法连接服务端，请检查网络或服务端地址';
  const OFFLINE_HINT = () => directModeEnabled ? OFFLINE_HINT_DIRECT : OFFLINE_HINT_DESKTOP;
  // 通道着色口径：background UI_PROBE 探测出的实际生效通道（desktop 保持品牌绿默认值）
  const CHAN_LABEL = {backend: '直连服务端', desktop: '桌面客户端', download: '本地下载', error: '通道异常'};
  const OFFLINE_ERROR = /failed to fetch|networkerror|network error|load failed|econnrefused|未检测到微文存阅客户端|未检测到 downx 客户端|无法连接服务端/i;
  const isOffline = e => e?.code === 'offline' || OFFLINE_ERROR.test(e?.message || '');
  let offline = false;
  const send = (type, payload = {}) => chrome.runtime.sendMessage({type, ...payload});
  // 监听 background 发送的上传进度/结果
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'directSubmitProgress' && msg.url === currentUrl) {
      if (msg.phase === 'downloading') {
        display('busy','正在下载图片 (' + msg.done + '/' + msg.total + ')…','…');
      }
    } else if (msg.type === 'directSubmitDone' && msg.url === currentUrl) {
      if (button) display(msg.ok ? 'ok' : 'err', msg.message, msg.ok ? '✓' : '!');
    }
    return false;
  });
  // 平台/状态 SVG 图标，贴在品牌绿 #07c160 主色上，纯描边以适配任意背景色
  const ICON_SVG = {
    wechat: '<path d="M9.5 4C6.46 4 4 6.24 4 9.05c0 1.5.78 2.86 2 3.82-.12.5-.36 1.05-.7 1.66 1-.14 1.85-.42 2.58-.78.5.13 1.04.21 1.62.21 3.04 0 5.5-2.24 5.5-5.05C15 6.24 12.54 4 9.5 4Zm-2.2 3.6a.85.85 0 1 1 0 1.7.85.85 0 0 1 0-1.7Zm4.4 0a.85.85 0 1 1 0 1.7.85.85 0 0 1 0-1.7Z" fill="currentColor" fill-opacity=".0"/><path d="M9.5 4C6.46 4 4 6.24 4 9.05c0 1.5.78 2.86 2 3.82-.12.5-.36 1.05-.7 1.66 1-.14 1.85-.42 2.58-.78.5.13 1.04.21 1.62.21 3.04 0 5.5-2.24 5.5-5.05C15 6.24 12.54 4 9.5 4Z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="7.6" cy="8.4" r=".9" fill="currentColor"/><circle cx="11.4" cy="8.4" r=".9" fill="currentColor"/><path d="M19 11.5c-2.49 0-4.5 1.83-4.5 4.1 0 1.22.63 2.32 1.62 3.1-.1.4-.29.85-.57 1.34.8-.11 1.5-.34 2.1-.63.4.13.85.2 1.36.2 2.48 0 4.49-1.84 4.49-4.1 0-2.27-2.01-4.01-4.5-4.01Z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="17.3" cy="15.2" r=".75" fill="currentColor"/><circle cx="20.3" cy="15.2" r=".75" fill="currentColor"/>',
    busy: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="14 38" stroke-dashoffset="6"/>',
    ok: '<path d="M5 12.5l4.5 4.6L19.2 7.3" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>',
    err: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M12 7.5v5.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><circle cx="12" cy="16.5" r="1.2" fill="currentColor"/>'
  };
  // 把历史 hint 字符（'…' '✓' '!'）归一为状态图标 key
  const glyphKey = (kind, hint) => {
    if (hint === '✓' || kind === 'ok') return 'ok';
    if (hint === '!' || kind === 'err') return 'err';
    if (hint === '…' || kind === 'busy') return 'busy';
    return 'wechat';
  };
  // SVG 元素的 hidden IDL 属性在部分内核上不反映为内容属性，CSS [hidden] 选择器会漏匹配；
  // 显隐统一走内容属性开关（图标常挂、按状态互斥显示，避免 innerHTML 重建打断拖拽）。
  const setHidden = (el, hidden) => { if (hidden) el.setAttribute('hidden', ''); else el.removeAttribute('hidden'); };
  const svgEl = (cls, inner) => {
    const wrap = document.createElement('div');
    wrap.innerHTML = `<svg${cls ? ` class="${cls}"` : ''} viewBox="0 0 24 24" aria-hidden="true">${inner}</svg>`;
    return wrap.firstElementChild;
  };
  // 文章地址归一化：同一篇文章在页面上的地址可能带 chksm / scene / from / #wechat_redirect 等跟踪参数，
  // 提交给服务端的 original_url 必须用它归一，否则服务端按 URL 去重会失效、重复入库。
  // 微信：短链接归一为 https://mp.weixin.qq.com/s/<slug>，长链接只保留 __biz/mid/idx/sn 四要素（与桌面端归一化契约一致）
  function normalizeArticleUrl(rawUrl) {
    if (!rawUrl) return '';
    let parsed;
    try { parsed = new URL(rawUrl, location.href); } catch { return ''; }
    const path = parsed.pathname;
    if (parsed.hostname !== WECHAT_HOST) return '';
    // 短链接：/s/xxxxx
    if (WECHAT_SHORT.test(path)) {
      return `https://mp.weixin.qq.com${path.replace(/\/$/, '')}`;
    }
    // 长链接：/s?__biz=xxx&mid=xxx&idx=1&sn=xxx，仅保留四要素
    if (WECHAT_LONG.test(path)) {
      const params = parsed.searchParams;
      if (params.has('__biz')) {
        const biz = params.get('__biz') || '';
        const mid = params.get('mid') || '';
        const idx = params.get('idx') || '1';
        const sn = params.get('sn') || '';
        return `https://mp.weixin.qq.com/s?__biz=${biz}&mid=${mid}&idx=${idx}&sn=${sn}`;
      }
    }
    return '';
  }
  // 微信文章 URL（短链/长链）才返回归一地址；其余页面（含微信非文章页）返回空串
  function articleUrl() {
    if (location.hostname !== WECHAT_HOST) return '';
    return normalizeArticleUrl(location.href);
  }
  // 两形态的名义尺寸（收起 = 38 主钮 + 2 gap + 34 玻璃辅助钮占位；展开 = 胶囊，名义宽度取常态估算，
  // 拖拽引擎用按下时实测 rect，不依赖这里的值）
  function formSize() { return collapsed ? { W: 74, H: 38 } : { W: 172, H: 36 }; }
  function clampPos(left, top, W, H) {
    const M = EDGE_MARGIN;
    return {
      left: Math.min(Math.max(M, left), Math.max(M, innerWidth - W - M)),
      top: Math.min(Math.max(M, top), Math.max(M, innerHeight - H - M))
    };
  }
  function place(left = position?.left, top = position?.top) {
    const { W, H } = formSize(), M = EDGE_MARGIN;
    const defaultLeft = Math.max(M, innerWidth - W - M);
    const defaultTop = Math.max(M, Math.round((innerHeight - H) / 2));
    position = clampPos(Number.isFinite(left) ? left : defaultLeft, Number.isFinite(top) ? top : defaultTop, W, H);
    if (host) {
      host.style.left = `${position.left}px`; host.style.top = `${position.top}px`;
      // 提示气泡比按钮宽得多，靠屏幕哪一侧就往另一侧展开，避免贴边被裁掉
      if (notice) { const toLeft = position.left + W / 2 > innerWidth / 2; notice.style.right = toLeft ? '0' : 'auto'; notice.style.left = toLeft ? 'auto' : '0'; }
    }
  }
  function display(kind, text, glyphHint, quiet = false) {
    if (!button) return;
    phase = kind || '';
    button.className = kind ? `wx-main ${kind}` : 'wx-main';
    button.title = text;
    button.setAttribute('aria-label', text);
    const key = glyphKey(kind, glyphHint);
    for (const [name, svg] of Object.entries(glyphs)) setHidden(svg, name !== key);
    notice.textContent = text;
    notice.hidden = quiet || !text || text === IDLE_TEXT;
  }
  function idleText() {
    if (channelName === 'error') return channelReason || '当前下载通道异常，请到设置页检查';
    if (offline) return OFFLINE_HINT();
    return channelName ? `${IDLE_TEXT} · ${CHAN_LABEL[channelName]}` : IDLE_TEXT;
  }
  function updateIdle() {
    if (!button || phase) return; // 提交中/结果状态保留自己的文案
    display('', idleText(), null, true); // 离线提示只放在悬停 title，不遮挡页面
  }
  function setOffline(next) {
    if (next === offline) return;
    offline = next;
    updateIdle();
  }
  function showOffline() {
    setOffline(true);
    updateBadge([]); // 提交/轮询失败时立刻在面板给出离线说明，不等下一次 recent 轮询
  }
  function remove() {
    clearTimeout(resetTimer); clearTimeout(pressTimer);
    clearInterval(recentTimer); clearInterval(panelRefreshTimer);
    for (const t of pollTimers) clearTimeout(t);
    pollTimers.clear(); pollTracker.clear();
    host?.remove(); host = button = notice = badge = panel = wxRoot = label = sum = chevL = chevR = null; glyphs = null; phase = '';
  }
  // 双形态样式令牌：展开=品牌绿胶囊，收起=低存在感圆钮（opacity .4，hover 显现）
  const CSS_TEXT = `
:host{position:fixed;z-index:2147483647;display:block;font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;--wx-accent:#07c160;--wx-accent-d:#06a552;--wx-dark:#087f5b;--wx-red:#d92d20;--wx-red-d:#b4241a;--wx-ink:#334155;--wx-glow:rgba(7,193,96,.35)}
:host([data-channel='backend']){--wx-accent:#2563eb;--wx-accent-d:#1d4ed8;--wx-dark:#1e40af;--wx-glow:rgba(37,99,235,.35)}
:host([data-channel='download']){--wx-accent:#d97706;--wx-accent-d:#b45309;--wx-dark:#92400e;--wx-glow:rgba(217,119,6,.35)}
:host([data-channel='error']){--wx-accent:#d92d20;--wx-accent-d:#b4241a;--wx-dark:#991b1b;--wx-glow:rgba(217,45,32,.35)}
:host *,:host *::before,:host *::after{box-sizing:border-box}
.wx{display:inline-flex;align-items:center;gap:2px;position:relative;animation:wx-in .18s ease-out}
@keyframes wx-in{from{opacity:0;transform:translateY(4px) scale(.96)}to{opacity:1;transform:none}}
.wx[data-collapsed='0']{gap:0}
.wx-main{position:relative;display:flex;align-items:center;gap:7px;width:172px;max-width:min(60vw,172px);height:36px;padding:0 30px 0 13px;border:0;border-radius:18px;background:var(--wx-accent);color:#fff;box-shadow:0 3px 12px rgba(15,23,42,.22);cursor:pointer;touch-action:none;user-select:none;-webkit-user-select:none;transition:background .18s ease,box-shadow .18s ease,transform .15s ease,opacity .15s ease}
.wx-main:hover{background:var(--wx-accent-d);transform:translateY(-1px);box-shadow:0 6px 18px var(--wx-glow)}
.wx-main:active{transform:translateY(0)}
.wx-main:focus-visible{outline:none;box-shadow:0 0 0 3px var(--wx-glow),0 3px 12px rgba(15,23,42,.22)}
.wx-main.busy{cursor:progress}
.wx-main.busy .ic-busy{animation:spin 1s linear infinite}
.wx-main.ok{background:var(--wx-dark);box-shadow:0 3px 12px rgba(8,127,91,.30)}
.wx-main.ok:hover{background:var(--wx-dark);box-shadow:0 6px 18px rgba(8,127,91,.34)}
.wx-main.err{background:var(--wx-red);box-shadow:inset 0 0 0 1px rgba(255,255,255,.7),0 3px 12px rgba(217,45,32,.28)}
.wx-main.err:hover{background:var(--wx-red-d)}
:host([data-dragging]){will-change:transform}
:host([data-dragging]) .wx-main{cursor:grabbing;transform:scale(.96)!important;background:var(--wx-accent-d);box-shadow:0 12px 28px rgba(15,23,42,.32);transition:transform .08s ease,box-shadow .15s ease}
:host([data-dragging]) .wx-mini{pointer-events:none}
.wx[data-collapsed='1'] .wx-main{justify-content:center;gap:0;width:38px;height:38px;padding:0;border-radius:50%;border:1px solid rgba(255,255,255,.32);opacity:.4;box-shadow:0 2px 8px rgba(15,23,42,.16)}
.wx[data-collapsed='1'] .wx-main:hover{opacity:1;background:var(--wx-accent-d);box-shadow:0 6px 18px var(--wx-glow)}
.wx[data-collapsed='1'] .wx-main:focus-visible{opacity:1;box-shadow:0 0 0 3px var(--wx-glow),0 2px 8px rgba(15,23,42,.16)}
.wx[data-collapsed='1'] .wx-main.busy,.wx[data-collapsed='1'] .wx-main.ok,.wx[data-collapsed='1'] .wx-main.err{opacity:1}
.wx-ico{flex:0 0 auto;display:flex;align-items:center;justify-content:center}
.glyph{display:block;width:18px;height:18px;flex:0 0 18px}
.wx-text{min-width:0;max-width:100%;display:flex;flex-direction:column;align-items:flex-start}
.wx-label{white-space:nowrap;font-size:13px;font-weight:600;letter-spacing:.04em;line-height:1.25}
.wx-sum{font-size:10.5px;line-height:1.25;color:rgba(255,255,255,.82);white-space:nowrap;max-width:104px;overflow:hidden;text-overflow:ellipsis}
.wx-mini{position:relative;flex:0 0 auto;display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:0;border-radius:50%;margin-left:-26px;background:rgba(255,255,255,.18);color:#fff;cursor:pointer;touch-action:none;user-select:none;-webkit-user-select:none;transition:background .15s ease,opacity .15s ease,transform .15s ease,box-shadow .15s ease}
.wx-mini svg{display:block;width:14px;height:14px}
.wx-mini:hover{background:rgba(255,255,255,.30)}
.wx-mini:active{transform:scale(.94)}
.wx-mini:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(255,255,255,.45)}
.wx[data-collapsed='1'] .wx-mini{width:34px;height:34px;margin-left:0;color:var(--wx-ink);background:rgba(255,255,255,.72);border:1px solid rgba(15,23,42,.08);box-shadow:0 2px 8px rgba(15,23,42,.14);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);opacity:0;pointer-events:none}
.wx[data-collapsed='1']:hover .wx-mini,.wx[data-collapsed='1']:focus-within .wx-mini{opacity:1;pointer-events:auto}
.wx[data-collapsed='1'] .wx-mini:hover{background:#fff;color:#0f172a}
.wx[data-collapsed='1'] .wx-mini:focus-visible{opacity:1;pointer-events:auto;box-shadow:0 0 0 3px var(--wx-glow)}
.badge{position:absolute;right:-4px;top:-4px;background:#d92d20;color:#fff;border-radius:12px;padding:2px 6px;font:700 11px system-ui;min-width:18px;text-align:center;box-shadow:0 2px 6px rgba(217,45,32,.4);border:1.5px solid #fff;pointer-events:none}
.notice{position:absolute;top:calc(100% + 8px);font:13px/1.5 system-ui,sans-serif;color:#fff;background:rgba(31,41,55,.95);border-radius:9px;padding:8px 10px;width:200px;max-width:60vw;overflow-wrap:anywhere;pointer-events:none;box-shadow:0 6px 18px rgba(0,0,0,.18)}
.panel{position:absolute;right:104px;top:0;width:286px;max-width:calc(100vw - 16px);max-height:min(460px,calc(100vh - 16px));border-radius:14px;background:#fff;color:#111;border:1px solid #eef1f5;box-shadow:0 10px 34px rgba(15,23,42,.14),0 2px 8px rgba(15,23,42,.06);display:flex;flex-direction:column;font:12.5px/1.35 system-ui;overflow:hidden}
.panel-header{display:flex;align-items:center;justify-content:space-between;padding:9px 12px 8px;background:linear-gradient(135deg,#f8fafc 0%,#f1f5f9 100%);border-bottom:1px solid #eef1f5}
.panel-header b{font-size:12.5px;font-weight:600;color:#1e293b;letter-spacing:-.01em}
.panel-header .count{font-size:10px;line-height:1;color:#64748b;background:#e2e8f0;padding:3px 7px;border-radius:9px;font-weight:600}
.panel-head-tools{display:inline-flex;align-items:center;gap:6px;margin-left:auto}
.chan{display:inline-flex;align-items:center;gap:4px;font-size:10px;line-height:1;font-weight:600;color:#475569;background:#f1f5f9;padding:3px 7px;border-radius:9px}
.chan-dot{width:7px;height:7px;border-radius:50%;background:#07c160}
.chan-backend .chan-dot{background:#2563eb}
.chan-download .chan-dot{background:#d97706}
.chan-error .chan-dot{background:#d92d20}
.chan-error{color:#b91c1c;background:#fef2f2}
.panel-body{flex:1;min-height:0;overflow:auto;padding:6px 8px}
.row{padding:5px 10px;border-radius:9px;background:#fff;border:1px solid #f1f5f9;margin-bottom:4px;transition:border-color .15s ease,box-shadow .15s ease,background .15s ease}
.row:last-child{margin-bottom:0}
.row:hover{border-color:#e0e7ff;background:#fcfcff;box-shadow:0 1px 6px rgba(99,102,241,.07)}
.row-title{font-weight:600;color:#1e293b;font-size:12.5px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:2px;letter-spacing:-.01em}
.row-title.no-title{color:#94a3b8;font-weight:400;font-style:italic}
.row-meta{display:flex;align-items:center;justify-content:space-between;gap:6px;line-height:1.3;font-size:11px;color:#94a3b8}
.row-status{display:flex;align-items:center;gap:4px;font-size:11px;color:#64748b;font-weight:500;min-width:0}
.row-status span:last-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.row-status .dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;border:1.5px solid transparent}
.row-status .dot.waiting{background:#f59e0b;border-color:#fef3c7}
.row-status .dot.running{background:#3b82f6;border-color:#dbeafe;animation:pulse 1.5s ease-in-out infinite}
.row-status .dot.completed{background:#22c55e;border-color:#dcfce7}
.row-status .dot.failed,.row-status .dot.cancelled{background:#ef4444;border-color:#fee2e2}
.row-status .dot.paused{background:#9ca3af;border-color:#f3f4f6}
.row-count{white-space:nowrap;font-variant-numeric:tabular-nums}
.row-tools{display:flex;align-items:center;gap:6px;flex-shrink:0}
.task-action{display:inline-flex;align-items:center;gap:3px;width:auto;height:auto;box-shadow:none;background:#f8fafc;border:1px solid #e7ebf2;border-radius:5px;padding:2px 6px;cursor:pointer;transition:all .15s ease;font:500 11px/1 system-ui;color:#6366f1}
.task-action:hover{background:#eef2ff;border-color:#c7d2fe;color:#4f46e5}
.task-action.danger{color:#b91c1c;background:transparent;border-color:transparent;padding:2px 3px;border-radius:5px}
.task-action.danger:hover{background:#fef2f2;border-color:transparent;color:#dc2626}
.task-action svg{flex-shrink:0;display:block}
.task-action span{pointer-events:none}
.task-action.loading{opacity:.55;pointer-events:none}
.task-action.loading svg{animation:spin 1s linear infinite}
.task-action:disabled{opacity:.5;cursor:default;pointer-events:none}
.panel-footer{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px 10px;border-top:1px solid #eef1f5;background:#f8fafc;border-radius:0 0 14px 14px}
.panel-footer .task-action{padding:4px 10px;font-size:11.5px}
.empty{padding:20px 14px;text-align:center;color:#94a3b8;font-size:12px;line-height:1.55}
.empty.offline{color:#b45309}
.empty.offline .empty-icon{opacity:.7}
.empty-icon{font-size:22px;margin-bottom:5px;opacity:.35}
.panel-refresh{font-size:10.5px;color:#94a3b8;pointer-events:none;white-space:nowrap}
.cfm-mask{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.45);animation:wx-in .18s ease-out}
.cfm-box{width:280px;max-width:calc(100vw - 32px);background:#fff;color:#111;border-radius:14px;box-shadow:0 10px 34px rgba(15,23,42,.24);padding:16px;display:flex;flex-direction:column;gap:6px}
.cfm-title{font-size:13.5px;font-weight:600;color:#1e293b;letter-spacing:-.01em}
.cfm-detail{font-size:12.5px;line-height:1.5;color:#64748b;overflow-wrap:anywhere;max-height:30vh;overflow:auto}
.cfm-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:8px}
.cfm-btn{border:0;border-radius:8px;padding:7px 14px;font:600 12.5px system-ui;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s ease}
.cfm-btn:hover{background:#e2e8f0}
.cfm-btn.danger{background:var(--wx-red);color:#fff}
.cfm-btn.danger:hover{background:var(--wx-red-d)}
.cfm-btn:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(99,102,241,.25)}
.progress-bg{height:3px;background:#f1f5f9;border-radius:2px;margin-top:4px;overflow:hidden}
.progress-bar{height:100%;background:linear-gradient(90deg,#6366f1,#8b5cf6);border-radius:2px;transition:width .3s ease;animation:shimmer 2s linear infinite;background-size:200% 100%}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes spin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.wx,.wx-main.busy .ic-busy,.row-status .dot.running,.progress-bar,.cfm-mask{animation:none}}
[hidden]{display:none!important}
`;
  function mount() {
    host = document.createElement('div'); host.id = HOST_ID;
    const shadow = host.attachShadow({mode:'open'});
    const style = document.createElement('style');
    style.textContent = CSS_TEXT;
    wxRoot = document.createElement('div'); wxRoot.className = 'wx';
    button = document.createElement('button'); button.type = 'button'; button.className = 'wx-main';
    const ico = document.createElement('span'); ico.className = 'wx-ico';
    glyphs = {};
    for (const [name, paths] of Object.entries(ICON_SVG)) {
      const svg = svgEl(`glyph ic-${name}`, paths);
      setHidden(svg, true);
      glyphs[name] = svg;
      ico.appendChild(svg);
    }
    const textWrap = document.createElement('span'); textWrap.className = 'wx-text';
    label = document.createElement('span'); label.className = 'wx-label'; label.textContent = '存阅';
    sum = document.createElement('span'); sum.className = 'wx-sum'; setHidden(sum, true);
    textWrap.append(label, sum);
    badge = document.createElement('span'); badge.className = 'badge'; badge.hidden = true;
    button.append(ico, textWrap, badge);
    mini = document.createElement('button'); mini.type = 'button'; mini.className = 'wx-mini';
    chevL = svgEl('chev chev-l', '<path d="M14 6l-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>');
    chevR = svgEl('chev chev-r', '<path d="M10 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>');
    mini.append(chevL, chevR);
    notice = document.createElement('div'); notice.className = 'notice'; notice.setAttribute('role','status');
    panel = document.createElement('div'); panel.className = 'panel'; panel.hidden = true;
    shadow.append(style, wxRoot, notice, panel);
    wxRoot.append(button, mini);
    if (channelName) host.setAttribute('data-channel', channelName);
    place(); renderForm(); display('', idleText(), null, true); document.documentElement.appendChild(host);
    button.addEventListener('pointerdown', onPointerDown);
    button.addEventListener('click', () => {
      if (suppressClick) { suppressClick = false; return; }
      save();
    });
    button.addEventListener('pointerenter', refreshSummary);
    button.addEventListener('pointerleave', hideSummary);
    button.addEventListener('focus', refreshSummary);
    button.addEventListener('blur', hideSummary);
    mini.addEventListener('click', () => toggleCollapsed());
    panel.addEventListener('click', async e => {
      const target = e.target.closest('[data-task-action]');
      if (!target || target.disabled) return;
      const action = target.dataset.taskAction;
      // 删除类操作先二次确认；取消则不做任何事
      if ((action === 'delete' || action === 'clearFinished') && !await confirmTaskDelete(action, target)) return;
      target.disabled = true;
      target.classList.add('loading');
      try {
        if (directModeEnabled) {
          // 直连模式：本地历史操作
          if (action === 'open') { await openReaderFor(target.dataset.articleId); return; }
          if (action === 'delete') await removeDirectHistory(target.dataset.taskId);
          else if (action === 'clearFinished') await clearDirectHistory();
          // 直连模式无重试（已直接上传）
        } else {
          // 桌面端模式
          if (action === 'videoBackfill') { await startVideoBackfill(); return; }
          const result = action === 'retry' ? await send('retry', {taskId: target.dataset.taskId}) : action === 'delete' ? await send('deleteTask', {taskId: target.dataset.taskId}) : await send('clearFinished');
          if (!result?.ok) throw apiFailure(result, '操作失败');
          await refreshRecent();
        }
      } catch (e) { if (isOffline(e)) showOffline(); notice.textContent = errorMessage(e); notice.hidden = false; }
      finally { target.disabled = false; target.classList.remove('loading'); }
    });
  }
  // 收起↔展开：宽度突变时按右缘锚定重定位，视觉位置不跳
  function toggleCollapsed() {
    const oldW = formSize().W;
    collapsed = !collapsed;
    if (position) place(position.left + oldW - formSize().W, position.top);
    else place();
    renderForm();
    if (panel && !panel.hidden) fitPanel();
    persist();
  }
  function renderForm() {
    if (!wxRoot) return;
    wxRoot.setAttribute('data-collapsed', collapsed ? '1' : '0');
    setHidden(label, collapsed); // 收起态用 hidden 属性而非仅靠 CSS：读屏与 Tab 都不该再碰到这行字
    setHidden(chevL, !collapsed);
    setHidden(chevR, collapsed);
    mini?.setAttribute('aria-label', collapsed ? '展开存阅按钮' : '收起存阅按钮');
    hideSummary();
  }
  function persist() {
    if (!position) return;
    try { chrome.storage.local.set({position: {...position, collapsed}})?.catch?.(() => {}); } catch (e) { /* 存储写失败：本次会话内位置仍然生效（持久化是尽力而为） */ }
  }
  function summaryText() {
    if (offline) return directModeEnabled ? '未连接服务端' : '未连接客户端';
    const platform = directModeEnabled ? '直连' : '微信';
    return activeCount ? `${platform} · 进行中 ${activeCount}` : platform;
  }
  function refreshSummary() {
    // 收起态只有动作，无第二行；拖拽中不展开：高度突变会让按下时缓存的 rect 失准；busy/ok/err 由气泡播报
    if (collapsed || phase || !sum || host?.hasAttribute('data-dragging')) return;
    sum.textContent = summaryText();
    setHidden(sum, false);
  }
  function hideSummary() {
    if (!sum) return;
    setHidden(sum, true);
    sum.textContent = '';
  }
  // 拖拽（Pointer Events；transform 走合成层 + rAF 合帧，松手按「最后指针位置」同步落定，不读布局避免 reflow）
  function onPointerDown(e) {
    if (e.button !== 0) return;
    suppressClick = false;
    const rect = host.getBoundingClientRect();
    const btnW = rect.width || formSize().W, btnH = rect.height || formSize().H;
    const grabDX = e.clientX - rect.left, grabDY = e.clientY - rect.top;
    const downX = e.clientX, downY = e.clientY; // 阈值基准：必须是「相对按下点的位移」
    let moved = false, rafId = 0;
    // 目标左上角坐标，初值即当前位置：保证即使一次 move 都没合成，松手也有正确的落定值
    let px = rect.left, py = rect.top;
    const targetAt = (x, y) => clampPos(x - grabDX, y - grabDY, btnW, btnH);
    const flush = () => {
      rafId = 0;
      const t = targetAt(px, py);
      host.style.transform = `translate3d(${t.left - rect.left}px,${t.top - rect.top}px,0)`;
      position = t;
    };
    const onMove = ev => {
      const dx = ev.clientX - downX, dy = ev.clientY - downY;
      if (!moved && Math.abs(dx) + Math.abs(dy) <= DRAG_THRESHOLD) return; // 未过阈值：仍按点击处理
      if (!moved) {
        moved = true;
        clearTimeout(pressTimer); // 越过拖拽阈值即取消长按开面板
        host.setAttribute('data-dragging', '1');
        hideSummary();
      }
      px = ev.clientX; py = ev.clientY;
      if (rafId) return; // 一帧只排一次更新，丢弃同帧内多余的 pointermove
      rafId = requestAnimationFrame(flush);
    };
    // commit=true 落定到新位置；false（未达阈值的点击/手势取消）仅清场，绝不留下半截 transform
    const finish = commit => {
      clearTimeout(pressTimer);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onCancel);
      if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
      host.removeAttribute('data-dragging');
      if (commit) {
        // 关键：用「最后一次指针位置」同步重算，而不是可能尚未 flush 的旧 pos——否则快速拖拽松手会回弹
        const t = targetAt(px, py);
        position = t;
        host.style.transform = '';
        host.style.left = `${t.left}px`; host.style.top = `${t.top}px`;
        suppressClick = true;
        persist();
        if (panel && !panel.hidden) fitPanel();
      } else {
        host.style.transform = '';
      }
    };
    const onUp = () => finish(moved);
    const onCancel = () => finish(moved); // 系统中断手势时也把按钮停在最后位置，避免视觉残留/弹回
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);
    pressTimer = setTimeout(() => { suppressClick = true; showPanel(); }, LONG_PRESS_MS);
  }
  const apiFailure = (result, fallback) => { const e = Error(result?.error || fallback); e.code = result?.code; return e; };
  function errorMessage(e) {
    const message = e?.message || '';
    if (/context invalidated|receiving end does not exist/i.test(message)) return '插件已更新，请刷新当前页面后重试';
    if (isOffline(e)) return OFFLINE_HINT();
    return message || (directModeEnabled ? '无法连接服务端，请检查配置' : '无法连接微文存阅，请启动客户端后重试');
  }
  const emptyState = () => {
    if (directModeEnabled) {
      return '<div class="empty"><div class="empty-icon">◎</div>暂无保存记录</div>';
    }
    return offline
      ? '<div class="empty offline"><div class="empty-icon">⚠</div>未检测到微文存阅客户端<br>请先打开微文存阅客户端</div>'
      : '<div class="empty"><div class="empty-icon">◎</div>暂无下载任务</div>';
  };
  const statusLabel = status => ({
    queued:'等待中 · 排队',
    waiting:'等待中 · 等待执行',
    running:'下载中 · 正在执行',
    processing:'处理中 · 正在处理',
    completed:'已完成 · 下载完成',
    failed:'失败 · 下载出错',
    cancelled:'已取消',
    paused:'等待中 · 等待继续'
  }[status] || status || '未知');
  const statusDot = status => ({
    queued:'waiting', waiting:'waiting', running:'running', processing:'running',
    completed:'completed', failed:'failed', cancelled:'cancelled', paused:'paused'
  }[status] || 'waiting');
  const TRASH_SVG = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>';
  const RETRY_SVG = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>';
  const OPEN_SVG = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';
  const truncateTitle = (title, max = 20) => {
    if (!title) return '';
    const t = String(title).trim();
    return t.length > max ? t.slice(0, max) + '…' : t;
  };
  const itemCount = task => {
    if (task.itemCount > 0) return task.itemCount;
    if (Array.isArray(task.items)) return task.items.length;
    return 1;
  };
  function updateBadge(tasks=[]) {
    const rows = tasks.filter(t => ['queued','waiting','running','processing'].includes(t.status));
    const ids = new Set(rows.map(t=>t.id));
    for (const id of active.values()) if (id !== 'pending') ids.add(id);
    const count = ids.size + [...active.values()].filter(id=>id === 'pending').length;
    activeCount = count;
    // badge 挂在主钮内：清空隐藏态的文本，避免读屏与 textContent 混入残留数字
    badge.hidden = !count; badge.textContent = count || '';
    const visible = tasks.slice(0, 20);
    const panelTitle = directModeEnabled ? '已保存文章' : '下载任务';
    const chanChip = channelName ? `<span class="chan chan-${channelName}" title="当前下载方式"><span class="chan-dot"></span>${CHAN_LABEL[channelName]}</span>` : '';
    panel.innerHTML = `<div class="panel-header"><b>${panelTitle}</b><span class="panel-head-tools">${chanChip}${count ? `<span class="count">${count}</span>` : ''}</span></div><div class="panel-body">${videoGapRowHtml()}${visible.length ? visible.map(t => {
      const title = truncateTitle(t.title);
      const cnt = itemCount(t);
      const statusClass = esc(statusDot(t.status));
      const statusText = esc(statusLabel(t.status));
      const isDirectCompleted = directModeEnabled && t.status === 'completed';
      return `<div class="row"><div class="row-title${title ? '' : ' no-title'}">${esc(title) || '文章 · 1 篇'}</div><div class="row-meta"><div class="row-status"><span class="dot ${statusClass}"></span><span>${statusText}</span></div><div class="row-tools">${isDirectCompleted && t.articleId ? `<button class="task-action" data-task-action="open" data-article-id="${esc(t.articleId)}" title="打开阅读">${OPEN_SVG}<span>阅读</span></button>` : ''}${isDirectCompleted || ['completed','failed','cancelled','partial_failed'].includes(t.status) ? `<button class="task-action danger" data-task-action="delete" data-task-id="${esc(t.id)}" title="删除">${TRASH_SVG}</button>` : ''}${!directModeEnabled && ['failed','cancelled','partial_failed'].includes(t.status) ? `<button class="task-action" data-task-action="retry" data-task-id="${esc(t.id)}" title="重试">${RETRY_SVG}<span>重试</span></button>` : ''}</div></div>${!directModeEnabled && ['running','processing','paused'].includes(t.status) ? `<div class="progress-bg"><div class="progress-bar" style="width:${Math.min(t.progress || 30, 95)}%"></div></div>` : ''}</div>`;
    }).join('') : emptyState()}</div><div class="panel-footer"><button class="task-action" data-task-action="clearFinished">${directModeEnabled ? '清空记录' : '清空已结束'}</button><span class="panel-refresh" data-refresh-hint></span></div>`;
  }
  async function refreshRecent() {
    // 直连模式：从本地存储读取提交历史
    if (directModeEnabled) {
      try {
        const data = await chrome.storage.local.get({ directHistory: [] });
        const history = Array.isArray(data.directHistory) ? data.directHistory : [];
        setOffline(false);
        updateBadge(history.slice(0, 20));
      } catch (e) {
        updateBadge([]);
      }
      return;
    }
    // 桌面端模式：从桌面客户端获取任务列表
    try {
      const r = await send('recent');
      if (r?.ok) { setOffline(false); updateBadge(Array.isArray(r.data) ? r.data : []); return; }
      if (isOffline(r)) showOffline();
    } catch (e) {
      if (isOffline(e)) showOffline();
    }
  }
  // 通道探测：向 background 要「实际生效通道」，驱动按钮底色/tooltip/面板徽标；顺带同步直连判定（含 v1 'direct' 迁移后的 'backend'）
  function applyChannelState(st) {
    const chan = st?.channel;
    if (!CHAN_LABEL[chan]) return;
    const direct = st.mode === 'backend';
    if (chan === channelName && direct === directModeEnabled) return;
    channelName = chan;
    channelReason = String(st.reason || '');
    directModeEnabled = direct;
    if (!button) return; // 挂载前先记状态，mount() 里统一应用
    host.setAttribute('data-channel', channelName);
    updateIdle();
    refreshRecent();
  }
  const probeChannel = () => Promise.resolve(send('UI_PROBE')).then(r => applyChannelState(r?.data)).catch(() => {});
  // 直连历史「打开阅读」：优先用设置页填写的 Web 入口，其次按服务端地址推导 origin。
  // Web 端为 history 路由，文章详情页固定为 /article/{id}，打通「采集→阅读」闭环
  async function readerUrlFor(articleId) {
    if (!articleId) return '';
    try {
      const data = await chrome.storage.local.get({ entryWebUrl: '', serverUrl: '' });
      let base = String(data.entryWebUrl || '').trim();
      if (!/^https?:\/\//i.test(base)) {
        try { base = new URL(data.serverUrl).origin + '/'; } catch (e) { return ''; }
      }
      return base.replace(/\/+$/, '') + '/article/' + encodeURIComponent(articleId);
    } catch (e) { return ''; }
  }
  async function openReaderFor(articleId) {
    const url = await readerUrlFor(articleId);
    if (!url) {
      notice.textContent = '无法推导阅读页地址：请先在设置页填写服务端地址或 Web 入口';
      notice.hidden = false;
      return;
    }
    window.open(url, '_blank', 'noopener');
  }
  // 直连模式：记录提交历史到本地存储
  async function addDirectHistory(entry) {
    try {
      const data = await chrome.storage.local.get({ directHistory: [] });
      const history = Array.isArray(data.directHistory) ? data.directHistory : [];
      history.unshift(Object.assign({
        id: 'direct_' + Date.now(),
        status: 'completed',
        progress: 100,
        createdAt: new Date().toISOString()
      }, entry));
      // 保留最近 50 条
      const trimmed = history.slice(0, 50);
      await chrome.storage.local.set({ directHistory: trimmed });
    } catch (e) { /* ignore */ }
  }
  // 直连模式：删除历史记录
  async function removeDirectHistory(id) {
    try {
      const data = await chrome.storage.local.get({ directHistory: [] });
      const history = Array.isArray(data.directHistory) ? data.directHistory : [];
      const filtered = history.filter(h => h.id !== id);
      await chrome.storage.local.set({ directHistory: filtered });
      await refreshRecent();
    } catch (e) { /* ignore */ }
  }
  // 直连模式：清空已完成历史
  async function clearDirectHistory() {
    try {
      await chrome.storage.local.set({ directHistory: [] });
      await refreshRecent();
    } catch (e) { /* ignore */ }
  }
  // 删除类操作的二次确认对话框：样式与面板一致；取消/ESC/点遮罩都关闭并返回 false（不执行任何删除）
  function askConfirm(title, detail, okText) {
    return new Promise(resolve => {
      const root = panel && panel.getRootNode();
      if (!root || typeof root.append !== 'function') { resolve(false); return; }
      root.querySelector('.cfm-mask')?.remove(); // 同一时刻只保留一个确认框
      const mask = document.createElement('div'); mask.className = 'cfm-mask';
      const box = document.createElement('div'); box.className = 'cfm-box';
      box.setAttribute('role', 'alertdialog'); box.setAttribute('aria-modal', 'true');
      const t = document.createElement('div'); t.className = 'cfm-title'; t.textContent = title;
      const d = document.createElement('div'); d.className = 'cfm-detail'; d.textContent = detail;
      const acts = document.createElement('div'); acts.className = 'cfm-actions';
      const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'cfm-btn'; cancel.textContent = '取消';
      const ok = document.createElement('button'); ok.type = 'button'; ok.className = 'cfm-btn danger'; ok.textContent = okText;
      acts.append(cancel, ok); box.append(t, d, acts); mask.append(box);
      const close = val => { mask.remove(); document.removeEventListener('keydown', onKey); resolve(val); };
      const onKey = e => { if (e.key === 'Escape') close(false); };
      cancel.addEventListener('click', () => close(false));
      ok.addEventListener('click', () => close(true));
      mask.addEventListener('click', e => { if (e.target === mask) close(false); });
      document.addEventListener('keydown', onKey);
      root.append(mask);
      ok.focus();
    });
  }
  // 组装删除确认文案：点明被删条目（标题/条数）与影响范围，直连/桌面两模式口径分开
  async function confirmTaskDelete(action, target) {
    if (action === 'delete') {
      let name = '';
      if (directModeEnabled) {
        try {
          const data = await chrome.storage.local.get({ directHistory: [] });
          const history = Array.isArray(data.directHistory) ? data.directHistory : [];
          const hit = history.find(h => h.id === target.dataset.taskId);
          if (hit) name = String(hit.title || '');
        } catch (e) { /* 取不到标题则回落行内文案 */ }
      }
      if (!name) name = target.closest('.row')?.querySelector('.row-title')?.textContent?.trim() || '';
      if (!name) name = directModeEnabled ? '该保存记录' : '该任务';
      const what = directModeEnabled ? '保存记录' : '下载任务';
      const note = directModeEnabled
        ? '仅删除扩展里的这条记录，不影响服务端已保存的文章。'
        : '删除后任务将从列表移除且不可恢复。';
      return askConfirm(`删除${what}`, `确定删除 1 条${what}：「${name}」？${note}`, '删除');
    }
    if (directModeEnabled) {
      let count = 0;
      try {
        const data = await chrome.storage.local.get({ directHistory: [] });
        count = (Array.isArray(data.directHistory) ? data.directHistory : []).length;
      } catch (e) { count = panel.querySelectorAll('.panel-body .row').length; }
      if (!count) { notice.textContent = '暂无保存记录可删除'; notice.hidden = false; return false; }
      return askConfirm('清空保存记录', `确定删除全部 ${count} 条保存记录？仅清空扩展里的记录，不影响服务端已保存的文章。`, '清空');
    }
    const rows = [...panel.querySelectorAll('.panel-body .row')].filter(r => r.querySelector('[data-task-action="delete"]'));
    if (!rows.length) { notice.textContent = '暂无可清空的已结束任务'; notice.hidden = false; return false; }
    return askConfirm('清空已结束任务', `确定删除当前列出的 ${rows.length} 条已结束任务？删除后不可恢复。`, '清空');
  }
  function forgetTask(taskId) {
    for (const [u, id] of active) if (id === taskId) active.delete(u);
    pollTracker.delete(taskId);
  }
  function scheduleReset(activeButton) {
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => {
      resetTimer = null;
      if (button && button === activeButton) { phase = ''; refresh(); }
    }, 6000);
  }
  async function poll(taskId, activeButton) {
    if (button !== activeButton) return;
    try {
      const result = await send('task', {taskId});
      if (button !== activeButton) return;
      if (!result?.ok) throw apiFailure(result, '任务查询失败');
      const task = result.data;
      if (task.status === 'completed') { forgetTask(taskId); refreshRecent(); display('ok', task.phase || '本地下载完成', '✓'); scheduleReset(activeButton); return; }
      if (['failed','cancelled','paused','partial_failed'].includes(task.status)) {
        forgetTask(taskId); refreshRecent(); display('err', task.error || task.items?.find(i => i.error)?.error || task.phase || '请在客户端查看任务', '!'); scheduleReset(activeButton); return;
      }
      display('busy', task.phase || '正在下载，请稍候', '…');
      const t = setTimeout(() => poll(taskId, activeButton), 2000);
      pollTimers.add(t);
    } catch(e) {
      // 查询失败（桌面端未启动/连接中断等）：立即清理 active 并停止轮询，避免“下载中”死锁
      forgetTask(taskId);
      refreshRecent();
      if (isOffline(e)) showOffline();
      display('err', errorMessage(e), '!');
      scheduleReset(activeButton);
    }
  }
  // 直连模式：提取微信文章并上传到服务端
  async function directSubmitWeChat(url) {
    if (!button) return;
    const activeButton = button;
    if (active.has(url)) { display('busy','这篇文章正在下载','…'); return; }
    active.set(url, 'pending');
    updateBadge();
    clearTimeout(resetTimer);
    display('busy','正在提取文章内容…','…');
    try {
      const adapter = globalThis.WxdocAdapter;
      if (!adapter || !adapter.WECHAT_ADAPTER) {
        throw new Error('微信提取器未加载，请刷新页面');
      }
      const content = adapter.WECHAT_ADAPTER.extract(document, location);
      if (!content || !content.blocks || !content.blocks.length) {
        throw new Error('未提取到文章内容');
      }
      // 提交前归一化 original_url（去掉 chksm/scene/from 等跟踪参数），服务端据此去重
      content.original_url = normalizeArticleUrl(content.original_url) || url;
      display('busy','正在下载图片 (0/' + content.media.length + ')…','…');
      const result = await send('directSubmit', {url, content});
      if (button !== activeButton) return;
      if (!result?.ok) throw apiFailure(result, result?.error || '上传失败');
      if (result.data?.duplicate) {
        active.delete(url);
        display('ok','此文已在资料库','✓');
        scheduleReset(activeButton);
        return;
      }
      active.delete(url);
      const imgOk = result?.data?.savedMediaCount || 0;
      const imgTotal = content.media.length;
      const compressed = result?.data?.compressedCount || 0;
      if (imgTotal > 0 && imgOk < imgTotal) {
        display('ok','已保存 · ' + imgOk + '/' + imgTotal + ' 张图片' + (compressed > 0 ? ' · 压缩 ' + compressed + ' 张' : ''),'✓');
      } else {
        display('ok','已保存' + (imgTotal > 0 ? ' · ' + imgTotal + ' 张图片' : '') + (compressed > 0 ? ' · 压缩 ' + compressed + ' 张' : ''),'✓');
      }
      // 记录到本地历史
      await addDirectHistory({ title: content.title || url, itemCount: 1, articleId: result?.data?.articleId });
      scheduleReset(activeButton);
    } catch(e) {
      active.delete(url);
      if (button === activeButton) {
        if (isOffline(e)) showOffline();
        let msg = errorMessage(e);
        if (/未找到微信公众号文章|未找到文章内容|需要登录|需要验证码/.test(e?.message || '')) msg = e.message;
        if (/401|认证失败|Token/.test(e?.message || '')) msg = 'Token 无效，请重新配置';
        if (/超出上传限制|payload_too_large/.test(e?.message || '')) msg = e.message;
        display('err', msg, '!');
        scheduleReset(activeButton);
      }
    }
  }
  async function save() {
    if (!button) return;
    const url = articleUrl(), activeButton = button;
    if (!url) { refresh(); return; }
    // 微信文章直连模式
    if (directModeEnabled) {
      await directSubmitWeChat(url);
      return;
    }
    if (active.has(url)) { display('busy','这篇文章正在下载','…'); return; }
    active.set(url, 'pending');
    updateBadge();
    clearTimeout(resetTimer); display('busy','正在提交下载…','…');
    try {
      const result = await send('download', {url});
      if (button !== activeButton) return;
      if (!result?.ok) throw apiFailure(result, '提交失败');
      if (result.data?.duplicate && !result.data?.taskId) {
        active.delete(url);
        refreshRecent(); display('ok','这篇文章已在本地资料库','✓'); scheduleReset(activeButton); return;
      }
      if (result.data?.taskId) { active.set(url, result.data.taskId); pollTracker.set(result.data.taskId, {url, button: activeButton}); } else active.delete(url);
      display('busy','已提交，等待客户端下载','…');
      if (result.data?.taskId) { const t = setTimeout(() => poll(result.data.taskId, activeButton), 1000); pollTimers.add(t); } else scheduleReset(activeButton);
    } catch(e) { active.delete(url); if (button === activeButton) { if (isOffline(e)) showOffline(); display('err',errorMessage(e),'!'); scheduleReset(activeButton); } }
  }
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function fitPanel() {
    if (!panel || panel.hidden || !position) return;
    // 面板紧贴按钮左缘外 8px：双形态宽度不同，锚定值随宿主实测宽度写
    panel.style.right = `${(host?.offsetWidth || formSize().W) + 8}px`;
    panel.style.top = '0px';
    const h = panel.offsetHeight;
    const spaceBelow = innerHeight - position.top - 8;
    // 面板默认与按钮顶部对齐；下方放不下时整体上移，最高到距视口顶 8px，列表内部滚动
    const top = h <= spaceBelow ? 0 : Math.max(8 - position.top, spaceBelow - h);
    panel.style.top = `${top}px`;
  }
  function showPanel() {
    panel.hidden = false;
    fitPanel();
    refreshRecent().then(fitPanel);
    clearInterval(panelRefreshTimer);
    let tick = 0;
    panelRefreshTimer = setInterval(async () => {
      await refreshRecent();
      fitPanel();
      tick++;
      const hint = panel.querySelector('[data-refresh-hint]');
      if (hint) hint.textContent = offline ? (directModeEnabled ? '未连接服务端' : '未连接客户端') : `自动刷新 · ${tick * 2}s`;
    }, 2000);
    panelRefreshTimer?.unref?.();
  }
  function hidePanel() {
    clearInterval(panelRefreshTimer);
    if (panel) panel.hidden = true;
  }
  function refresh() {
    // 仅微信文章页挂载悬浮按钮：其他站点、微信非文章页都不显示
    const next = enabled ? articleUrl() : '';
    if (next !== currentUrl || (host && !host.isConnected)) { hidePanel(); remove(); currentUrl = next; }
    if (!next) return;
    if (!host) { mount(); refreshRecent(); recentTimer = setInterval(refreshRecent, 5000); recentTimer?.unref?.(); }
    updateIdle();
    checkVideoGap(next);
  }
  // 打开文章页时向服务器探测一次视频缺口（同地址不重复查）；仅桌面模式提供补齐
  function checkVideoGap(url) {
    if (directModeEnabled || !url || videoGapCheckedUrl === url) return;
    videoGapCheckedUrl = url;
    send('VIDEO_GAP_CHECK', { url }).then(r => {
      videoGap = (r?.ok && r.data) ? Object.assign({ url }, r.data) : null;
      if (panel && !panel.hidden) refreshRecent();
    }).catch(() => { videoGap = null; });
  }
  function videoGapRowHtml() {
    const g = videoGap;
    if (directModeEnabled || !g || g.url !== currentUrl) return '';
    const total = Number(g.videoCount) || 0, ready = Number(g.videoReady) || 0;
    if (!g.found || !total || ready >= total) return '';
    const off = !g.desktopOk;
    const tip = off ? '需桌面端在线补齐（扩展无 ffmpeg，m3u8 须在桌面端转码）' : '重新采集本页、补齐视频并同步到服务器';
    return `<div class="row"><div class="row-title">本文视频未补齐 ${ready}/${total}</div><div class="row-meta"><div class="row-status"><span>服务器已有该文，可在桌面端补齐</span></div><div class="row-tools"><button class="task-action" data-task-action="videoBackfill"${off ? ' disabled' : ''} title="${esc(tip)}">${off ? '需桌面端在线' : '补齐视频'}</button></div></div></div>`;
  }
  async function startVideoBackfill() {
    const url = currentUrl;
    if (!url) return;
    clearTimeout(resetTimer);
    display('busy','正在提交视频补齐任务…','…');
    try {
      const r = await send('VIDEO_BACKFILL', { url });
      if (!r?.ok) throw apiFailure(r, '提交失败');
      const taskId = r.data?.taskId;
      if (!taskId) { display('ok','桌面端已受理，请稍候','✓'); scheduleReset(button); return; }
      display('busy','桌面端正在补齐视频…','…');
      const t = setTimeout(() => pollVideoBackfill(taskId), 2000);
      pollTimers.add(t);
    } catch (e) {
      if (isOffline(e)) showOffline();
      display('err', errorMessage(e), '!');
      scheduleReset(button);
    }
  }
  async function pollVideoBackfill(taskId) {
    try {
      const r = await send('task', { taskId });
      if (!r?.ok) throw apiFailure(r, '任务查询失败');
      const t = r.data || {};
      if (t.status === 'completed' || t.status === 'partial_failed') {
        videoGap = null;
        display('ok', t.status === 'completed' ? '视频已补齐并同步到服务器' : '补齐完成，但部分媒体失败','✓');
        scheduleReset(button); refreshRecent(); return;
      }
      if (['failed','cancelled'].includes(t.status)) {
        display('err', t.error || '桌面端补齐失败，请在客户端查看任务', '!');
        scheduleReset(button); return;
      }
      display('busy','桌面端正在补齐视频…','…');
      const timer = setTimeout(() => pollVideoBackfill(taskId), 2000);
      pollTimers.add(timer);
    } catch (e) {
      if (isOffline(e)) showOffline();
      display('err', errorMessage(e), '!');
      scheduleReset(button);
    }
  }
  // 已存坐标必须两值都是有限数才采信（半个坐标不采信，整体回落默认锚点）；旧格式 {left,top} 无 collapsed 字段自然回落展开态
  function readPosition(p) {
    if (!p || !Number.isFinite(Number(p.left)) || !Number.isFinite(Number(p.top))) return null;
    return {left: Number(p.left), top: Number(p.top)};
  }
  // mode 缺省跟随 shared.js 收口默认（auto），避免与 background/options 三处口径漂移
  chrome.storage.local.get({position:null,enabled:true,mode:(self.WxdocShared&&self.WxdocShared.SETTINGS_DEFAULTS&&self.WxdocShared.SETTINGS_DEFAULTS.mode)||'auto'}, settings => {
    enabled = settings.enabled !== false;
    directModeEnabled = settings.mode === 'direct' || settings.mode === 'backend';
    position = readPosition(settings.position) || position;
    collapsed = !!settings.position?.collapsed;
    place(); refresh(); probeChannel();
    clearInterval(chanTimer);
    chanTimer = setInterval(probeChannel, 5000);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.enabled) enabled = changes.enabled.newValue !== false;
    if (changes.mode) { directModeEnabled = changes.mode.newValue === 'direct' || changes.mode.newValue === 'backend'; probeChannel(); }
    if (changes.serverUrl) probeChannel();
    if (changes.position) {
      position = readPosition(changes.position.newValue);
      collapsed = !!changes.position.newValue?.collapsed;
      place(); renderForm();
    }
    refresh();
  });
  const observer = new MutationObserver(refresh);
  observer.observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener('popstate',refresh);
  window.addEventListener('resize', () => { place(); fitPanel(); });
  const routeTimer = setInterval(refresh, 1000);
  window.addEventListener('pagehide', () => {observer.disconnect();clearInterval(routeTimer);clearInterval(chanTimer);clearInterval(recentTimer);clearTimeout(resetTimer);clearTimeout(pressTimer);clearInterval(panelRefreshTimer);for (const t of pollTimers) clearTimeout(t);pollTimers.clear();pollTracker.clear();}, {once:true});
})();
