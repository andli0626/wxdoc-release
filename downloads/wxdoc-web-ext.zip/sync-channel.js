// sync-channel.js · 文章同步通道（后端 JSON 推送 / 媒体分片上传）与身份派生
// 蓝本：email-web-ext/sync-channel.js，端点与字段按 docs 方案 §4.2/§4.3/§4.4 改造。
//
// 关键约定（实现前务必对齐方案原文）：
//   1. push/upload 的 404/405 语义分端点解读：push 路径 404/405 均视为"端点未实现"→ unavailable 可降级；
//      upload 路径 405=GET 在、POST 未实现→unavailable；404=articleId 记录不存在→business 不降级。
//   2. multipart 字段名是 file（对齐 email MediaController#upload），不是 media。
//   3. dedupKey 优先归一化 original_url；articleId='x'+sha256(dedupKey).slice(0,32)；
//      dirPath='文章_<清洗title,60>_x<sha256.slice(0,8)>'，重试恒定收敛。
//   4. 本文件不依赖 md-builder.js（background importScripts 未包含它），媒体 relPath 兜底规则在此自带镜像。
(function (root) {
  "use strict";

  /* ==================== 错误与分类 ==================== */

  // kind: 'unavailable' | 'auth' | 'business'
  function SyncError(kind, message, raw) {
    var e = new Error(message || kind);
    e.name = "SyncError";
    e.kind = kind;
    e.raw = raw;
    return e;
  }

  // 端点特定状态分类覆盖：命中即采用，否则回落到通用 classifyHttpStatus。
  var PUSH_STATUS_KINDS = { 404: "unavailable", 405: "unavailable" }; // 端点未实现 → 可降级
  var UPLOAD_STATUS_KINDS = { 405: "unavailable" }; // GET 在、POST 未实现 → 可降级；404 保持 business

  function classifyHttpStatus(status) {
    var s = Number(status) || 0;
    if (s >= 200 && s < 400) return null;
    if (s === 401 || s === 403) return "auth";
    if (s === 0 || s >= 500) return "unavailable";
    return "business";
  }

  // bodyText 为响应体原文（可能为空）；kindByStatus 为端点覆盖表。
  function syncErrorFromResponse(status, bodyText, kindByStatus) {
    var s = Number(status) || 0;
    var override = kindByStatus && kindByStatus[s];
    var kind = override || classifyHttpStatus(s);
    var msg = "";
    try {
      msg = bodyText ? String(bodyText).slice(0, 300) : "";
    } catch (e) {
      msg = "";
    }
    if (override) {
      // 端点未实现/服务不可用要能与业务错误区分，便于界面提示与降级决策
      return SyncError(kind, "后端端点未实现或服务不可用（HTTP " + s + "）" + (msg ? "：" + msg : ""), { status: s, body: bodyText });
    }
    var base = kind === "auth"
      ? "后端拒绝访问（HTTP " + s + "），请检查 API Token"
      : kind === "unavailable"
        ? "后端服务暂时不可用（HTTP " + s + "）"
        : "后端返回业务错误（HTTP " + s + "）";
    return SyncError(kind, msg ? base + "：" + msg : base, { status: s, body: bodyText });
  }

  /* ==================== 通道决策 ==================== */

  // 出参：backend | desktop | download | error
  // backend 锁定但不可用 → error（不降级，显式失败好过静默走本地）；
  // desktop 锁定但不在线 → download（本地通道始终可用，降级无害）。
  function resolveChannel(opts) {
    var mode = opts && opts.mode;
    var hasEndpoint = !!(opts && opts.hasEndpoint);
    var backendOk = !!(opts && opts.backendOk);
    var desktopOk = !!(opts && opts.desktopOk);
    if (mode === "backend") {
      if (!hasEndpoint) return "error";
      if (!backendOk) return "error";
      return "backend";
    }
    if (mode === "desktop") {
      return desktopOk ? "desktop" : "download";
    }
    if (hasEndpoint && backendOk) return "backend";
    if (desktopOk) return "desktop";
    return "download";
  }

  /* ==================== 身份派生 ==================== */

  function subtleSha256Hex(text) {
    var bytes = new TextEncoder().encode(String(text == null ? "" : text));
    var subtle = (typeof crypto !== "undefined" && crypto.subtle)
      ? crypto.subtle
      : (typeof globalThis !== "undefined" && globalThis.crypto && globalThis.crypto.subtle);
    if (!subtle) return Promise.reject(new Error("当前环境不支持 crypto.subtle，无法计算文章 ID"));
    return Promise.resolve(subtle.digest("SHA-256", bytes)).then(function (buf) {
      var out = "";
      var u8 = new Uint8Array(buf);
      for (var i = 0; i < u8.length; i++) out += (u8[i] < 16 ? "0" : "") + u8[i].toString(16);
      return out;
    });
  }

  function str(v) {
    return v == null ? "" : String(v);
  }

  // 兼容 snake_case 快照与 camelCase 契约两种字段名
  function pickField(obj, snake, camel) {
    if (!obj) return "";
    var v = obj[snake];
    if (v == null || v === "") v = obj[camel];
    return str(v).trim();
  }

  // dedupKey：优先归一化 original_url；缺失回落 title|authorName|publishTime。
  function dedupKeyOf(article) {
    var raw = pickField(article, "original_url", "sourceUrl");
    var normalize = (root.WxdocShared && typeof root.WxdocShared.normalizeArticleUrl === "function")
      ? root.WxdocShared.normalizeArticleUrl
      : null;
    var url = "";
    if (raw) {
      if (normalize) {
        url = str(normalize(raw));
      } else {
        // 兜底归一化：去 hash、去尾斜杠（与 shared.normalizeArticleUrl 的可解析分支一致）
        url = str(raw).trim().replace(/#.*$/, "").replace(/\/+$/, "");
      }
    }
    if (url) return url;
    var title = pickField(article, "title", "title");
    var author = pickField(article, "author_name", "authorName");
    var time = pickField(article, "publish_time", "publishTime");
    return [title, author, time].join("|");
  }

  var DIR_ILLEGAL = /[\\/:*?"<>|\u0000-\u001f]/g;

  // 标题清洗：优先复用 shared.sanitizeTitle 避免常量漂移；缺失时按同规则兜底。
  function cleanTitleForDir(title) {
    var shared = root.WxdocShared;
    if (shared && typeof shared.sanitizeTitle === "function") {
      return str(shared.sanitizeTitle(title, 60));
    }
    var clean = str(title).replace(/\s+/g, " ").trim().replace(DIR_ILLEGAL, "_");
    if (!clean) clean = "未命名文章";
    if (clean.length > 60) clean = clean.slice(0, 60);
    return clean;
  }

  // 出参 {articleId, dirPath, dedupKey}
  function deriveIdentities(dedupKey, title, hashImpl, sanitizeTitle) {
    var hash = typeof hashImpl === "function"
      ? hashImpl
      : function (t) {
        return subtleSha256Hex(t);
      };
    var clean = typeof sanitizeTitle === "function"
      ? sanitizeTitle(title, 60)
      : cleanTitleForDir(title);
    return Promise.resolve(hash(str(dedupKey))).then(function (hex) {
      var h = str(hex).toLowerCase();
      return {
        articleId: "x" + h.slice(0, 32),
        dirPath: "文章_" + clean + "_x" + h.slice(0, 8),
        dedupKey: str(dedupKey),
      };
    });
  }

  /* ==================== 媒体路径兜底（镜像 md-builder.js） ==================== */

  var MIME_EXT = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/bmp": "bmp",
    "image/svg+xml": "svg",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
  };
  var FALLBACK_EXT = { image: "png", video: "mp4" };

  function normalizeExt(ext) {
    var e = str(ext).toLowerCase();
    return e === "jpeg" ? "jpg" : e;
  }

  // guessMediaExt 返回 {ext, guessed}
  function guessMediaExt(url, kind) {
    var fallback = FALLBACK_EXT[str(kind) === "video" ? "video" : "image"] || "png";
    var raw = str(url);
    if (!raw) return { ext: fallback, guessed: true };
    var dataM = /^data:([^;,]+)/i.exec(raw);
    if (dataM) {
      var mapped = MIME_EXT[str(dataM[1]).toLowerCase()];
      if (mapped) return { ext: mapped, guessed: false };
    }
    try {
      var u = new URL(raw, "https://mp.weixin.qq.com/");
      var wxfmt = u.searchParams.get("wx_fmt");
      if (wxfmt) {
        var fmt = normalizeExt(wxfmt.split("?")[0]);
        if (fmt) return { ext: fmt, guessed: false };
      }
      var seg = u.pathname.split("/").pop() || "";
      var dot = seg.lastIndexOf(".");
      if (dot > 0 && dot < seg.length - 1) {
        var ext = normalizeExt(seg.slice(dot + 1));
        if (/^[a-z0-9]{2,5}$/.test(ext)) return { ext: ext, guessed: false };
      }
    } catch (e) {
      // URL 解析失败时继续走兜底
    }
    return { ext: fallback, guessed: true };
  }

  // 与 md-builder.mediaRelPath 同口径：images/image_N.ext / videos/video_N.ext
  function fallbackMediaRelPath(entry, index) {
    var kind = str(entry && (entry.media_type || entry.kind)) === "video" ? "video" : "image";
    var g = guessMediaExt(entry && entry.url, kind);
    var prefix = kind === "video" ? "videos/video_" : "images/image_";
    return prefix + (Number(index) || 0) + "." + g.ext;
  }

  // 读取任务媒体清单时优先使用 mediaFileMap 的 rel_path（下载通道口径），否则兜底自算。
  function relPathOfMedia(entry, index) {
    var rp = entry && (entry.rel_path || entry.relPath);
    if (rp) return str(rp);
    return fallbackMediaRelPath(entry, index);
  }

  /* ==================== HTTP ==================== */

  function fetchWithTimeout(fetchImpl, url, opts, timeoutMs) {
    var ms = Number(timeoutMs) || 0;
    var controller = (typeof AbortController !== "undefined") ? new AbortController() : null;
    var timer = null;
    var options = opts || {};
    if (controller) {
      options = Object.assign({}, opts, { signal: controller.signal });
    }
    if (controller && ms > 0) {
      timer = setTimeout(function () {
        try { controller.abort(); } catch (e) { /* 已结算则忽略 */ }
      }, ms);
    }
    return Promise.resolve(fetchImpl(url, options)).then(
      function (r) {
        if (timer) clearTimeout(timer);
        return r;
      },
      function (e) {
        if (timer) clearTimeout(timer);
        throw e;
      }
    );
  }

  function trimBase(endpoint) {
    return str(endpoint).replace(/\/+$/, "");
  }

  function authHeaders(token, extra) {
    var h = {};
    if (token) h["Authorization"] = "Bearer " + token;
    if (extra) Object.keys(extra).forEach(function (k) { h[k] = extra[k]; });
    return h;
  }

  // R 信封：{code:0,data:{...}}；缺 code 视为业务错误。
  function unwrapR(json) {
    if (!json || typeof json !== "object") {
      throw SyncError("business", "后端响应格式异常（非 JSON 对象）", json);
    }
    if (json.code !== 0) {
      throw SyncError("business", str(json.message || json.msg || "后端返回错误") + "（code=" + json.code + "）", json);
    }
    return json.data;
  }

  // kindByStatus：端点特定状态覆盖（push 传 PUSH_STATUS_KINDS，让 404/405 判 unavailable 可降级）。
  function requestJson(ctx, method, url, token, body, kindByStatus) {
    var opts = { method: method, mode: "cors", headers: authHeaders(token, body ? { "Content-Type": "application/json" } : null) };
    if (body !== undefined && body !== null) opts.body = JSON.stringify(body);
    return fetchWithTimeout(ctx.fetch, url, opts, ctx.timeoutMs || 10000).then(function (r) {
      if (!r.ok) {
        return Promise.resolve(r.text()).then(function (t) {
          throw syncErrorFromResponse(r.status, t, kindByStatus);
        });
      }
      return Promise.resolve(r.text()).then(function (t) {
        var json = null;
        try { json = t ? JSON.parse(t) : {}; } catch (e) {
          throw SyncError("business", "后端响应不是合法 JSON", t);
        }
        return unwrapR(json);
      });
    }).catch(function (e) {
      if (e && e.name === "SyncError") throw e;
      throw SyncError("unavailable", "无法连接后端服务（网络或地址不可达）", e && e.message);
    });
  }

  /* ==================== 探测与门控 ==================== */

  function probeBackend(endpoint, ctx) {
    var url = trimBase(endpoint) + "/api/health";
    return fetchWithTimeout(ctx.fetch, url, { method: "GET", mode: "cors" }, ctx.timeoutMs || 2000)
      .then(function (r) {
        if (!r.ok) return { ok: false };
        return Promise.resolve(r.text()).then(function (t) {
          var json = null;
          try { json = t ? JSON.parse(t) : {}; } catch (e) { json = {}; }
          return { ok: true, serverTime: json && json.data && Number(json.data.serverTime) || 0 };
        });
      })
      .catch(function () { return { ok: false }; });
  }

  /**
   * GET {endpoint}/api/service-addresses?type=api（服务端内置接口地址列表，免鉴权只读）。
   * 响应为 R 信封，成功返回 data = {version,count,items:[{name,url,type,note}]}；
   * version 为单调递增 epoch ms，调用方据此做缓存新旧判定。ctx 可注入（测试桩）。
   */
  function fetchServiceAddresses(endpoint, ctx) {
    var c = ctx || { fetch: root.fetch, timeoutMs: 10000 };
    var url = trimBase(endpoint) + "/api/service-addresses?type=api";
    return requestJson(c, "GET", url, "", null);
  }

  function makeBackendGate(ttlMs, probeFn) {
    var ttl = Number(ttlMs) || 30000;
    var cache = null; // {endpoint, ok, serverTime, at}
    return {
      check: function (endpoint, ctx) {
        var now = Date.now();
        if (cache && cache.endpoint === endpoint && now - cache.at < ttl) {
          return Promise.resolve({ ok: cache.ok, serverTime: cache.serverTime });
        }
        return Promise.resolve(probeFn(endpoint, ctx)).then(function (res) {
          cache = { endpoint: endpoint, ok: !!res.ok, serverTime: res.serverTime || 0, at: Date.now() };
          return { ok: cache.ok, serverTime: cache.serverTime };
        });
      },
      invalidate: function () { cache = null; },
      _cache: function () { return cache; },
    };
  }

  /* ==================== 组装与推送 ==================== */

  // task：background 组装的任务（snake_case 快照 + 派生身份 + bodyMd + media 清单）
  // 出参 §4.2 ArticleSyncItem。
  function buildPushItem(task, deviceId) {
    var snapshot = task && task.snapshot ? task.snapshot : (task || {});
    var mediaList = Array.isArray(task.media) && task.media.length
      ? task.media
      : (Array.isArray(snapshot.media) ? snapshot.media : []);
    var blocks = Array.isArray(task.blocks) ? task.blocks : (Array.isArray(snapshot.blocks) ? snapshot.blocks : []);
    var counts = task.counts && typeof task.counts === "object"
      ? task.counts
      : { imageCount: 0, videoCount: 0 };

    return {
      id: str(task.articleId),
      dirPath: str(task.dirPath),
      title: str(pickField(snapshot, "title", "title") || task.title),
      authorName: pickField(snapshot, "author_name", "authorName"),
      authorHandle: pickField(snapshot, "author_handle", "authorHandle"),
      source: str(task.source || pickField(snapshot, "source", "adapter")),
      publishTime: pickField(snapshot, "publish_time", "publishTime"),
      sourceUrl: str(task.sourceUrl || pickField(snapshot, "original_url", "sourceUrl")),
      exportedAt: Number(task.exportedAt) || 0,
      bodyMd: str(task.bodyMd || ""),
      blocks: blocks.map(function (b) {
        return {
          kind: str(b && b.kind),
          text: str(b && (b.text != null ? b.text : "")),
          html: str(b && (b.html != null ? b.html : "")),
        };
      }),
      imageCount: Number(counts.imageCount) || 0,
      videoCount: Number(counts.videoCount) || 0,
      totalBytes: Number(task.totalBytes) || 0,
      dedupKey: str(task.dedupKey),
      deviceId: str(deviceId == null ? task.deviceId : deviceId),
      createdAt: Number(task.createdAt) || 0,
      updatedAt: Number(task.updatedAt) || 0,
      syncVersion: Number(task.syncVersion) || 1,
      media: mediaList.map(function (m, i) {
        var relPath = relPathOfMedia(m, i);
        var slash = relPath.lastIndexOf("/");
        return {
          id: str(m && (m.id || m.attId)) || ("m" + i),
          articleId: str(task.articleId),
          kind: str(m && (m.media_type || m.kind)) === "video" ? "video" : "image",
          relPath: relPath,
          name: str(m && m.name) || relPath.slice(slash + 1),
          size: Number(m && m.size) || 0,
          sha256: str(m && m.sha256) || "",
          status: str(m && m.status) || "pending",
        };
      }),
    };
  }

  // ctx 可注入（测试桩）；默认取 root.fetch。成功判读（对齐 email pushMail，勿自定义）：
  // applied≥1 或 conflicts≥1 成功；skipped>0 且其余全零 → business 不降级；
  // 全零同样判 business（服务端未处理该记录，避免虚假成功）。
  function pushArticle(endpoint, token, deviceId, deviceName, item, ctx) {
    var c = ctx || { fetch: root.fetch, timeoutMs: 30000 };
    var url = trimBase(endpoint) + "/api/articles/sync/push";
    var body = { deviceId: str(deviceId), deviceName: str(deviceName), records: [item] };
    return requestJson(c, "POST", url, token, body, PUSH_STATUS_KINDS).then(function (data) {
      var applied = Number(data && data.applied) || 0;
      var conflicts = Number(data && data.conflicts) || 0;
      var skipped = Number(data && data.skipped) || 0;
      var serverTime = Number(data && data.serverTime) || 0;
      if (applied >= 1 || conflicts >= 1) {
        return { applied: applied, conflicts: conflicts, skipped: skipped, serverTime: serverTime, converged: conflicts >= 1 };
      }
      if (skipped > 0) {
        throw SyncError("business", "记录被服务端跳过（id 缺失或请求体异常）", data);
      }
      throw SyncError("business", "服务端未处理该记录（applied/conflicts/skipped 均为 0）", data);
    });
  }

  // POST /api/articles/{id}/media?relPath=<相对路径>，multipart 字段名 file。
  // 405=GET 在、POST 未实现→unavailable 可降级；404=articleId 记录不存在→business 不降级。
  function uploadMedia(endpoint, token, articleId, relPath, blob, ctx) {
    var c = ctx || { fetch: root.fetch, timeoutMs: 120000 };
    var url = trimBase(endpoint) + "/api/articles/" + encodeURIComponent(str(articleId)) + "/media?relPath=" + encodeURIComponent(str(relPath));
    var fd = new FormData();
    var name = str(relPath).slice(str(relPath).lastIndexOf("/") + 1) || "file.bin";
    fd.append("file", blob, name);
    var opts = { method: "POST", mode: "cors", headers: authHeaders(token), body: fd };
    return fetchWithTimeout(c.fetch, url, opts, c.timeoutMs || 120000).then(function (r) {
      if (!r.ok) {
        return Promise.resolve(r.text()).then(function (t) {
          throw syncErrorFromResponse(r.status, t, UPLOAD_STATUS_KINDS);
        });
      }
      return Promise.resolve(r.text()).then(function (t) {
        var json = null;
        try { json = t ? JSON.parse(t) : {}; } catch (e) {
          throw SyncError("business", "后端响应不是合法 JSON", t);
        }
        return unwrapR(json);
      });
    }).catch(function (e) {
      if (e && e.name === "SyncError") throw e;
      throw SyncError("unavailable", "无法连接后端服务（网络或地址不可达）", e && e.message);
    });
  }

  /* ==================== 时钟校准 ==================== */

  // 客户端时钟超前会永久压制 LWW，故以服务端时间为准计算偏移。
  function calibrateOffset(serverTime, nowMs) {
    var st = Number(serverTime) || 0;
    if (st <= 0) return 0;
    return st - (Number(nowMs) || Date.now());
  }
  function stampTime(offsetMs, nowMs) {
    return (Number(nowMs) || Date.now()) + (Number(offsetMs) || 0);
  }

  var api = {
    SyncError: SyncError,
    classifyHttpStatus: classifyHttpStatus,
    syncErrorFromResponse: syncErrorFromResponse,
    PUSH_STATUS_KINDS: PUSH_STATUS_KINDS,
    UPLOAD_STATUS_KINDS: UPLOAD_STATUS_KINDS,
    resolveChannel: resolveChannel,
    subtleSha256Hex: subtleSha256Hex,
    dedupKeyOf: dedupKeyOf,
    deriveIdentities: deriveIdentities,
    guessMediaExt: guessMediaExt,
    fallbackMediaRelPath: fallbackMediaRelPath,
    fetchWithTimeout: fetchWithTimeout,
    trimBase: trimBase,
    authHeaders: authHeaders,
    unwrapR: unwrapR,
    requestJson: requestJson,
    probeBackend: probeBackend,
    fetchServiceAddresses: fetchServiceAddresses,
    makeBackendGate: makeBackendGate,
    buildPushItem: buildPushItem,
    pushArticle: pushArticle,
    uploadMedia: uploadMedia,
    calibrateOffset: calibrateOffset,
    stampTime: stampTime,
  };
  root.WxdocSyncChannel = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : globalThis);
