// 访问入口环境集：popup 与 options 共用的唯一口径。
// 地址依据 docs/03-验收文档/36-端口矩阵与接口服务地址.md 与 deploy/ 各栈 compose 实测端口。
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.WwcnEntries = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ENTRY_KEYS = ['web', 'h5', 'app', 'apiDoc', 'admin'];
  var ENTRY_LABELS = {
    web: 'Web 阅读端（PC）',
    h5: 'H5 访问页（移动端）',
    app: '手机 APP 下载页（安卓 · 蒲公英）',
    apiDoc: 'API 文档页（获取直连访问令牌）',
    admin: '服务地址管理页（PC Web）'
  };
  // APP 下载地址与桌面端「手机 APP」分区同口径
  var DEFAULT_APP_INSTALL_URL = 'https://www.pgyer.com/wxdoc';

  var STORAGE_DEFAULTS = {
    entryProfile: 'follow',
    entryWebUrl: '',
    entryH5Url: '',
    entryAppUrl: '',
    entryApiDocUrl: '',
    entryAdminUrl: ''
  };

  function originOf(url) {
    try { return new URL(url).origin; } catch (e) { return ''; }
  }

  // 「跟随服务端地址」：仅统一网关（/ · /h5/ · /api 同端口）拓扑下四入口同源可达。
  // 后端与前端分端口/分主机部署（NAS 26690/27788、mac-epoint 换机）推导不出正确页面，
  // 故不做端口猜测，此类环境用下方具名环境或在设置页手填。
  function deriveEntryUrls(serverUrl) {
    var out = { web: '', h5: '', app: DEFAULT_APP_INSTALL_URL, apiDoc: '', admin: '' };
    var origin = originOf(serverUrl);
    if (origin) {
      out.web = origin + '/';
      out.h5 = origin + '/h5/';
      out.apiDoc = origin + '/api-doc';
      out.admin = origin + '/service-addresses';
    }
    return out;
  }

  function gatewayUrls(port) {
    var origin = 'http://127.0.0.1:' + port;
    return { web: origin + '/', h5: origin + '/h5/', apiDoc: origin + '/api-doc', admin: origin + '/service-addresses' };
  }

  // notes 逐项附在入口按钮/设置页提示上：既解释"为何置灰"，也解释"这个入口指向别处"。
  // h5: null 表示该环境自身没有 H5 —— 前端 nginx 无 /h5/ 路由时会被 SPA 兜底成 PC 页，
  // 属于"假打开"，所以要么置灰，要么显式给一个可用地址并在 note 里说明数据来源。
  var PROFILES = [
    { id: 'follow', label: '跟随服务端地址（默认）', dynamic: true },
    { id: 'local-gw', label: '本机 Docker 统一网关', urls: gatewayUrls(16702) },
    { id: 'local-test-gw', label: '本机 Docker 测试栈网关', urls: gatewayUrls(26702) },
    {
      id: 'local-direct', label: '本机 Docker 前端直连',
      urls: {
        web: 'http://127.0.0.1:16699/',
        h5: 'http://127.0.0.1:16701/h5/',
        apiDoc: 'http://127.0.0.1:16699/api-doc',
        admin: 'http://127.0.0.1:16699/service-addresses'
      }
    },
    {
      id: 'nas', label: 'NAS 飞牛 192.168.10.222',
      urls: {
        web: 'http://192.168.10.222:27788/',
        h5: 'http://127.0.0.1:16702/h5/',
        apiDoc: 'http://192.168.10.222:27788/api-doc',
        admin: 'http://192.168.10.222:27788/service-addresses'
      },
      notes: {
        h5: 'NAS 栈未部署 H5（compose 仅 backend 26690 + frontend 27788），此入口指向本机 Docker 统一网关，打开的是本机库'
      }
    }
  ];

  function profileById(id) {
    for (var i = 0; i < PROFILES.length; i++) {
      if (PROFILES[i].id === id) return PROFILES[i];
    }
    return null;
  }

  function manualKey(key) {
    return 'entry' + key.charAt(0).toUpperCase() + key.slice(1) + 'Url';
  }

  function trim(v) { return String(v == null ? '' : v).trim(); }

  // 解析各入口最终地址。具名环境即最终地址（手填不生效），保证 popup 与设置页不会打开不同页面。
  function resolveEntries(state) {
    var s = state || {};
    var profile = profileById(s.entryProfile) ? s.entryProfile : 'follow';
    var p = profileById(profile);
    var derived = deriveEntryUrls(s.serverUrl);
    var urls = {}, sources = {}, notes = {};

    ENTRY_KEYS.forEach(function (key) {
      var manual = trim(s[manualKey(key)]);
      if (p.dynamic) {
        if (key === 'app') {
          urls.app = manual || DEFAULT_APP_INSTALL_URL;
          sources.app = manual ? '手动设置' : '内置默认';
          return;
        }
        urls[key] = manual || derived[key] || '';
        sources[key] = manual ? '手动设置' : (urls[key] ? '自动推导' : '未设置');
        return;
      }
      var preset = p.urls[key];
      if (p.notes && p.notes[key]) notes[key] = p.notes[key];
      if (key === 'app' && !preset) {
        urls.app = DEFAULT_APP_INSTALL_URL;
        sources.app = '内置默认';
        return;
      }
      if (preset == null) {
        urls[key] = '';
        sources[key] = '该环境无此入口';
        return;
      }
      urls[key] = preset;
      sources[key] = '环境预设';
    });

    return { profile: profile, urls: urls, sources: sources, notes: notes };
  }

  function isHttpUrl(url) {
    return /^https?:\/\//i.test(String(url || '').trim());
  }

  // 开新标签属于用户手势导航，不受 host_permissions 与 CORS 约束，无需申请权限
  function openEntry(url) {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: url });
      return true;
    }
    if (typeof window !== 'undefined' && window.open) {
      window.open(url, '_blank', 'noopener');
      return true;
    }
    return false;
  }

  return {
    ENTRY_KEYS: ENTRY_KEYS,
    ENTRY_LABELS: ENTRY_LABELS,
    DEFAULT_APP_INSTALL_URL: DEFAULT_APP_INSTALL_URL,
    STORAGE_DEFAULTS: STORAGE_DEFAULTS,
    PROFILES: PROFILES,
    profileById: profileById,
    deriveEntryUrls: deriveEntryUrls,
    resolveEntries: resolveEntries,
    manualKey: manualKey,
    isHttpUrl: isHttpUrl,
    openEntry: openEntry
  };
});
