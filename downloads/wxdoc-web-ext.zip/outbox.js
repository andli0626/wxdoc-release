/**
 * outbox.js — WxdocOutbox 发件箱（文章同步）
 *
 * 作用：把待同步/同步失败的文章任务持久化到 chrome.storage.local，
 * 按 FIFO 顺序重试，与 email-web-ext/outbox.js 同构。
 *
 * 方案 §5.5 约定（原文）：
 *   「结构同 email：readAll/writeAll/upsert/remove/clear、
 *     entryFromArticle(task,error)、mediaComplete/pendingMediaNames；
 *     key 用 articleId；上限 200。」
 *
 * 关键约定：
 *   1. 只存元数据与 bodyMd，不存二进制（媒体 blob 在 flush 时按媒体 URL 重新 fetch CDN）。
 *   2. key = articleId，upsert 时同 key 合并，保留原 createdAt 并累计 attempts。
 *   3. mediaComplete（无 pending/failed）才允许出队；否则保留等待 flush 补传媒体。
 *   4. auth/business 错误保留并累计 attempts 指数退避；unavailable 不累计（门控期后重试）。
 *   5. task 快照字段兼容 snake_case（md-builder 口径）与 camelCase（契约口径）。
 */
(function (root) {
  "use strict";

  var OUTBOX_KEY = "outbox";
  var OUTBOX_MAX = 200;

  function str(v) {
    return v == null ? "" : String(v);
  }

  // snake_case 快照与 camelCase 契约字段兼容取数。
  function pickField(obj, snake, camel) {
    if (!obj) return "";
    var v = obj[snake];
    if (v == null || v === "") v = obj[camel];
    return v == null ? "" : v;
  }

  function readAll(storage) {
    return Promise.resolve(storage.get({ outbox: [] })).then(function (res) {
      var list = (res && res.outbox) || [];
      return list.filter(function (x) { return x && x.key; });
    });
  }

  function writeAll(storage, list) {
    return Promise.resolve(storage.set({ outbox: list }));
  }

  // 同 key 合并：保留较早 createdAt，attempts 累加；超上限丢最旧。
  function upsert(storage, entry) {
    if (!entry || !entry.key) return Promise.resolve({ ok: false, error: "entry 缺少 key" });
    return readAll(storage).then(function (list) {
      var idx = -1;
      for (var i = 0; i < list.length; i++) {
        if (list[i].key === entry.key) { idx = i; break; }
      }
      var evicted = [];
      if (idx >= 0) {
        var prev = list[idx];
        var next = Object.assign({}, prev, entry);
        next.createdAt = prev.createdAt || entry.createdAt || Date.now();
        next.attempts = (Number(prev.attempts) || 0) + (Number(entry.attempts) || 0);
        list[idx] = next;
      } else {
        var fresh = Object.assign({}, entry);
        fresh.createdAt = entry.createdAt || Date.now();
        fresh.attempts = Number(entry.attempts) || 0;
        list.push(fresh);
      }
      if (list.length > OUTBOX_MAX) {
        evicted = list.splice(0, list.length - OUTBOX_MAX);
      }
      return writeAll(storage, list).then(function () {
        return { ok: true, evicted: evicted };
      });
    });
  }

  function remove(storage, key) {
    return readAll(storage).then(function (list) {
      var kept = list.filter(function (x) { return x.key !== key; });
      var removed = kept.length !== list.length;
      return writeAll(storage, kept).then(function () {
        return { ok: true, removed: removed };
      });
    });
  }

  function clear(storage) {
    return writeAll(storage, []).then(function () { return { ok: true }; });
  }

  /**
   * task：background 组装的任务快照（与 buildPushItem 同源）：
   *   {articleId, dirPath, dedupKey, title, author_name, author_handle,
   *    source, original_url/sourceUrl, bodyMd, imageCount, videoCount,
   *    totalBytes, createdAt, updatedAt, syncVersion,
   *    media:[{id|attId, kind|media_type, rel_path|relPath, name, size, status}]}
   * error：SyncError（可空）。
   */
  function entryFromArticle(task, error) {
    var now = Date.now();
    var media = Array.isArray(task.media) ? task.media : [];
    return {
      key: str(task.articleId),
      articleId: str(task.articleId),
      dedupKey: str(task.dedupKey),
      dirPath: str(task.dirPath),
      title: str(task.title || pickField(task, "title", "title")),
      authorName: pickField(task, "author_name", "authorName"),
      authorHandle: pickField(task, "author_handle", "authorHandle"),
      source: str(task.source || pickField(task, "source", "adapter")),
      sourceUrl: str(task.sourceUrl || pickField(task, "original_url", "sourceUrl")),
      bodyMd: str(task.bodyMd || ""),
      imageCount: Number(task.imageCount) || 0,
      videoCount: Number(task.videoCount) || 0,
      totalBytes: Number(task.totalBytes) || 0,
      createdAt: Number(task.createdAt) || now,
      updatedAt: Number(task.updatedAt) || now,
      syncVersion: Number(task.syncVersion) || 1,
      media: media.map(function (m, i) {
        var relPath = str(m.rel_path || m.relPath || "");
        var slash = relPath.lastIndexOf("/");
        return {
          id: str(m.id || m.attId) || ("m" + i),
          articleId: str(task.articleId),
          kind: str(m.media_type || m.kind) === "video" ? "video" : "image",
          relPath: relPath,
          name: str(m.name) || relPath.slice(slash + 1),
          // url 必须持久化：发件箱只存元数据，flush 时按 CDN URL 重新 fetch 二进制
          url: str(m.url || m.src || ""),
          size: Number(m.size) || 0,
          sha256: str(m.sha256) || "",
          status: str(m.status) || "pending",
        };
      }),
      attempts: 1,
      lastError: error
        ? { kind: str(error.kind), message: str(error.message) }
        : null,
      queuedAt: now,
    };
  }

  // 媒体全部 ok 才算完成（无 pending/failed）。
  function mediaComplete(entry) {
    var media = entry.media || entry.files || [];
    if (!media.length) return true;
    return media.every(function (m) { return m && m.status === "ok"; });
  }

  // 未完成媒体名清单，供界面提示「还有 N 个媒体未同步」。
  function pendingMediaNames(entry) {
    var media = entry.media || entry.files || [];
    return media
      .filter(function (m) { return m && m.status !== "ok"; })
      .map(function (m) { return str(m.name || m.relPath) || "未命名"; });
  }

  var api = {
    OUTBOX_KEY: OUTBOX_KEY,
    OUTBOX_MAX: OUTBOX_MAX,
    readAll: readAll,
    writeAll: writeAll,
    upsert: upsert,
    remove: remove,
    clear: clear,
    entryFromArticle: entryFromArticle,
    mediaComplete: mediaComplete,
    pendingMediaNames: pendingMediaNames,
  };

  root.WxdocOutbox = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : globalThis);
