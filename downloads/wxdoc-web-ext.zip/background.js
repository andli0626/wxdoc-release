/**
 * background.js — 微文存阅浏览器扩展 v2.0.0 后台编排（MV3 Service Worker）
 *
 * 职责（方案 §5.8）：
 *   1. 三通道编排：backend（JSON 推送 + 逐媒体上传）→ desktop（本地桥）→ download（内容帧构建 md 后落盘）
 *   2. 发件箱 flush：SW 启动 / alarms(~2min) / 成功探活 / popup 手动
 *   3. 媒体 fetch + 图片压缩（OffscreenCanvas）+ 30MB 客户端硬上限
 *   4. 键盘命令 save-article、安装通知、完成通知
 *
 * 环境适配：
 *   - Service Worker：importScripts("shared.js","sync-channel.js","outbox.js")
 *   - node --test：require 同目录三个 UMD 模块
 *   - md-builder.js 绝不进 SW（htmlToMarkdown 依赖 turndown/DOM），故 rewriteMediaPaths 在本文件本地实现
 *
 * 关键约束：
 *   - source 一律由 Shared.pickSource(host) 按 host 派生，严禁硬编码 'wechat'
 *   - 桌面桥响应不是 R 信封，必须自行 r.text() + JSON.parse，不能走 Sync.requestJson
 *   - 后端门控 check(endpoint, ctx) 只接受两个参数（ctx 内含 fetch/timeoutMs）
 */
(function (root) {
  "use strict";

  /* ==================== 环境装载 ==================== */

  var IS_SERVICE_WORKER = typeof importScripts === "function";
  if (IS_SERVICE_WORKER) {
    importScripts("shared.js", "sync-channel.js", "outbox.js");
  } else if (typeof module !== "undefined" && module.exports) {
    require("./shared.js");
    require("./sync-channel.js");
    require("./outbox.js");
  }

  var Shared = root.WxdocShared;
  var Sync = root.WxdocSyncChannel;
  var Outbox = root.WxdocOutbox;
  var HAS_CHROME = typeof chrome !== "undefined" && !!chrome.runtime && !!chrome.runtime.id;

  if (!Shared || !Sync || !Outbox) {
    throw new Error("background.js 依赖 shared.js / sync-channel.js / outbox.js，请按顺序装载");
  }

  /* ==================== 常量 ==================== */

  var BACKEND_PROBE_TIMEOUT_MS = 2000;      // §4.1 探活
  var BACKEND_PUSH_TIMEOUT_MS = 30000;      // §3.1 push
  var BACKEND_UPLOAD_TIMEOUT_MS = 120000;   // §3.1 逐媒体上传
  var BACKEND_GATE_TTL_MS = 30000;          // 门控缓存 TTL
  var MEDIA_FETCH_TIMEOUT_MS = 120000;      // SW 侧 CDN fetch
  var DESKTOP_TIMEOUT_MS = 10000;           // 桌面桥单次调用
  var DESKTOP_POLL_INTERVAL_MS = 2000;      // 桌面任务轮询
  var DESKTOP_POLL_MAX_MS = 300000;         // 桌面任务轮询上限 5min
  var COMPRESS_MAX_DIM = 1920;              // 图片压缩：最长边
  var COMPRESS_QUALITY = 0.85;              // 图片压缩：JPEG 质量
  var COMPRESS_MAX_BYTES = 2 * 1024 * 1024; // 图片压缩：单张阈值
  var CLIENT_PAYLOAD_MAX_BYTES = 30 * 1024 * 1024; // 客户端硬上限（payload_too_large）
  var EXPORT_LOCK_TTL_MS = 10 * 60 * 1000;  // 每 tab 互斥锁 TTL
  var OUTBOX_FLUSH_ALARM = "wxdoc-outbox-flush";
  var OUTBOX_FLUSH_PERIOD_MINUTES = 2;
  var OBJECT_URL_TTL_MS = 5 * 60 * 1000;    // download 通道 blob URL 保守回收
  var SERVICE_ADDRESSES_TTL_MS = 60 * 60 * 1000; // 内置接口地址列表缓存 TTL（1h）

  var DESKTOP_TERMINAL_STATUS = {
    completed: true,
    failed: true,
    cancelled: true,
    paused: true,
    partial_failed: true
  };

  /* ==================== 错误与小工具 ==================== */

  function str(v) {
    return v == null ? '' : String(v);
  }

  function wxError(code, message, raw) {
    var e = new Error(message);
    e.code = code;
    if (raw !== undefined) e.raw = raw;
    return e;
  }

  function escapeRegExp(s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function hostOf(url) {
    var u = Shared.parseUrl(url);
    return u && u.hostname ? String(u.hostname).toLowerCase() : "";
  }

  function refererFor(url) {
    var u = Shared.parseUrl(url);
    return u && u.origin ? u.origin + "/" : "https://mp.weixin.qq.com/";
  }

  function lastSegment(p) {
    var s = String(p == null ? "" : p);
    var i = s.lastIndexOf("/");
    return i >= 0 ? s.slice(i + 1) : s;
  }

  function replaceExt(relPath, ext) {
    var p = String(relPath == null ? "" : relPath);
    return p.replace(/\.[a-z0-9]+$/i, "") + "." + ext;
  }

  /* ==================== 纯函数：媒体计划与路径改写 ==================== */

  // kind 归一：video / image / poster（poster 为视频封面的独立展开项）
  function mediaKindOf(media) {
    var k = String((media && (media.media_type || media.kind)) || "").toLowerCase();
    if (k === "video") return "video";
    if (k === "poster") return "poster";
    return "image";
  }

  // 单一事实源：优先内容帧快照携带的 rel_path（md-builder.mediaFileMap 生成），否则兜底推导
  function relPathOf(media, index) {
    var m = media || {};
    var rp = m.rel_path || m.relPath;
    if (rp) return String(rp);
    return Sync.fallbackMediaRelPath(m, index);
  }

  /**
   * 把内容帧快照的 media 列表展开为扁平上传计划。
   * 视频的 poster 展开为独立项（kind='poster'），与正片同等对待。
   */
  function planMedia(mediaList) {
    var list = Array.isArray(mediaList) ? mediaList : [];
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var m = list[i] || {};
      var kind = mediaKindOf(m);
      var url = String(m.url || m.src || "");
      if (!url) continue;
      out.push({
        kind: kind,
        url: url,
        relPath: relPathOf(m, out.length),
        sha256: String(m.sha256 || ""),
        size: Number(m.size) || 0,
        declared: Number(m.filesize) || 0,
        index: out.length
      });
      var posterUrl = String(m.poster_url || m.posterUrl || m.poster || "");
      if (kind === "video" && posterUrl) {
        out.push({
          kind: "poster",
          url: posterUrl,
          relPath: String(m.poster_rel_path || m.posterRelPath || "") ||
            Sync.fallbackMediaRelPath({ url: posterUrl, kind: "image" }, out.length),
          sha256: "",
          size: 0,
          index: out.length
        });
      }
    }
    return out;
  }

  /**
   * 压缩产物统一为 image/jpeg，落盘/推送的扩展名必须跟着改成 .jpg，
   * 否则 JPEG 字节被存成 .png/.gif，服务端按扩展名判类型会出错。
   */
  function finalRelPathFor(entry, blob) {
    var mime = (blob && blob.type) || "";
    if (/^image\/jpe?g$/i.test(mime)) return replaceExt(entry.relPath, "jpg");
    return entry.relPath;
  }

  /**
   * 就地改写 bodyMd 中的媒体引用（仅替换 markdown 链接/图片目标 `](path)`，不做全文裸替换，
   * 避免 image_0 误伤 image_01）。
   */
  function rewriteMediaPaths(md, replacements) {
    var out = String(md == null ? "" : md);
    if (!replacements || !replacements.length) return out;
    for (var i = 0; i < replacements.length; i++) {
      var r = replacements[i];
      var from = r && r.from;
      var to = r && r.to;
      if (!from || !to || from === to) continue;
      var re = new RegExp("(\\(\\s*[\"']?)" + escapeRegExp(from) + "([\"']?\\s*\\))", "g");
      out = out.replace(re, "$1" + to + "$2");
    }
    return out;
  }

  function conflictActionFor(policy) {
    return policy === "new" ? "uniquify" : "overwrite";
  }

  function isTerminalDesktopStatus(st) {
    return !!DESKTOP_TERMINAL_STATUS[String(st || "")];
  }

  function estimatePayloadBytes(bodyMd, items) {
    var size = String(bodyMd == null ? "" : bodyMd).length;
    var list = items || [];
    for (var i = 0; i < list.length; i++) {
      var b = list[i] && list[i].blob;
      if (b && typeof b.size === "number") size += b.size;
    }
    return size;
  }

  /* ==================== 纯函数：通道解析 ==================== */

  function channelReasonText(channel, s) {
    if (channel !== "error") return "";
    if (s.mode === "backend") {
      if (!Sync.trimBase(s.serverUrl || "")) {
        return "已选择「仅后端」通道，但尚未配置后端地址，请到设置页填写";
      }
      return "后端探活失败（地址不可达或返回异常），请检查后端服务与地址配置";
    }
    return "当前同步模式无法确定有效通道";
  }

  /**
   * 把探测结果翻译成通道决策（resolveChannel 纯函数的胶水层）。
   * probe = { desktop: {ok, version}, backend: {ok, serverTime} }
   */
  function resolveChannelState(s, probe) {
    probe = probe || {};
    var desktop = probe.desktop || {};
    var backend = probe.backend || {};
    var hasEndpoint = !!Sync.trimBase(s.serverUrl || "");
    var channel = Sync.resolveChannel({
      mode: s.mode,
      hasEndpoint: hasEndpoint,
      backendOk: !!backend.ok,
      desktopOk: !!desktop.ok
    });
    return {
      mode: s.mode,
      channel: channel,
      hasEndpoint: hasEndpoint,
      backendOk: !!backend.ok,
      desktopOk: !!desktop.ok,
      backendServerTime: Number(backend.serverTime) || 0,
      desktopVersion: String(desktop.version || ""),
      reason: channelReasonText(channel, s)
    };
  }

  /* ==================== 设置与探测 ==================== */

  var backendGate = null;

  function getBackendGate() {
    if (!backendGate) {
      backendGate = Sync.makeBackendGate(BACKEND_GATE_TTL_MS, Sync.probeBackend);
    }
    return backendGate;
  }

  function getSettings() {
    return Shared.getSettings();
  }

  function desktopHeaders(s, json) {
    var h = {};
    if (s.token) h.Authorization = "Bearer " + s.token;
    if (json) h["Content-Type"] = "application/json";
    return h;
  }

  /**
   * 桌面桥调用：响应不是 R 信封，必须自行 text() + JSON.parse（不得走 Sync.requestJson）。
   * 返回 { status, ok, json, text }
   */
  function desktopCall(s, path, options, timeoutMs) {
    var base = String(s.baseUrl || Shared.DESKTOP_BASE_URL).replace(/\/+$/, "");
    return Sync.fetchWithTimeout(root.fetch, base + path, options, timeoutMs || DESKTOP_TIMEOUT_MS)
      .then(function (r) {
        return r.text().then(function (t) {
          var json = null;
          try { json = t ? JSON.parse(t) : {}; } catch (e) { json = {}; }
          return { status: r.status, ok: r.ok, json: json, text: t };
        });
      })
      .catch(function (e) {
        if (e && e.name === "SyncError") throw e;
        throw wxError("desktop_unavailable", "无法连接桌面端（请确认微文存阅客户端已打开）", e);
      });
  }

  function probeDesktop(s) {
    return desktopCall(s, "/health", {
      method: "GET",
      mode: "cors",
      headers: desktopHeaders(s, false)
    }, BACKEND_PROBE_TIMEOUT_MS).then(function (r) {
      return {
        ok: !!(r.ok && r.json && r.json.ok),
        version: String((r.json && r.json.version) || ""),
        status: r.status
      };
    }).catch(function () {
      return { ok: false, version: "", status: 0 };
    });
  }

  function probeBackendState(s) {
    var endpoint = Sync.trimBase(s.serverUrl || "");
    if (!endpoint) return Promise.resolve({ ok: false, serverTime: 0, reason: "no-endpoint" });
    // 注意：wxdoc 的 makeBackendGate.check(endpoint, ctx) 只接受两个参数
    return getBackendGate().check(endpoint, {
      fetch: root.fetch,
      timeoutMs: BACKEND_PROBE_TIMEOUT_MS
    }).then(function (r) {
      return { ok: !!r.ok, serverTime: Number(r.serverTime) || 0, reason: r.ok ? "" : "probe-failed" };
    });
  }

  function probeAll(s) {
    return Promise.all([probeDesktop(s), probeBackendState(s)]).then(function (res) {
      return { desktop: res[0], backend: res[1] };
    });
  }

  /* ==================== 内置接口服务地址列表缓存 ==================== */

  // chrome.storage.local key：{version,count,items,fetchedAt,endpoint}
  function readServiceAddressesCache() {
    return new Promise(function (resolve) {
      chrome.storage.local.get({ serviceAddressesCache: null }, function (r) {
        var err = chrome.runtime && chrome.runtime.lastError;
        resolve(err ? null : ((r && r.serviceAddressesCache) || null));
      });
    });
  }

  function writeServiceAddressesCache(next) {
    return new Promise(function (resolve) {
      chrome.storage.local.set({ serviceAddressesCache: next }, resolve);
    });
  }

  /**
   * 从当前 serverUrl 拉取服务端内置接口地址列表并写缓存：
   *   - 仅当新 version >= 缓存 version 才覆盖；拉取失败保留旧缓存（异常向上抛，由调用方吞掉）；
   *   - opts.force 跳过节制；非 force 时缓存 < TTL 直接命中返回（防 SW 频繁唤醒打爆服务端）。
   */
  async function refreshServiceAddressesCache(opts) {
    opts = opts || {};
    var s = await getSettings();
    var endpoint = Sync.trimBase(s.serverUrl || "");
    if (!endpoint) return { refreshed: false, reason: "no-endpoint" };
    var cache = await readServiceAddressesCache();
    if (!opts.force && cache && cache.fetchedAt &&
        Date.now() - (Number(cache.fetchedAt) || 0) < SERVICE_ADDRESSES_TTL_MS) {
      return { refreshed: false, reason: "fresh", cache: cache };
    }
    var data = await Sync.fetchServiceAddresses(endpoint, {
      fetch: root.fetch,
      timeoutMs: BACKEND_PUSH_TIMEOUT_MS
    });
    var version = Number(data && data.version) || 0;
    var items = (data && Array.isArray(data.items)) ? data.items : [];
    var prevVersion = Number(cache && cache.version) || 0;
    if (version < prevVersion) {
      return { refreshed: false, reason: "stale-version", cache: cache };
    }
    var next = {
      version: version,
      count: Number(data && data.count) || items.length,
      items: items,
      fetchedAt: Date.now(),
      endpoint: endpoint
    };
    await writeServiceAddressesCache(next);
    return { refreshed: true, cache: next };
  }

  // 启动类事件统一入口：失败仅告警，保留旧缓存
  function refreshServiceAddressesQuietly(opts) {
    return refreshServiceAddressesCache(opts).catch(function (e) {
      if (typeof console !== "undefined") console.warn("[wxdoc] 服务地址列表拉取失败（保留旧缓存）", e);
    });
  }

  /* ==================== 内容帧桥接 ==================== */

  function sendToTab(tabId, message) {
    return new Promise(function (resolve, reject) {
      if (!HAS_CHROME || !chrome.tabs) {
        return reject(wxError("no_chrome", "当前环境不支持标签页通信"));
      }
      var settled = false;
      function done(fn, v) { if (!settled) { settled = true; fn(v); } }
      var ret = chrome.tabs.sendMessage(tabId, message, function (resp) {
        var err = chrome.runtime && chrome.runtime.lastError;
        if (err) return done(reject, wxError("no_content", "无法连接页面脚本，请刷新页面后重试", err));
        done(resolve, resp);
      });
      // Firefox / 新版 Chrome 可能返回 Promise
      if (ret && typeof ret.then === "function") {
        ret.then(function (resp) { done(resolve, resp); }, function (e) {
          done(reject, wxError("no_content", "无法连接页面脚本，请刷新页面后重试", e));
        });
      }
    });
  }

  function getTab(tabId) {
    return new Promise(function (resolve, reject) {
      chrome.tabs.get(tabId, function (tab) {
        var err = chrome.runtime && chrome.runtime.lastError;
        if (err || !tab) return reject(wxError("no_tab", "找不到目标标签页", err));
        resolve(tab);
      });
    });
  }

  function queryActiveTab() {
    return new Promise(function (resolve, reject) {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
        var err = chrome.runtime && chrome.runtime.lastError;
        if (err) return reject(wxError("no_tab", "无法获取当前标签页", err));
        resolve((tabs && tabs[0]) || null);
      });
    });
  }

  // 向内容帧汇报进度（floating.js 消费）；失败不影响主流程
  function reportProgress(tabId, payload) {
    if (!HAS_CHROME || tabId == null) return Promise.resolve();
    return new Promise(function (resolve) {
      try {
        chrome.tabs.sendMessage(tabId, Object.assign({ type: "EXPORT_PROGRESS" }, payload), function () {
          resolve();
        });
      } catch (e) { resolve(); }
    });
  }

  function extractArticle(tabId) {
    return sendToTab(tabId, { type: "EXTRACT_REQUEST" }).then(function (resp) {
      if (!resp || !resp.ok || !resp.article) {
        throw wxError("extract_failed", (resp && resp.error) || "未能提取文章内容（页面可能不受支持）");
      }
      return resp.article;
    });
  }

  /**
   * 请求内容帧构建 Markdown。mediaPrefix 仅 download 通道需要（置空即与 md 同根，
   * 对应 §5.8 的「落 .md + images/ + videos/」布局）。
   */
  function buildMarkdownViaTab(tabId, article, mediaPrefix) {
    return sendToTab(tabId, { type: "BUILD_MD", article: article, mediaPrefix: mediaPrefix || "" })
      .then(function (resp) {
        if (!resp || !resp.ok) {
          throw wxError("build_md_failed", (resp && resp.error) || "正文 Markdown 构建失败");
        }
        return {
          md: String(resp.md || ""),
          media: Array.isArray(resp.media) ? resp.media : [],
          blocks: Array.isArray(resp.blocks) ? resp.blocks : []
        };
      });
  }

  /* ==================== 媒体 fetch 与压缩 ==================== */

  function fetchMediaBlob(url, referer) {
    var attempt = 0;
    function tryFetch() {
      attempt++;
      return Sync.fetchWithTimeout(root.fetch, url, {
        headers: { Referer: referer || "https://mp.weixin.qq.com/" },
        credentials: "omit"
      }, MEDIA_FETCH_TIMEOUT_MS).then(function (res) {
        if (!res.ok) throw wxError("media_http", "媒体下载失败（HTTP " + res.status + "）");
        return res.blob();
      }).catch(function (e) {
        if (attempt < 2) return tryFetch();
        throw (e && e.code) ? e : wxError("media_fetch", "媒体下载失败：" + Shared.friendlyError(e), e);
      });
    }
    return tryFetch();
  }

  function hasCanvasSupport() {
    return typeof createImageBitmap === "function" && typeof OffscreenCanvas === "function";
  }

  // 最长边 1920px、JPEG 0.85、单张超 2MB 才压缩；压缩后反而更大则保留原图
  async function compressImageBlob(blob) {
    if (!blob || !blob.type || blob.type.indexOf("image/") !== 0) return blob;
    if (blob.size <= COMPRESS_MAX_BYTES) return blob;
    if (!hasCanvasSupport()) return blob;
    try {
      var bitmap = await createImageBitmap(blob);
      var w = bitmap.width, h = bitmap.height;
      if (Math.max(w, h) <= COMPRESS_MAX_DIM && /jpeg|webp/.test(blob.type)) {
        bitmap.close();
        return blob;
      }
      var scale = Math.min(1, COMPRESS_MAX_DIM / Math.max(w, h));
      var tw = Math.max(1, Math.round(w * scale));
      var th = Math.max(1, Math.round(h * scale));
      var canvas = new OffscreenCanvas(tw, th);
      var ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0, tw, th);
      bitmap.close();
      var compressed = await canvas.convertToBlob({ type: "image/jpeg", quality: COMPRESS_QUALITY });
      return (compressed && compressed.size && compressed.size < blob.size) ? compressed : blob;
    } catch (e) {
      return blob; // 压缩失败保留原图
    }
  }

  /* ==================== 推送任务装配 ==================== */

  function makePushTask(article, built, ids, s, opts) {
    opts = opts || {};
    var now = Date.now();
    var offset = Number(opts.serverOffset) || 0;
    var media = opts.media || [];
    var imageCount = 0, videoCount = 0;
    for (var i = 0; i < media.length; i++) {
      if (media[i].kind === "video") videoCount++; else imageCount++;
    }
    return {
      articleId: ids.articleId,
      dirPath: ids.dirPath,
      dedupKey: ids.dedupKey,
      title: article.title,
      author_name: article.authorName,
      author_handle: article.authorHandle,
      // source 由适配器按 host 派生，严禁硬编码
      source: article.source || Shared.pickSource(hostOf(article.sourceUrl || article.original_url || article.url)),
      publish_time: article.publishTime,
      sourceUrl: article.sourceUrl || article.original_url || article.url,
      exportedAt: Sync.stampTime(offset, now),
      createdAt: Sync.stampTime(offset, now),
      updatedAt: Sync.stampTime(offset, now),
      syncVersion: 1,
      bodyMd: opts.bodyMd || (built && built.md) || "",
      blocks: (built && built.blocks) || [],
      media: media,
      counts: { imageCount: imageCount, videoCount: videoCount },
      imageCount: imageCount,
      videoCount: videoCount,
      totalBytes: Number(opts.totalBytes) || 0,
      deviceId: s.deviceId
    };
  }

  // 收集全部媒体 blob（含压缩与 30MB 硬上限），并给出 bodyMd 的路径改写表。
  // 视频分流：签名 mpvideo 直址有时效且体积常超上限，超限或拉取失败的视频只报元数据
  // （blob=null → 服务端 media 行 url 为空 → 视频缺口），由桌面端补齐闭环强制重抓重签。
  async function collectBackendMedia(plan, referer) {
    var items = [];
    var replacements = [];
    var total = 0;
    for (var i = 0; i < plan.length; i++) {
      var entry = plan[i];
      var isVideo = entry.kind === "video";
      if (isVideo && entry.declared > CLIENT_PAYLOAD_MAX_BYTES) {
        items.push({ kind: entry.kind, rel_path: entry.relPath, relPath: entry.relPath, url: entry.url,
          blob: null, name: lastSegment(entry.relPath), sha256: entry.sha256 || "", size: 0, status: "deferred" });
        continue;
      }
      var blob;
      try {
        blob = await fetchMediaBlob(entry.url, referer);
      } catch (e) {
        if (!isVideo) throw e;
        items.push({ kind: entry.kind, rel_path: entry.relPath, relPath: entry.relPath, url: entry.url,
          blob: null, name: lastSegment(entry.relPath), sha256: entry.sha256 || "", size: 0, status: "deferred" });
        continue;
      }
      if (isVideo && blob.size > CLIENT_PAYLOAD_MAX_BYTES) {
        items.push({ kind: entry.kind, rel_path: entry.relPath, relPath: entry.relPath, url: entry.url,
          blob: null, name: lastSegment(entry.relPath), sha256: entry.sha256 || "", size: 0, status: "deferred" });
        continue;
      }
      if (entry.kind === "image" && blob.type && blob.type.indexOf("image/") === 0 && blob.size > COMPRESS_MAX_BYTES) {
        blob = await compressImageBlob(blob);
      }
      var finalRelPath = finalRelPathFor(entry, blob);
      if (finalRelPath !== entry.relPath) {
        replacements.push({ from: entry.relPath, to: finalRelPath });
      }
      total += (blob && blob.size) || 0;
      if (total > CLIENT_PAYLOAD_MAX_BYTES) {
        throw wxError("payload_too_large",
          "文章体积超过客户端 30MB 上限，已中止（可在设置中关闭图片下载后重试）");
      }
      items.push({
        kind: entry.kind,
        rel_path: finalRelPath,
        relPath: finalRelPath,
        url: entry.url,
        blob: blob,
        name: lastSegment(finalRelPath),
        sha256: entry.sha256 || "",
        size: (blob && blob.size) || 0,
        status: "pending"
      });
    }
    return { items: items, replacements: replacements, totalBytes: total };
  }

  /* ==================== 错误分类与发件箱辅助 ==================== */

  // sync-channel.js 抛出的 SyncError：e.name === "SyncError"，e.kind 为
  // unavailable / auth / business。background 自己的 wxError 用 e.code，两者必须区分。
  function isSyncError(e) {
    return !!(e && e.name === "SyncError");
  }

  function isUnavailable(e) {
    return !!(e && e.name === "SyncError" && e.kind === "unavailable");
  }

  function isAuthError(e) {
    return !!(e && e.name === "SyncError" && e.kind === "auth");
  }

  function isBusinessError(e) {
    return !!(e && e.name === "SyncError" && e.kind === "business");
  }

  function errorKindOf(e) {
    if (isUnavailable(e)) return "unavailable";
    if (isAuthError(e)) return "auth";
    if (isBusinessError(e)) return "business";
    return "client";
  }

  function errorMessageOf(e) {
    if (!e) return "";
    if (e.message) return String(e.message);
    return String(e);
  }

  // 手工构造与 sync-channel.js 同构的 SyncError，供 background 自身判态使用
  // （例如门控探测失败即视为 unavailable，交由 runExport 决定降级）。
  function syncErrorLike(kind, message, raw) {
    var e = new Error(message);
    e.name = "SyncError";
    e.kind = kind;
    e.raw = raw == null ? null : raw;
    return e;
  }

  function unavailableError(message) {
    return syncErrorLike("unavailable", message, null);
  }

  // 发件箱只存元数据，二进制一律现取现传。读改写必须原位替换：
  // Outbox.upsert 会把 attempts 累加（prev.attempts + entry.attempts），
  // 若用 upsert 记录媒体上传进度会导致 attempts 被虚增。
  async function persistEntry(entry) {
    var list = await Outbox.readAll(chrome.storage.local);
    var found = false;
    for (var i = 0; i < list.length; i++) {
      if (list[i].key === entry.key) {
        list[i] = entry;
        found = true;
        break;
      }
    }
    if (!found) list.push(entry);
    await Outbox.writeAll(chrome.storage.local, list);
    return entry;
  }

  // 媒体上传完成态唯一判据：status === "ok"。上传失败仅记 failed，
  // 不阻塞文章记录本身出队（个别媒体失效在通知与报告中列出）。
  function mediaItemForOutbox(item) {
    return {
      id: String(item.id || ""),
      articleId: String(item.articleId || ""),
      kind: item.kind === "video" ? "video" : "image",
      relPath: String(item.relPath || item.rel_path || ""),
      rel_path: String(item.rel_path || item.relPath || ""),
      name: String(item.name || ""),
      url: String(item.url || ""),
      size: Number(item.size) || 0,
      sha256: String(item.sha256 || ""),
      status: String(item.status || "pending")
    };
  }

  function outboxEntryFromTask(task, error, extra) {
    var now = Date.now();
    var media = Array.isArray(task.media) ? task.media.map(mediaItemForOutbox) : [];
    var entry = {
      key: task.articleId,
      articleId: task.articleId,
      dirPath: task.dirPath,
      title: task.title,
      source: task.source,
      sourceUrl: task.sourceUrl,
      dedupKey: task.dedupKey,
      bodyMd: task.bodyMd || "",
      blocks: Array.isArray(task.blocks) ? task.blocks : [],
      media: media,
      counts: task.counts || { imageCount: 0, videoCount: 0 },
      totalBytes: Number(task.totalBytes) || 0,
      deviceId: task.deviceId || "",
      syncVersion: Number(task.syncVersion) || 1,
      exportedAt: Number(task.exportedAt) || now,
      createdAt: Number(task.createdAt) || now,
      updatedAt: Number(task.updatedAt) || now,
      attempts: 1,
      lastError: error ? { kind: errorKindOf(error), message: errorMessageOf(error) } : null,
      queuedAt: now
    };
    if (extra && extra.mediaStatus) {
      for (var i = 0; i < entry.media.length; i++) {
        if (extra.mediaStatus[entry.media[i].relPath]) {
          entry.media[i].status = extra.mediaStatus[entry.media[i].relPath];
        }
      }
    }
    return entry;
  }

  /* ==================== 通道一：backend 直推 ==================== */

  // 顺序要点：先下载 + 压缩得到最终 blob，再算 finalRelPath 并改写 bodyMd，
  // 然后才 pushArticle，最后上传 blob。压缩产物统一 image/jpeg → .jpg，
  // 若先 push 则已推送的 bodyMd 会引用过期扩展名。
  async function runBackendExport(tab, s) {
    var gate = getBackendGate();
    var probe = await gate.check(s.serverUrl, { fetch: root.fetch, timeoutMs: BACKEND_PROBE_TIMEOUT_MS });
    if (!probe.ok) {
      // 端点不可达：抛 unavailable，由 runExport 决定是否自动降级入箱
      throw unavailableError("后端服务不可达（地址或网络异常）");
    }

    var article = await extractArticle(tab.id);
    var ids = await Sync.deriveIdentities(
      article.dedupKey || article.original_url || article.url,
      article.title,
      Shared.sha256Hex,
      Shared.sanitizeTitle || Shared.sanitizeFilename
    );

    reportProgress(tab.id, { phase: "build", message: "正在生成 Markdown" });
    var built = await buildMarkdownViaTab(tab.id, article, "");

    var plan = planMedia(Array.isArray(article.media) ? article.media : []);
    reportProgress(tab.id, {
      phase: "media", message: "正在下载媒体（0/" + plan.length + "）",
      done: 0, total: plan.length
    });

    var collected = { items: [], replacements: [], totalBytes: 0 };
    if (plan.length) {
      collected = await collectBackendMedia(plan, refererFor(article.original_url || article.url));
      for (var i = 0; i < collected.items.length; i++) {
        reportProgress(tab.id, {
          phase: "media", message: "正在下载媒体（" + (i + 1) + "/" + collected.items.length + "）",
          done: i + 1, total: collected.items.length
        });
      }
    }

    var bodyMd = rewriteMediaPaths(built.md, collected.replacements);
    var task = makePushTask(article, built, ids, s, {
      media: collected.items,
      bodyMd: bodyMd,
      totalBytes: collected.totalBytes,
      serverOffset: probe.serverTime
    });

    reportProgress(tab.id, { phase: "push", message: "正在推送到后端" });
    var res = await Sync.pushArticle(
      s.serverUrl, s.apiToken, s.deviceId, s.deviceId, task,
      { fetch: root.fetch, timeoutMs: BACKEND_PUSH_TIMEOUT_MS }
    );
    if (res.serverTime) {
      // 用服务端时间校准偏移，落库时间与本地时钟解耦
      var stamp = Sync.stampTime(res.serverTime - Date.now(), Date.now());
      task.exportedAt = stamp;
      task.createdAt = stamp;
      task.updatedAt = stamp;
    }

    var mediaStatus = {};
    var failures = [];
    var done = 0;
    for (var j = 0; j < collected.items.length; j++) {
      var item = collected.items[j];
      if (!item.blob) {
        // deferred 视频不上传文件，仅保留元数据行（服务端据此计缺口）
        mediaStatus[item.rel_path] = item.status || "deferred";
        done++;
        continue;
      }
      try {
        await Sync.uploadMedia(
          s.serverUrl, s.apiToken, task.articleId, item.rel_path, item.blob,
          { fetch: root.fetch, timeoutMs: BACKEND_UPLOAD_TIMEOUT_MS }
        );
        item.status = "ok";
      } catch (e) {
        item.status = "failed";
        failures.push({ relPath: item.rel_path, message: errorMessageOf(e) });
      }
      mediaStatus[item.rel_path] = item.status;
      done++;
      reportProgress(tab.id, {
        phase: "upload", message: "正在上传媒体（" + done + "/" + collected.items.length + "）",
        done: done, total: collected.items.length
      });
    }

    task.media = collected.items.map(mediaItemForOutbox);
    task.counts = { imageCount: task.imageCount, videoCount: task.videoCount };
    return {
      channel: "backend",
      articleId: task.articleId,
      dirPath: task.dirPath,
      title: task.title,
      mediaTotal: collected.items.length,
      mediaOk: collected.items.length - failures.length,
      mediaFailed: failures,
      converged: !!res.converged,
      task: task
    };
  }

  /* ==================== 通道二：桌面桥 ==================== */

  // 桌面桥响应不是 R 信封：直接 200/202 + 业务 JSON，需自行解析
  function bridgeJson(res, fallbackMessage) {
    if (res.json && typeof res.json === "object") return res.json;
    try {
      return res.text ? JSON.parse(res.text) : {};
    } catch (e) {
      return { error: fallbackMessage || res.text || "" };
    }
  }

  function bridgeErrorMessage(body, status) {
    if (!body) return "桌面端无响应（HTTP " + status + "）";
    if (typeof body === "string") return body;
    return body.error || body.message || "桌面端返回异常（HTTP " + status + "）";
  }

  function desktopStatusText(status, t) {
    var base = {
      queued: "桌面端排队中",
      waiting: "桌面端等待中",
      running: "桌面端处理中",
      processing: "桌面端处理中",
      completed: "桌面端已完成",
      partial_failed: "桌面端部分完成（有媒体失败）",
      failed: "桌面端处理失败",
      cancelled: "桌面端任务已取消",
      paused: "桌面端任务已暂停"
    }[status] || ("桌面端状态：" + (status || "未知"));
    if (t && t.error) base += "：" + String(t.error);
    return base;
  }

  /**
   * 桌面通道：把 URL 交给桌面端（17321）完成抓取、落盘与同步。
   * 幂等语义：重复文章返回 200 + status:"duplicate"，视为成功而非失败。
   * 创建成功（202）后轮询任务直到终态，让扩展能回报真实进度与结果。
   */
  async function runDesktopExport(tab, s) {
    var article = await extractArticle(tab.id);
    var url = article.original_url || article.url;
    if (!url) throw wxError("no_url", "未取到文章链接");

    reportProgress(tab.id, { phase: "submit", message: "正在提交到桌面端" });
    var created = await desktopCall(s, "/api/download", {
      method: "POST",
      headers: desktopHeaders(s, true),
      body: JSON.stringify({
        url: url,
        force: false,
        autoVerify: true,
        downloadImages: true,
        downloadVideos: true
        // 不传 autoSync：交由桌面端自身同步开关决定（桥接默认 false，且会继承其全局设置）
      })
    }, DESKTOP_TIMEOUT_MS);

    if (created.status === 400) {
      // 校验失败属业务错误：地址不受支持等，不应降级到别的通道
      throw wxError("desktop_rejected", bridgeErrorMessage(bridgeJson(created, created.text), 400));
    }
    if (created.status === 503) {
      throw wxError("desktop_unavailable", bridgeErrorMessage(bridgeJson(created, created.text), 503));
    }
    if (!created.ok) {
      throw wxError("desktop_unavailable", "桌面端返回异常（HTTP " + created.status + "）");
    }

    var body = bridgeJson(created, "");
    if (body.status === "duplicate" || body.taskId == null) {
      reportProgress(tab.id, { phase: "done", message: "桌面端已存在该文章" });
      return {
        channel: "desktop",
        duplicate: true,
        articleId: body.articleId || "",
        title: article.title || "",
        taskId: null,
        status: "duplicate"
      };
    }

    var taskId = body.taskId;
    reportProgress(tab.id, { phase: "running", message: "桌面端已受理，正在处理", taskId: taskId });

    var deadline = Date.now() + DESKTOP_POLL_MAX_MS;
    var last = null;
    while (Date.now() < deadline) {
      await new Promise(function (resolve) { setTimeout(resolve, DESKTOP_POLL_INTERVAL_MS); });
      var q = await desktopCall(s, "/api/tasks/" + encodeURIComponent(taskId), {
        method: "GET",
        headers: desktopHeaders(s, false)
      }, DESKTOP_TIMEOUT_MS);
      if (!q.ok) {
        // 轮询失败不立即判负：桌面端可能正在重启，继续等到超时
        continue;
      }
      var t = bridgeJson(q, null);
      if (!t) continue;
      last = t;
      var status = String(t.status || "");
      reportProgress(tab.id, {
        phase: "running",
        message: desktopStatusText(status, t),
        taskId: taskId,
        status: status,
        done: Number(t.fetched_count) || 0,
        total: Number(t.fetch_count) || 1
      });
      if (isTerminalDesktopStatus(status)) break;
    }

    var finalStatus = String((last && last.status) || "");
    if (!finalStatus) {
      throw wxError("desktop_timeout", "等待桌面端处理超时（任务 " + taskId + " 仍在队列中）");
    }
    if (finalStatus !== "completed" && finalStatus !== "partial_failed") {
      throw wxError("desktop_failed", desktopStatusText(finalStatus, last));
    }
    return {
      channel: "desktop",
      duplicate: false,
      articleId: last.article_id || "",
      title: last.title || article.title || "",
      taskId: taskId,
      status: finalStatus,
      savedPath: last.saved_path || "",
      mediaFailed: []
    };
  }

  /* ==================== 视频缺口：服务器探测与桌面补齐 ==================== */

  /**
   * GET {server}/api/videos/by-url（免鉴权只读）。
   * 服务端未配置/探测失败都归 checked:false 正常返回：浮动按钮据此静默隐藏，
   * 不应该因为读不了缺口就在每篇页面上给用户报错。
   */
  async function videoGapCheck(url) {
    var s = await getSettings();
    var endpoint = Sync.trimBase(s.serverUrl || "");
    if (!url || !endpoint) return { checked: false, desktopOk: false };
    var probe = await probeDesktop(s);
    var gap = null;
    try {
      gap = await Sync.requestJson(
        { fetch: root.fetch, timeoutMs: BACKEND_PROBE_TIMEOUT_MS * 3 },
        "GET",
        endpoint + "/api/videos/by-url?url=" + encodeURIComponent(url),
        s.apiToken || "",
        null
      );
    } catch (e) {
      return { checked: false, desktopOk: probe.ok, reason: (e && e.message) || "探测失败" };
    }
    gap = gap || {};
    return {
      checked: true,
      found: !!gap.found,
      articleId: str(gap.articleId),
      videoCount: Number(gap.videoCount) || 0,
      videoReady: Number(gap.videoReady) || 0,
      complete: !!gap.complete,
      desktopOk: probe.ok
    };
  }

  /**
   * 视频补齐：把原文链接交给桌面端重新采集（force:true，否则桥按 duplicate 直接返回）。
   * 桌面端下完视频后 autoSync:true 走 tar 覆盖上传，服务端按 origin_hash 合并到同一篇。
   */
  async function videoBackfill(url) {
    if (!url) throw wxError("no_url", "未取到文章链接");
    var s = await getSettings();
    var created = await desktopCall(s, "/api/download", {
      method: "POST",
      headers: desktopHeaders(s, true),
      body: JSON.stringify({
        url: url,
        force: true,
        autoVerify: true,
        downloadImages: true,
        downloadVideos: true,
        autoSync: true,
        source: "browser-extension-video-backfill"
      })
    }, DESKTOP_TIMEOUT_MS);
    var body = bridgeJson(created, created.text);
    if (created.status === 400) throw wxError("desktop_rejected", bridgeErrorMessage(body, 400));
    if (!created.ok) throw wxError("desktop_unavailable", bridgeErrorMessage(body, created.status));
    return { taskId: body.taskId || null, status: String(body.status || "") };
  }

  /* ==================== 通道三：下载内容 ==================== */

  // 把原始 media 快照展开成可下载清单（含 poster 展开为独立项）。
  // 路径口径：与 md-builder.mediaRelPath / mediaFileMap 同源（images/image_<idx>.<ext> /
  // videos/video_<idx>.<ext>，poster → videos/video_<idx>_poster.<ext>）。
  function downloadPlanFor(article) {
    var media = Array.isArray(article.media) ? article.media : [];
    var plan = [];
    for (var i = 0; i < media.length; i++) {
      var m = media[i];
      if (!m) continue;
      var kind = str(m.media_type || m.kind) === "video" ? "video" : "image";
      if (kind === "video") {
        plan.push({ idx: i, kind: "video", url: m.url, poster: true });
        if (m.poster) plan.push({ idx: i, kind: "image", url: m.poster, isPoster: true });
      } else {
        plan.push({ idx: i, kind: "image", url: m.url });
      }
    }
    return plan;
  }

  // 该项对应到导出目录内的相对路径（<jobDir>?/<dir>/<file>），与 md 中的引用一致。
  // poster 文件名：把「video_N.<ext>」改写成「video_N_poster.<ext>」（与 md-builder.posterRelPath 同源）
  function posterNameFor(idx, url, blob) {
    var base = Shared.filenameFor({ media_type: "video", url: url }, idx, blob);
    return base.replace(/\.([^.]+)$/, "_poster.$1");
  }

  /**
   * 下载通道：内容帧构建 md（mediaPrefix 为空，md 内引用 images/video_N），
   * 本端把 .md 落盘到 <saveLocation>/<jobDir>/<name>.md，媒体落到 <jobDir>/images|videos/，
   * 支持覆盖/另存策略与每次确认位置（saveAs）。
   */
  async function runDownloadExport(tab, s) {
    var article = await extractArticle(tab.id);
    var plan = downloadPlanFor(article);

    var nowTs = Shared.formatTs ? Shared.formatTs(new Date()) : String(Date.now());
    var jobDir = Shared.renderDirName(s.dirNameTemplate || "{title}_{ts}",
      { title: article.title || "未命名", ts: nowTs });
    var usedDirs = [];
    jobDir = Shared.dedupeDir(jobDir, usedDirs);
    usedDirs.push(jobDir);

    reportProgress(tab.id, { phase: "build", message: "正在生成 Markdown" });
    var built = await buildMarkdownViaTab(tab.id, article, "");
    var bodyMd = (built && built.md) || "";

    var conflict = conflictActionFor(s.duplicatePolicy);
    var saveAs = !!s.askEveryTime;
    var done = 0;
    var failures = [];

    // 先落 .md
    reportProgress(tab.id, { phase: "download", message: "正在写入 Markdown", done: 0, total: plan.length + 1 });
    try {
      await downloadText(jobDir, Shared.sanitizeFilename(article.title || "未命名") + ".md", bodyMd, conflict, saveAs);
    } catch (e) {
      failures.push({ name: jobDir + "/" + Shared.sanitizeFilename(article.title || "未命名") + ".md", message: errorMessageOf(e) });
    }
    done++;
    reportProgress(tab.id, { phase: "download", message: "已写入 Markdown，正在下载媒体（" + done + "/" + (plan.length + 1) + "）", done: done, total: plan.length + 1 });

    for (var i = 0; i < plan.length; i++) {
      var item = plan[i];
      try {
        var blob = await fetchMediaBlob(item.url, refererFor(article.original_url || article.url));
        var subDir = item.isPoster ? "videos" : Shared.dirForKind(item.kind);
        var fname = item.isPoster
          ? posterNameFor(item.idx, item.url, blob)
          : Shared.filenameFor({ media_type: item.kind, url: item.url }, item.idx, blob);
        await downloadBlob(Shared.downloadPath(s.saveLocation, jobDir, subDir, fname), blob, conflict, saveAs);
      } catch (e) {
        failures.push({ name: (item.url || "").split("/").pop() || (item.isPoster ? "poster" : "media"), message: errorMessageOf(e) });
      }
      done++;
      reportProgress(tab.id, {
        phase: "download", message: "正在下载媒体（" + done + "/" + (plan.length + 1) + "）",
        done: done, total: plan.length + 1
      });
    }

    Shared.notify((failures.length ? "部分完成" : "导出完成"),
      (article.title || "未命名") + " — 媒体 " + (plan.length - failures.length) + "/" + plan.length + " 已落盘");

    return {
      channel: "download",
      dirPath: jobDir,
      title: article.title || "",
      savedPath: jobDir,
      mediaTotal: plan.length,
      mediaOk: plan.length - failures.length,
      mediaFailed: failures
    };
  }

  // chrome.downloads 包装：创建 blob URL 并下载，完成后回收。
  function downloadBlob(filePath, blob, conflictAction, saveAs) {
    var url = (typeof URL !== "undefined" && URL.createObjectURL) ? URL.createObjectURL(blob) : null;
    if (!url) return Promise.reject(wxError("download_unsupported", "当前环境不支持 Blob URL，无法下载"));
    scheduleRevoke(url);
    return chromeDownloadsDownload({
      url: url,
      filename: filePath,
      conflictAction: conflictAction || "uniquify",
      saveAs: !!saveAs
    });
  }

  function downloadText(jobDir, name, text, conflictAction, saveAs) {
    var blob = (typeof Blob !== "undefined") ? new Blob([text], { type: "text/markdown;charset=utf-8" }) : null;
    var jobPath = Shared.downloadPath("", jobDir || "", "", name);
    return downloadBlob(jobPath, blob, conflictAction, saveAs);
  }

  // chrome.downloads 普通 Promise 化（含兼容性：Promise-API 与旧版回调 API）。
  function chromeDownloadsDownload(opts) {
    return new Promise(function (resolve, reject) {
      var dl = (typeof chrome !== "undefined" && chrome.downloads && chrome.downloads.download) ? chrome.downloads.download : null;
      if (!dl) { reject(wxError("download_unsupported", "chrome.downloads 不可用")); return; }
      try {
        var res = dl(opts, function (id) {
          if (chrome.runtime.lastError) {
            reject(wxError("download_failed", chrome.runtime.lastError.message || "下载失败"));
          } else { resolve({ id: id }); }
        });
        // 新版 Promise API：直接返回 Promise
        if (res && typeof res.then === "function") {
          res.then(function (id) { resolve({ id: id }); }).catch(function (e) {
            reject(wxError("download_failed", (e && e.message) || "下载失败"));
          });
        }
      } catch (e) {
        reject(wxError("download_failed", (e && e.message) || "下载失败"));
      }
    });
  }

  /* ==================== Blob URL 回收 ==================== */

  // OBJECT_URL_TTL_MS 后回收旧 blob URL，避免内存泄漏；保留最近一个（当前下载中）不回收。
  var pendingRevokes = [];
  function scheduleRevoke(objectUrl) {
    if (!objectUrl) return;
    var entry = { url: objectUrl, at: Date.now() + OBJECT_URL_TTL_MS };
    pendingRevokes.push(entry);
    flushRevokes();
  }
  function flushRevokes() {
    var now = Date.now();
    // 始终至少保留最近一个，避免正在下载中的 URL 被提前释放
    var cutoff = pendingRevokes.length <= 1 ? Infinity : 0;
    pendingRevokes = pendingRevokes.filter(function (e) {
      if (now - e.at >= cutoff || (now >= e.at && pendingRevokes.indexOf(e) === pendingRevokes.length - 1)) {
        if (now >= e.at && e !== pendingRevokes[pendingRevokes.length - 1]) {
          try { URL.revokeObjectURL(e.url); } catch (err) { /* ignore */ }
          return false;
        }
      }
      return true;
    });
  }

  /* ==================== 每 tab 互斥锁 ==================== */

  var tabLocks = {};          // tabId -> 过期时间戳
  var activeJobs = {};        // tabId -> Promise（当前正在执行的导出）

  function acquireTabLock(tabId) {
    if (tabId == null) return false;
    var now = Date.now();
    if (tabLocks[tabId] && tabLocks[tabId] > now) return false;
    tabLocks[tabId] = now + EXPORT_LOCK_TTL_MS;
    return true;
  }
  function releaseTabLock(tabId) {
    delete tabLocks[tabId];
  }

  /* ==================== 编排：解析通道 → 执行 ==================== */

  // 在探测结果上决定最终通道（auto 模式：选后端→桌面→下载）。
  function decideChannel(s, probe) {
    var prefer = (s.mode || "auto");
    if (prefer === "backend" || prefer === "desktop" || prefer === "download") return prefer;
    if (probe && probe.backend && probe.backend.ok) return "backend";
    if (probe && probe.desktop && probe.desktop.ok) return "desktop";
    return "download";
  }

  /**
   * 单篇文章导出编排。任一通道：
   *   - unavailable + auto 入 outbox 并顺位降级到下一可用通道；
   *   - unavailable 且无可用通道 → outbox 入队后抛错（由调用方发完成/失败通知）；
   *   - 成功 → 通知并返回结果。
   */
  async function runExport(tab) {
    var s = await getSettings();
    var probe = await probeAll(s);
    var channel = decideChannel(s, probe);

    if (channel === "backend") {
      try {
        var r = await runBackendExport(tab, s);
        await finishOk(tab, r);
        return r;
      } catch (e) {
        if (isUnavailable(e)) {
          await enqueueOutboxFromError(tab, s, "backend", e);
          // 后端不可用时尝试桌面，不可用则下载通道
          if (probe.desktop && probe.desktop.ok) {
            var rd = await runDesktopExport(tab, s);
            await finishOk(tab, rd);
            return rd;
          }
          var rl = await runDownloadExport(tab, s);
          await finishOk(tab, rl);
          return rl;
        }
        await finishError(tab, e);
        throw e;
      }
    }

    if (channel === "desktop") {
      try {
        var d = await runDesktopExport(tab, s);
        await finishOk(tab, d);
        return d;
      } catch (e) {
        if (isUnavailable(e)) {
          var dl = await runDownloadExport(tab, s);
          await finishOk(tab, dl);
          return dl;
        }
        await finishError(tab, e);
        throw e;
      }
    }

    // 下载通道
    try {
      var l = await runDownloadExport(tab, s);
      await finishOk(tab, l);
      return l;
    } catch (e) {
      await finishError(tab, e);
      throw e;
    }
  }

  async function finishOk(tab, result) {
    if (!result) return;
    var title = (result && result.title) || "未命名";
    reportProgress(tab.id, { phase: "done", message: "已导出「" + title + "」", result: result });
  }

  async function finishError(tab, e) {
    reportProgress(tab.id, { phase: "error", message: errorMessageOf(e) || "导出失败", code: e && e.code });
  }

  /**
   * 后端 unavailable 时：把「几乎可推送」的任务快照写入 outbox（不含二进制，仅元数据），
   * 以便 flush 时重试；终态路径则是成功通知。
   * tab：chrome.tabs.Tab；s：settings；failedChannel：'unavailable' 来源通道说明。
   */
  async function enqueueOutboxFromError(tab, s, failedChannel, err) {
    try {
      var article = await extractArticle(tab.id);
      var ids = await Sync.deriveIdentities(
        article.dedupKey || article.original_url || article.url,
        article.title, Shared.sha256Hex,
        Shared.sanitizeTitle || Shared.sanitizeFilename
      );
      var built = await buildMarkdownViaTab(tab.id, article, "");
      var plan = planMedia(Array.isArray(article.media) ? article.media : []);
      var repl = plan.map(function (it) { return { from: it.relPath, to: it.relPath }; });
      var task = makePushTask(article, built, ids, s, { media: [], bodyMd: built.md, totalBytes: 0 });
      // 媒体项保留「待下载」状态（status pending），flush 时按 url 重新 fetch
      task.media = plan.map(function (it, i) {
        return {
          id: "m" + i,
          kind: it.kind,
          rel_path: it.relPath,
          relPath: it.relPath,
          name: lastSegment(it.relPath),
          url: it.url,
          size: 0,
          sha256: "",
          status: "pending"
        };
      });
      task.imageCount = task.imageCount || 0;
      task.videoCount = task.videoCount || 0;
      task.totalBytes = 0;
      var entry = Outbox.entryFromArticle(task, syncErrorLike(
        isUnavailable(err) ? "unavailable" : "business",
        errorMessageOf(err) || "通道不可用，已加入补推队列", err));
      await Outbox.upsert(chrome.storage.local, entry);
    } catch (persistErr) {
      // 入队失败不应中断主流程，仅上报即可
      if (typeof console !== "undefined") console.warn("[wxdoc] outbox 入队失败", persistErr);
    }
  }

  /* ==================== 发件箱 flush ==================== */

  /**
   * flush：遍历 outbox，按每条目重试 push + 媒体 upload（懒入 binary）。
   *   - 全部媒体 ok → 出队；
   *   - unavailable（端点未实现）→ 不累计 attempts，保留当前条目，顺位 break（本轮不再重试其它同端点条目）；
   *   - auth / business → 保留并累计 attempts（指数退避）；
   * 调用来源：SW 启动 / alarms（~2min）/ backend probe 成功后 / 手动。
   */
  async function flushOutbox() {
    var s = await getSettings();
    var endpoint = Sync.trimBase(s.serverUrl || "");
    if (!endpoint) return { tried: 0, ok: 0, skipped: 0, noEndpoint: true };
    var gate = getBackendGate();
    var probe = await gate.check(endpoint, { fetch: root.fetch, timeoutMs: BACKEND_PROBE_TIMEOUT_MS });
    if (!probe.ok) return { tried: 0, ok: 0, skipped: 0, backendUnavailable: true };

    var list = await Outbox.readAll(chrome.storage.local);
    if (!list.length) return { tried: 0, ok: 0, skipped: 0, empty: true };

    var result = { tried: 0, ok: 0, failed: 0, skipped: 0, remaining: 0 };
    for (var i = 0; i < list.length; i++) {
      var entry = list[i];
      try {
        await flushOne(s, entry, probe);
        var fresh = await Outbox.readAll(chrome.storage.local);
        var still = fresh.filter(function (x) { return x.key === entry.key; });
        if (still.length) {
          // 部分媒体未齐 → 累计一次 attempts 并原地写回
          await persistEntry(Object.assign({}, still[0], {
            attempts: (Number(still[0].attempts) || 0) + 1,
            lastError: { kind: "retry", message: "部分媒体未齐，等待下次 flush" }
          }));
          result.failed++;
        } else {
          result.ok++;
        }
      } catch (e) {
        if (isUnavailable(e)) {
          // 端点仍未实现：不累计 attempts，保留并停止本轮
          result.skipped++;
          break;
        }
        var attempts = (Number(entry.attempts) || 0) + 1;
        await persistEntry(Object.assign({}, entry, {
          attempts: attempts,
          lastError: { kind: errorKindOf(e), message: errorMessageOf(e) }
        }));
        result.failed++;
      }
      result.tried++;
    }
    var after = await Outbox.readAll(chrome.storage.local);
    result.remaining = after.length;
    return result;
  }

  async function flushOne(s, entry, probe) {
    var title = entry.title || "未命名";
    var baseTime = probe.serverTime ? Sync.stampTime(probe.serverTime - Date.now(), Date.now()) : Sync.stampTime(0, Date.now());
    var mediaItems = [];
    var pendingMedia = Array.isArray(entry.media) ? entry.media.slice() : [];

    // 1) 先上传所有仍处于 pending 的媒体（懒入 binary）
    for (var i = 0; i < pendingMedia.length; i++) {
      var m = pendingMedia[i];
      if (m.status === "ok") continue;
      var referer = entry.sourceUrl || entry.sourceUrl || "";
      var blob = await fetchMediaBlob(m.url, referer);
      // 图片压缩（口径同 runBackendExport）
      if (m.kind === "image" && blob.type && blob.type.indexOf("image/") === 0 && blob.size > COMPRESS_MAX_BYTES) {
        blob = await compressImageBlob(blob);
      }
      var finalRelPath = (m.relPath || m.rel_path);
      if (!finalRelPath) finalRelPath = Sync.fallbackMediaRelPath({ kind: m.kind, url: m.url }, i);
      try {
        await Sync.uploadMedia(s.serverUrl, s.apiToken, entry.articleId, finalRelPath, blob,
          { fetch: root.fetch, timeoutMs: BACKEND_UPLOAD_TIMEOUT_MS });
        m.status = "ok";
        m.size = blob.size || 0;
      } catch (e) {
        m.status = "failed";
        m.lastError = errorMessageOf(e);
      }
      // 记录进度（原位写回）
      var fresh = await Outbox.readAll(chrome.storage.local);
      var cur = fresh.filter(function (x) { return x.key === entry.key; })[0];
      if (cur) {
        var nextMedia = Array.isArray(cur.media) ? cur.media.slice() : [];
        nextMedia[i] = Object.assign({}, nextMedia[i] || {}, { status: m.status, size: m.size, lastError: m.lastError || null });
        await persistEntry(Object.assign({}, cur, { media: nextMedia }));
      }
      mediaItems.push({
        kind: m.kind, rel_path: finalRelPath, relPath: finalRelPath,
        url: m.url, name: lastSegment(finalRelPath),
        size: blob.size || 0, sha256: m.sha256 || "",
        status: m.status
      });
    }

    // 2) push（文章去重键已确定）
    var task = {
      articleId: entry.articleId,
      dirPath: entry.dirPath || ("文章_" + title + "_" + String(entry.articleId).slice(-8)),
      dedupKey: entry.dedupKey,
      title: title,
      author_name: entry.authorName || "",
      author_handle: entry.authorHandle || "",
      source: entry.source || "",
      publish_time: entry.publishTime || "",
      sourceUrl: entry.sourceUrl || "",
      exportedAt: baseTime, createdAt: baseTime, updatedAt: baseTime,
      syncVersion: Number(entry.syncVersion) || 1,
      bodyMd: entry.bodyMd || "",
      media: mediaItems,
      counts: { imageCount: 0, videoCount: 0 },
      imageCount: 0,
      videoCount: 0,
      totalBytes: mediaItems.reduce(function (acc, it) { return acc + (Number(it.size) || 0); }, 0),
      deviceId: s.deviceId
    };

    await Sync.pushArticle(s.serverUrl, s.apiToken, s.deviceId, s.deviceId, task,
      { fetch: root.fetch, timeoutMs: BACKEND_PUSH_TIMEOUT_MS });

    // 3) 若媒体全部 ok → 出队
    if (Outbox.mediaComplete(entry)) {
      await Outbox.remove(chrome.storage.local, entry.key);
    }
  }

  /* ==================== 直连上传通道（directSubmit：内容帧提取 → 后端直传） ==================== */

  var DIRECT_SUBMIT_TIMEOUT_MS = 120000;

  // 向内容帧播报直传进度（content.js 消费 directSubmitProgress）；失败不影响主流程
  function directProgress(tabId, payload) {
    if (tabId == null) return;
    try { sendToTab(tabId, payload).catch(function () {}); } catch (e) { /* 页面已关闭 */ }
  }

  async function handleDirectSubmit(msg, tabId) {
    var s = await getSettings();
    var serverUrl = Sync.trimBase(String(s.serverUrl || ""));
    var token = String(s.apiToken || "");
    if (!serverUrl) throw wxError("config", "未配置服务端地址，请在扩展设置中配置");
    if (!token) throw wxError("config", "未配置 API Token，请在扩展设置中设置");
    var content = msg.content;
    if (!content || !Array.isArray(content.blocks)) throw wxError("bad_content", "未收到文章内容");

    var referer = refererFor(content.original_url || msg.url || "");
    var mediaList = Array.isArray(content.media) ? content.media : [];
    var blobs = [];
    var downloadErrors = [];
    var compressedCount = 0;
    var deferredVideos = 0;
    for (var i = 0; i < mediaList.length; i++) {
      directProgress(tabId, { type: "directSubmitProgress", url: msg.url, phase: "downloading", done: i, total: mediaList.length });
      var mEntry = mediaList[i] || {};
      var isVideo = str(mEntry.media_type || mEntry.kind) === "video";
      // 大视频（>30MB 或有声明体积超限）不随表单直传：留空位保配对，服务端计入视频缺口，
      // 由桌面端补齐闭环强制重抓（每次重抓会重新解析签名直址）
      if (isVideo && (Number(mEntry.filesize) || 0) > CLIENT_PAYLOAD_MAX_BYTES) {
        deferredVideos++;
        blobs.push(null);
        continue;
      }
      try {
        var blob = await fetchMediaBlob(mEntry.url, referer);
        var small = await compressImageBlob(blob);
        if (isVideo && small.size > CLIENT_PAYLOAD_MAX_BYTES) {
          deferredVideos++;
          blobs.push(null);
          continue;
        }
        if (small !== blob) compressedCount++;
        blobs.push(small);
      } catch (e) {
        if (isVideo) {
          deferredVideos++;
          blobs.push(null);
          continue;
        }
        downloadErrors.push("媒体 " + (i + 1) + "：" + errorMessageOf(e));
        blobs.push(null);
      }
    }
    if (deferredVideos) {
      downloadErrors.push(deferredVideos + " 个视频未随直传提交（体积或防盗链限制），将由桌面端自动补齐");
    }

    var totalBytes = 0;
    blobs.forEach(function (b) { if (b) totalBytes += b.size; });
    if (totalBytes > CLIENT_PAYLOAD_MAX_BYTES) {
      throw wxError("payload_too_large", "媒体总量超出上传限制（30MB）");
    }

    // source 由 host 派生（关键约束：严禁硬编码）；服务端按 original_url + index 配对媒体
    var source = Shared.pickSource(hostOf(content.original_url || msg.url || "")) || String(content.source || "");
    var contentPayload = {
      title: content.title || "",
      author_name: content.author_name || "",
      author_handle: content.author_handle || "",
      publish_time: content.publish_time || null,
      original_url: content.original_url || msg.url || "",
      source: source,
      source_block_count: content.source_block_count || content.blocks.length,
      blocks: content.blocks,
      media: mediaList.map(function (m, idx) {
        return {
          index: idx,
          url: m.url || null,
          media_type: m.media_type || m.kind || "image",
          description: m.description || null,
          poster: m.poster || null
        };
      })
    };

    var formData = new FormData();
    formData.append("content", new Blob([JSON.stringify(contentPayload)], { type: "application/json" }), "content.json");
    for (var k = 0; k < blobs.length; k++) {
      // 服务端契约：@RequestPart("media") MultipartFile[]，同名多 part 按 meta 下标配对；
      // 缺项（失败/分流视频）必须用空 part 占位，否则后续媒体整体错位（服务端忽略空 part）
      if (blobs[k]) {
        formData.append("media", blobs[k], Shared.filenameFor(mediaList[k], k, blobs[k]));
      } else {
        formData.append("media", new Blob([], { type: "application/octet-stream" }), "empty_" + k + ".bin");
      }
    }

    directProgress(tabId, { type: "directSubmitProgress", url: msg.url, phase: "uploading", done: mediaList.length, total: mediaList.length });

    var res;
    try {
      res = await Sync.fetchWithTimeout(root.fetch, serverUrl + "/api/articles/direct/submit", {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
        body: formData
      }, DIRECT_SUBMIT_TIMEOUT_MS);
    } catch (e) {
      throw wxError("offline", "无法连接服务端，请检查网络或服务端地址：" + Shared.friendlyError(e), e);
    }

    var body = null;
    try { body = await res.json(); } catch (e) { /* 非 JSON 响应按 HTTP 状态判定 */ }
    var payload = body && body.data ? body.data : null;
    if (res.status === 401 || (body && body.code === 401)) {
      throw wxError("unauthorized", "认证失败：Token 无效或已过期");
    }
    if (res.status === 409 || (payload && payload.duplicate)) {
      return { duplicate: true, articleId: (payload && payload.articleId) || null };
    }
    if (!res.ok || (body && typeof body.code === "number" && body.code !== 0)) {
      throw wxError("server", (body && body.message) || ("服务端返回 HTTP " + res.status));
    }
    var savedOk = blobs.filter(function (b) { return !!b; }).length;
    return {
      duplicate: false,
      articleId: (payload && payload.articleId) || null,
      savedMediaCount: payload && payload.savedMediaCount != null ? payload.savedMediaCount : savedOk,
      failedMediaCount: payload && payload.failedMediaCount != null ? payload.failedMediaCount : downloadErrors.length,
      compressedCount: compressedCount,
      warnings: downloadErrors
    };
  }

  /* ==================== v1 兼容代理（桌面桥：content.js 浮动按钮 / popup 旧消息） ==================== */

  /**
   * 桌面端模式下 content.js/popup.js 仍按 v1 协议发小写消息
   * （download/recent/task/retry/deleteTask/clearFinished/health），
   * 这里代理到桌面桥（bridge.rs，响应为裸 JSON，非 R 信封）。
   * 连接不可达统一转 code=offline + v1 离线文案，保持 content.js isOffline 判定口径。
   */
  function desktopProxy(path, options) {
    return getSettings().then(function (s) {
      var opts = options || {};
      opts.headers = Object.assign({}, desktopHeaders(s, !!opts.body), opts.headers || {});
      return desktopCall(s, path, opts, DESKTOP_TIMEOUT_MS);
    }).then(function (r) {
      if (r.status >= 200 && r.status < 300) return r.json;
      throw wxError("desktop_http", (r.json && r.json.error) || ("桌面端返回 HTTP " + r.status));
    }).catch(function (e) {
      if (e && e.code === "desktop_unavailable") {
        throw wxError("offline", "未检测到微文存阅客户端，请先打开微文存阅客户端后重试", e.raw);
      }
      throw e;
    });
  }

  function desktopJson(body) {
    return { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
  }

  function handleLegacyMessage(message, sendResponse) {
    switch (message.type) {
      case "health":
        return wrapAsync(desktopProxy("/health"), sendResponse);
      case "download":
        // autoSync 不在 v2 SETTINGS_DEFAULTS 里（options.js 仍会写），需单独读取，默认 true 与 v1 一致
        return wrapAsync(Promise.all([
          getSettings(),
          new Promise(function (resolve) { chrome.storage.local.get({ autoSync: true }, resolve); })
        ]).then(function (res) {
          return desktopProxy("/api/download", desktopJson({
            url: message.url,
            downloadImages: true,
            downloadVideos: true,
            autoSync: res[1].autoSync !== false,
            source: "browser-extension-v2"
          }));
        }), sendResponse);
      case "task":
        return wrapAsync(desktopProxy("/api/tasks/" + encodeURIComponent(message.taskId)), sendResponse);
      case "recent":
        return wrapAsync(desktopProxy("/api/tasks/recent"), sendResponse);
      case "retry":
        return wrapAsync(desktopProxy("/api/tasks/" + encodeURIComponent(message.taskId) + "/retry", { method: "POST" }), sendResponse);
      case "deleteTask":
        return wrapAsync(desktopProxy("/api/tasks/" + encodeURIComponent(message.taskId), { method: "DELETE" }), sendResponse);
      case "clearFinished":
        return wrapAsync(desktopProxy("/api/tasks/clear-finished", { method: "POST" }), sendResponse);
      default:
        return null;
    }
  }

  /* ==================== 消息路由 ==================== */

  function handleMessage(message, sender, sendResponse) {
    if (!message || !message.type) { sendResponse({ ok: false, error: "缺少 type" }); return false; }
    var tab = (sender && sender.tab) || {};
    var tabId = message.tabId || tab.id;

    switch (message.type) {
      case "UI_PROBE":
        return wrapAsync(sendMessageProbe(), sendResponse);
      case "EXPORT_START":
        return wrapAsync(handleExportStart(tabId), sendResponse);
      case "FLUSH_OUTBOX":
        return wrapAsync(flushOutbox().then(function (r) { return r; }), sendResponse);
      case "OUTBOX_SNAPSHOT":
        return wrapAsync(Outbox.readAll(chrome.storage.local).then(function (l) {
          return { total: l.length, entries: l };
        }), sendResponse);
      case "directSubmit":
        return wrapAsync(handleDirectSubmit(message, tabId), sendResponse);
      case "VIDEO_GAP_CHECK":
        return wrapAsync(videoGapCheck(message.url), sendResponse);
      case "VIDEO_BACKFILL":
        return wrapAsync(videoBackfill(message.url), sendResponse);
      case "SERVICE_ADDRESSES_REFRESH":
        // options 页缓存缺失/超 1h 时触发一次拉取（force 跳过节制）
        return wrapAsync(refreshServiceAddressesCache({ force: !!message.force }), sendResponse);
      default: {
        // v1 兼容：桌面桥代理消息（download/recent/task/retry/deleteTask/clearFinished/health）
        var legacyHandled = handleLegacyMessage(message, sendResponse);
        if (legacyHandled !== null) return legacyHandled;
        sendResponse({ ok: false, error: "未知消息类型: " + message.type, code: "unknown_type" });
        return false;
      }
    }
  }

  function sendMessageProbe() {
    return getSettings().then(function (s) {
      return probeAll(s).then(function (probe) {
        return resolveChannelState(s, probe);
      });
    }).then(function (state) {
      return Object.assign({ ok: true }, state);
    });
  }

  // 测试钩子：只暴露有用的内部函数，便于 node --test 注入假对象
  function setTestHooks(hooks) {
    if (!hooks) return;
    if (hooks.root) root = hooks.root;
    if (hooks.fetch) root.fetch = hooks.fetch;
  }

  function handleExportStart(tabId) {
    if (tabId == null) return Promise.resolve({ ok: false, error: "缺少 tabId", code: "no_tab" });
    if (!acquireTabLock(tabId)) {
      return Promise.resolve({ ok: false, error: "该标签页已有导出任务进行中，请稍后再试", code: "locked" });
    }
    var tab = { id: tabId };
    activeJobs[tabId] = runExport(tab)
      .catch(function (e) { return { error: errorMessageOf(e), code: e && e.code }; })
      .finally(function () { releaseTabLock(tabId); delete activeJobs[tabId]; });
    return Promise.resolve({ ok: true, accepted: true });
  }

  // 把异步结果包装成 {ok:true,data} / {ok:false,error,code} 并调用 sendResponse
  function wrapAsync(promise, sendResponse) {
    promise.then(function (data) {
      sendResponse({ ok: true, data: data });
    }).catch(function (e) {
      sendResponse({ ok: false, error: errorMessageOf(e), code: e && e.code || "internal_error" });
    });
    return true; // 异步响应
  }

  /* ==================== 命令与事件注册 ==================== */

  if (HAS_CHROME) {
    if (chrome.runtime && chrome.runtime.onMessage && chrome.runtime.onMessage.addListener) {
      chrome.runtime.onMessage.addListener(handleMessage);
    }
    if (chrome.commands && chrome.commands.onCommand && chrome.commands.onCommand.addListener) {
      chrome.commands.onCommand.addListener(function (command) {
        if (command === "save-article") {
          queryActiveTab().then(function (tab) {
            if (!tab || tab.id == null) {
              Shared.notify("微文存阅", "请先打开一个要收藏的标签页");
              return;
            }
            handleExportStart(tab.id);
          });
        }
      });
    }
    if (chrome.runtime && chrome.runtime.onInstalled && chrome.runtime.onInstalled.addListener) {
      chrome.runtime.onInstalled.addListener(function (details) {
        if (details.reason === "install" || details.reason === "update") {
          Shared.notify(
            "微文存阅 v" + (chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "2"),
            "已启用三通道同步：后端 · 桌面 · 下载。首次使用请打开「设置」配置后端/桌面桥地址。"
          );
        }
        // 安装/更新后强制刷新一次内置接口服务地址列表缓存
        refreshServiceAddressesQuietly({ force: true });
      });
    }
    if (chrome.runtime && chrome.runtime.onStartup && chrome.runtime.onStartup.addListener) {
      chrome.runtime.onStartup.addListener(function () {
        refreshServiceAddressesQuietly({ force: true });
      });
    }
    if (chrome.alarms) {
      try {
        chrome.alarms.create(OUTBOX_FLUSH_ALARM, { delayInMinutes: 1, periodInMinutes: OUTBOX_FLUSH_PERIOD_MINUTES });
        chrome.alarms.onAlarm.addListener(function (alarm) {
          if (alarm.name === OUTBOX_FLUSH_ALARM) {
            flushOutbox().catch(function (e) { /* ignore */ });
          }
        });
      } catch (e) { /* alarms 不可用时静默 */ }
    }
    // SW 启动时也跑一次 flush，尽量清掉上周期留下的条目
    flushOutbox().catch(function (e) { /* ignore */ });
    // 服务地址列表缓存：缺 / 超 TTL 才拉（非 force，SW 频繁唤醒不打爆服务端）
    refreshServiceAddressesQuietly();
  }

  /* ==================== 导出 ==================== */

  var api = {
    channelReasonText: channelReasonText,
    resolveChannelState: resolveChannelState,
    decideChannel: decideChannel,
    backendGate: getBackendGate,
    probeAll: probeAll,
    extractArticle: extractArticle,
    buildMarkdownViaTab: buildMarkdownViaTab,
    makePushTask: makePushTask,
    collectBackendMedia: collectBackendMedia,
    runExport: runExport,
    runBackendExport: runBackendExport,
    runDesktopExport: runDesktopExport,
    videoGapCheck: videoGapCheck,
    videoBackfill: videoBackfill,
    runDownloadExport: runDownloadExport,
    handleDirectSubmit: handleDirectSubmit,
    flushOutbox: flushOutbox,
    refreshServiceAddressesCache: refreshServiceAddressesCache,
    handleMessage: handleMessage,
    flushOne: flushOne,
    setTestHooks: setTestHooks
  };

  root.WxdocBackground = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;

})(typeof self !== 'undefined' ? self : globalThis);
