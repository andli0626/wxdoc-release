/*
 * md-builder.js — WxdocMd（微文存阅浏览器扩展）
 * 依据方案 §5.3：blocks + media → Markdown（frontmatter + 正文）。
 * 正文 HTML 由 blocks 顺序拼装，媒体块替换为指向 images/image_N、videos/video_N
 * 的相对路径引用，再经 Turndown + GFM 转 Markdown。
 * 纯函数实现，UMD 暴露；浏览器中依赖前置加载的 TurndownService / turndownPluginGfm 全局，
 * Node 测试中由 tests/helpers/dom-setup.js 注入同形态全局（不触碰 chrome.*）。
 */
(function (root) {
  'use strict';

  /* ==================== 基础工具 ==================== */

  function str(v) {
    return v == null ? '' : String(v);
  }

  function isBlank(v) {
    return !str(v).trim();
  }

  function escapeHtml(s) {
    return str(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // YAML 双引号字符串（与 JSON 字符串转义兼容，主流 YAML 解析器均可读）
  function yamlString(s) {
    return JSON.stringify(str(s));
  }

  // 本地墙钟时间串（yyyy-MM-ddTHH:mm:ss.SSS，不带 Z），与 publish_time 风格一致
  function wallClockNow() {
    var d = new Date();
    var local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 23);
  }

  /* ==================== 媒体文件名 ==================== */

  var MIME_EXT = {
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/bmp': 'bmp',
    'image/svg+xml': 'svg',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov'
  };

  var FALLBACK_EXT = { image: 'png', video: 'mp4' };

  // jpeg → jpg，与 MIME_EXT 的 image/jpeg 映射保持一致
  function normalizeExt(ext) {
    var e = String(ext || '').toLowerCase();
    return e === 'jpeg' ? 'jpg' : e;
  }

  // 从 URL 推断媒体扩展名：data: mime → wx_fmt 查询参数 → 路径扩展名 → 按类型回退
  function guessMediaExt(url, kind) {
    var u = str(url).trim();
    var fallback = FALLBACK_EXT[kind] || FALLBACK_EXT.image;
    if (!u) return { ext: fallback, guessed: true };
    var dataMime = /^data:([^;,]+)[;,]/.exec(u);
    if (dataMime) {
      var mapped = MIME_EXT[dataMime[1].toLowerCase()];
      return { ext: mapped || fallback, guessed: !mapped };
    }
    var wxFmt = /[?&]wx_fmt=([a-zA-Z0-9]+)/.exec(u);
    if (wxFmt) return { ext: normalizeExt(wxFmt[1]), guessed: false };
    var pathPart = u.split('#')[0].split('?')[0];
    var filePart = pathPart.split('/').pop() || '';
    var dot = filePart.lastIndexOf('.');
    if (dot > 0 && dot < filePart.length - 1) {
      var ext = normalizeExt(filePart.slice(dot + 1));
      if (/^[a-z0-9]{2,5}$/.test(ext)) return { ext: ext, guessed: false };
    }
    return { ext: fallback, guessed: true };
  }

  // 生成媒体在导出目录内的相对路径：images/image_N.ext / videos/video_N.ext
  function mediaRelPath(entry, index) {
    var kind = str(entry && (entry.media_type || entry.kind)) === 'video' ? 'video' : 'image';
    var dir = kind === 'video' ? 'videos' : 'images';
    var name = (kind === 'video' ? 'video_' : 'image_') + index + '.' + guessMediaExt(entry && entry.url, kind).ext;
    return dir + '/' + name;
  }

  function posterRelPath(entry, index) {
    var base = mediaRelPath({ media_type: 'video', url: entry && entry.poster }, index);
    // videos/video_N.ext → videos/video_N_poster.ext
    return base.replace(/\.([a-z0-9]+)$/i, '_poster.$1');
  }

  /* ==================== 媒体引用前缀 ==================== */

  // 下载通道：background 在落盘前设置为「<标题>_media/」等前缀；
  // backend 通道：保持默认（web 端媒体与 bodyMd 同根）。单线程消费，无并发问题。
  var mediaPrefix = '';

  function setMediaPrefix(prefix) {
    mediaPrefix = str(prefix == null ? '' : prefix).replace(/\\/g, '/');
    if (mediaPrefix && mediaPrefix.slice(-1) !== '/') mediaPrefix += '/';
    return mediaPrefix;
  }

  function getMediaPrefix() {
    return mediaPrefix;
  }

  function mediaHref(relPath) {
    var p = str(relPath).replace(/^\/+/, '');
    return mediaPrefix ? mediaPrefix + p : p;
  }

  /* ==================== blocks → HTML ==================== */

  function mediaBlockHtml(block, media) {
    var idx = block.media_index;
    var entry = (idx != null && media[idx]) || null;
    if (!entry) return '<p>[媒体缺失]</p>';
    var kind = str(entry.media_type || entry.kind) === 'video' ? 'video' : 'image';
    var alt = escapeHtml(entry.description || '');
    if (kind === 'video') {
      var href = escapeHtml(mediaHref(mediaRelPath(entry, idx)));
      var out = '<p><a href="' + href + '">视频 · 本地文件</a></p>';
      if (entry.poster) {
        out += '<p><img src="' + escapeHtml(mediaHref(posterRelPath(entry, idx))) + '" alt="视频封面"></p>';
      }
      return out;
    }
    if (!entry.url) return '<p>[图片缺失]</p>';
    return '<p><img src="' + escapeHtml(mediaHref(mediaRelPath(entry, idx))) + '" alt="' + alt + '"></p>';
  }

  function embedBlockHtml(block, label) {
    var url = str(block.embed_url || block.url || '');
    if (!url) return '';
    return '<p><a href="' + escapeHtml(url) + '">' + escapeHtml(label) + '</a></p>';
  }

  // 用 block.rows 重建规范表格，确保首行为表头，GFM 表格规则可转换
  function tableHtml(block) {
    var rows = block.rows;
    if (!Array.isArray(rows) || !rows.length) return str(block.html);
    var body = rows.slice(1).map(function (tr) {
      var cells = (Array.isArray(tr) ? tr : []).map(function (td) { return '<td>' + escapeHtml(td) + '</td>'; });
      return '<tr>' + (cells.join('') || '<td></td>') + '</tr>';
    }).join('');
    var head = (Array.isArray(rows[0]) ? rows[0] : []).map(function (th) { return '<th>' + escapeHtml(th) + '</th>'; });
    return '<table><thead><tr>' + (head.join('') || '<th></th>') + '</tr></thead><tbody>' + body + '</tbody></table>';
  }

  function blockHtml(block, media) {
    if (!block || typeof block !== 'object') return '';
    switch (block.kind) {
      case 'image':
      case 'video':
        return mediaBlockHtml(block, media);
      case 'video_embed':
        return embedBlockHtml(block, '视频 · 站外播放');
      case 'audio':
        return embedBlockHtml(block, '音频 · 站外播放');
      case 'table':
        return tableHtml(block);
      default:
        if (block.html) return str(block.html);
        if (block.text) return '<p>' + escapeHtml(block.text) + '</p>';
        return '';
    }
  }

  function blocksToHtml(blocks, media) {
    var list = Array.isArray(blocks) ? blocks : [];
    var m = Array.isArray(media) ? media : [];
    return list.map(function (b) { return blockHtml(b, m); }).filter(function (h) { return !!h; }).join('\n');
  }

  /* ==================== frontmatter ==================== */

  function buildFrontmatter(meta) {
    meta = meta || {};
    var lines = ['---'];
    if (!isBlank(meta.title)) lines.push('title: ' + yamlString(meta.title));
    if (!isBlank(meta.author_name)) lines.push('author_name: ' + yamlString(meta.author_name));
    if (!isBlank(meta.author_handle)) lines.push('author_handle: ' + yamlString(meta.author_handle));
    if (!isBlank(meta.source)) lines.push('source: ' + yamlString(meta.source));
    if (!isBlank(meta.publish_time)) lines.push('publish_time: ' + yamlString(meta.publish_time));
    if (!isBlank(meta.original_url)) lines.push('original_url: ' + yamlString(meta.original_url));
    lines.push('exported_at: ' + yamlString(meta.exported_at || wallClockNow()));
    lines.push('image_count: ' + (Number(meta.image_count) || 0));
    lines.push('video_count: ' + (Number(meta.video_count) || 0));
    lines.push('---');
    return lines.join('\n');
  }

  /* ==================== Turndown 装配 ==================== */

  function htmlToMarkdown(html) {
    if (!html || !html.trim()) return '';
    var Service = root.TurndownService;
    if (typeof Service !== 'function') {
      throw new Error('Turndown 未加载：请确认 vendor/turndown.js 已前置注入');
    }
    var td = new Service({
      headingStyle: 'atx',
      codeBlockStyle: 'fenced',
      bulletListMarker: '-',
      emDelimiter: '*'
    });
    if (typeof root.turndownPluginGfm === 'object' && root.turndownPluginGfm && typeof root.turndownPluginGfm.gfm === 'function') {
      td.use(root.turndownPluginGfm.gfm);
    }
    return td.turndown(html).replace(/\s+$/, '');
  }

  /* ==================== 计数与清单 ==================== */

  function countMedia(snapshot) {
    var media = Array.isArray(snapshot.media) ? snapshot.media : [];
    var imageCount = 0;
    var videoCount = 0;
    media.forEach(function (m) {
      if (str(m && (m.media_type || m.kind)) === 'video') videoCount++;
      else imageCount++;
    });
    return { imageCount: imageCount, videoCount: videoCount };
  }

  // 媒体文件清单：后台下载/上传通道按此落盘与命名，保证与 md 引用一致
  function mediaFileMap(snapshot) {
    var media = Array.isArray(snapshot.media) ? snapshot.media : [];
    var out = [];
    media.forEach(function (entry, index) {
      var kind = str(entry && (entry.media_type || entry.kind)) === 'video' ? 'video' : 'image';
      var item = {
        index: index,
        kind: kind,
        rel_path: mediaHref(mediaRelPath(entry, index)),
        url: str(entry && entry.url)
      };
      if (kind === 'video' && entry && entry.poster) {
        item.poster_rel_path = mediaHref(posterRelPath(entry, index));
        item.poster_url = str(entry.poster);
      }
      out.push(item);
    });
    return out;
  }

  /* ==================== 主入口 ==================== */

  function buildMarkdown(snapshot) {
    snapshot = snapshot || {};
    var media = Array.isArray(snapshot.media) ? snapshot.media : [];
    var blocks = Array.isArray(snapshot.blocks) ? snapshot.blocks : [];
    var counts = countMedia(snapshot);
    var fm = buildFrontmatter({
      title: snapshot.title,
      author_name: snapshot.author_name,
      author_handle: snapshot.author_handle,
      source: snapshot.source || snapshot.adapter,
      publish_time: snapshot.publish_time,
      original_url: snapshot.original_url,
      exported_at: wallClockNow(),
      image_count: counts.imageCount,
      video_count: counts.videoCount
    });
    var body = htmlToMarkdown(blocksToHtml(blocks, media));
    return body ? fm + '\n\n' + body + '\n' : fm + '\n';
  }

  function buildReport(snapshot, jobDir) {
    snapshot = snapshot || {};
    var dir = str(jobDir == null ? '' : jobDir).replace(/[\\/]+$/, '');
    var media = Array.isArray(snapshot.media) ? snapshot.media : [];
    var blocks = Array.isArray(snapshot.blocks) ? snapshot.blocks : [];
    var counts = countMedia(snapshot);
    var warnings = Array.isArray(snapshot.warnings) ? snapshot.warnings.slice() : [];

    var files = [{
      path: dir ? dir + '/article.md' : 'article.md',
      kind: 'markdown'
    }];
    media.forEach(function (entry, index) {
      var kind = str(entry && (entry.media_type || entry.kind)) === 'video' ? 'video' : 'image';
      var ext = guessMediaExt(entry && entry.url, kind);
      if (ext.guessed) {
        warnings.push('第 ' + (index + 1) + ' 个媒体无法识别扩展名，已按 ' + ext.ext + ' 处理');
      }
      var rel = mediaRelPath(entry, index);
      files.push({ path: dir ? dir + '/' + mediaHref(rel) : mediaHref(rel), kind: kind });
      if (kind === 'video' && entry && entry.poster) {
        files.push({ path: dir ? dir + '/' + mediaHref(posterRelPath(entry, index)) : mediaHref(posterRelPath(entry, index)), kind: 'poster' });
      }
    });

    if (!blocks.length) warnings.push('正文为空，未生成正文内容');
    if (!str(snapshot.title).trim()) warnings.push('未找到文章标题');
    if (!str(snapshot.original_url).trim()) warnings.push('未找到原文链接');

    return {
      job_dir: dir,
      title: str(snapshot.title),
      source: str(snapshot.source || snapshot.adapter),
      original_url: str(snapshot.original_url),
      markdown_file: dir ? dir + '/article.md' : 'article.md',
      counts: {
        blocks: blocks.length,
        images: counts.imageCount,
        videos: counts.videoCount,
        chars: str(buildMarkdown(snapshot)).length
      },
      files: files,
      warnings: warnings
    };
  }

  /* ==================== 导出 ==================== */

  var api = {
    buildFrontmatter: buildFrontmatter,
    blocksToHtml: blocksToHtml,
    buildMarkdown: buildMarkdown,
    buildReport: buildReport,
    mediaFileMap: mediaFileMap,
    mediaRelPath: mediaRelPath,
    posterRelPath: posterRelPath,
    guessMediaExt: guessMediaExt,
    setMediaPrefix: setMediaPrefix,
    getMediaPrefix: getMediaPrefix,
    wallClockNow: wallClockNow
  };

  root.WxdocMd = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
