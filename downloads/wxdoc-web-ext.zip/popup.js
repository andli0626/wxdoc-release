const statusEl = document.getElementById('status');
const statusTextEl = statusEl.querySelector('.status-text');
// 状态语义交给 CSS（data-state → 明暗两套语义色），不再往 DOM 上写死颜色
function setStatus(text, state) {
  statusTextEl.textContent = text;
  statusEl.dataset.state = state;
}
(function fillVersion() {
  var el = document.getElementById('popVer');
  if (!el) return;
  try {
    var v = chrome.runtime.getManifest().version;
    el.textContent = '浏览器扩展 · v' + v;
  } catch (e) { /* manifest 不可用时保留静态文案 */ }
})();
async function check() {
  setStatus('正在检测…', 'checking');
  const s = await chrome.storage.local.get({mode: 'desktop', baseUrl: 'http://127.0.0.1:17321', serverUrl: '', apiToken: ''});
  // 旧版 mac-epoint 服务地址（172.20.246.65:16688/16689/16699）统一校正为当前默认地址，自动改写历史存储值
  var LEGACY = ['http://172.20.246.65:16688', 'http://172.20.246.65:16689', 'http://172.20.246.65:16699'];
  if (LEGACY.indexOf((s.serverUrl || '').replace(/\/+$/, '').toLowerCase()) !== -1) {
    s.serverUrl = 'http://172.20.239.21:16688';
    chrome.storage.local.set({serverUrl: s.serverUrl});
  }
  const baseUrl = s.mode === 'direct' ? s.serverUrl : s.baseUrl;
  if (!baseUrl) {
    setStatus(s.mode === 'direct' ? '未配置服务端地址，请点击左侧设置' : '未配置桌面端地址，请点击左侧设置', 'bad');
    return;
  }
  var r = null;
  try {
    if (s.mode === 'direct') {
      // 直连模式：配置了 Token 时调用校验接口（/api/auth/token/verify 会真实返回 401），
      // 避免使用 /api/health（不校验 Token，错误/缺失令牌同样返回 200）导致误报"已连接"
      if (s.apiToken) {
        var verifyResp = await fetch(baseUrl.replace(/\/$/, '') + '/api/auth/token/verify', {
          method: 'POST',
          headers: {Authorization: 'Bearer ' + s.apiToken}
        });
        r = verifyResp.ok ? {ok: true, tokenVerified: true} : {ok: false, error: 'HTTP ' + verifyResp.status, code: verifyResp.status === 401 ? 'unauthorized' : 'offline'};
      } else {
        var hResp = await fetch(baseUrl.replace(/\/$/, '') + '/api/health');
        r = hResp.ok ? {ok: true, tokenVerified: false} : {ok: false, error: 'HTTP ' + hResp.status, code: hResp.status === 401 ? 'unauthorized' : 'offline'};
      }
    } else {
      r = await chrome.runtime.sendMessage({type: 'health'});
    }
  } catch (e) { r = {ok: false, error: e.message}; }
  if (r && r.ok) {
    if (s.mode === 'direct') {
      if (r.tokenVerified) {
        setStatus('已连接服务端（直连模式）· Token 有效', 'ok');
      } else {
        setStatus('服务端可达（未配置 Token，直连上传将被拒绝）', 'warn');
      }
    } else {
      setStatus('已连接微文存阅' + (r.data && r.data.version ? ' (' + r.data.version + ')' : '') + '（桌面端模式）', 'ok');
    }
  } else if (r && r.code === 'unauthorized') {
    setStatus('认证失败：Token 无效，请在设置中更新', 'warn');
  } else {
    if (s.mode === 'direct') {
      setStatus('未连接服务端：' + ((r && r.error) ? r.error : '请检查网络或服务端地址'), 'bad');
    } else {
      setStatus('未连接桌面客户端：' + ((r && r.error) ? r.error : '请先打开微文存阅桌面客户端'), 'bad');
    }
  }
}
// ===== 访问入口：环境切换 + 新标签页打开 =====
var ENTRY_SHORT = { web: 'Web', h5: 'H5', app: 'APP 下载', apiDoc: 'API 文档', admin: '管理端' };
var entryMsgEl = document.getElementById('entryMsg');
var entryProfileEl = document.getElementById('entryProfile');
var entryGridEl = document.getElementById('entryGrid');
var entryState = {};

function setEntryMsg(text, state) {
  entryMsgEl.dataset.state = state || 'idle';
  entryMsgEl.textContent = text || '';
}

function renderEntries() {
  var r = WwcnEntries.resolveEntries(entryState);
  entryProfileEl.value = r.profile;
  entryGridEl.textContent = '';
  var dynamic = WwcnEntries.profileById(r.profile).dynamic;
  var hint = '';
  var usable = 0;
  WwcnEntries.ENTRY_KEYS.forEach(function (key) {
    var url = r.urls[key];
    var btn = document.createElement('button');
    btn.className = 'entry-open';
    btn.textContent = ENTRY_SHORT[key];
    btn.setAttribute('data-entry', key);
    if (!WwcnEntries.isHttpUrl(url)) {
      btn.disabled = true;
      btn.title = r.notes[key] || '该环境未提供此入口';
      hint = hint || r.notes[key] || (dynamic
        ? '未配置服务端地址，请到「设置 → 访问入口」填写，或改用预设环境'
        : WwcnEntries.ENTRY_LABELS[key] + '：该环境未提供此入口');
    } else {
      btn.title = url + '（' + r.sources[key] + '）' + (r.notes[key] ? ' · ' + r.notes[key] : '');
      // 指向别处环境的入口必须当面说明，光靠悬停提示容易看漏
      if (!hint && r.notes[key]) hint = WwcnEntries.ENTRY_LABELS[key] + '：' + r.notes[key];
      btn.onclick = function () { WwcnEntries.openEntry(url); };
      usable++;
    }
    entryGridEl.appendChild(btn);
  });
  // 一个入口都打不开（多半是没配服务端地址）是需要处理的事，其余只是环境说明
  setEntryMsg(hint, usable === 0 && hint ? 'warn' : 'idle');
}

WwcnEntries.PROFILES.forEach(function (p) {
  var opt = document.createElement('option');
  opt.value = p.id;
  opt.textContent = p.label;
  entryProfileEl.appendChild(opt);
});

entryProfileEl.onchange = function () {
  entryState.entryProfile = entryProfileEl.value;
  chrome.storage.local.set({ entryProfile: entryProfileEl.value });
  renderEntries();
};

chrome.storage.local.get(Object.assign({ mode: 'desktop', serverUrl: '' }, WwcnEntries.STORAGE_DEFAULTS), function (s) {
  entryState = s || {};
  renderEntries();
});

document.getElementById('check').onclick = check;
document.getElementById('options').onclick = function() { chrome.runtime.openOptionsPage(); };
check();
