/**
 * adapter.js — 站点适配器（微信 / X），取代 ext-wechat.js
 *
 * 设计契约（方案 §5.2）：
 *  - 每个适配器：`{id, host, urlPatterns, selectors, probe(doc, loc), extract(doc, loc)}`。
 *    probe 返回 `{matched, reason}`：matched=false 时 reason 取 host/url/dom，便于 UI 说明原因；
 *    extract 产出文章对象（blocks 与 media 顺序、计数完整）。
 *  - 注册表：`pickAdapter(loc)` 按 host 选适配器，`probeAll(doc, loc)` 批量探测（便于调试与单测）。
 *  - extract 末尾统一 `original_url = WxdocShared.normalizeArticleUrl(href)`，服务端据此去重。
 *  - 纯函数助手（toWallClock / parseCnTime / ctStampFromScripts / matchXPath / isWechatMediaUrl /
 *    normalizeSrc）不触碰 DOM，可在 Node 中直接 require 后单测（tests/adapter.test.js）。
 *  - media 条目同时带 kind 与 media_type（后者兼容 v1 content.js 与 shared.filenameFor）。
 *
 * 迁移来源：ext-wechat.js（桌面端 extract-wechat.js + wechat-content-target.js 移植版），
 * 迁移完成后删除 ext-wechat.js。
 */
(function (root) {
  'use strict';

  var SH = root.WxdocShared || {};

  /* ==================== 纯函数助手（Node 可测） ==================== */

  function pad(n, w) { return String(n).padStart(w || 2, '0'); }

  // 墙钟时间串 yyyy-MM-ddTHH:mm:ss.SSS（不带 Z）：服务端按本地时间解析，转 UTC 会少一天
  function toWallClock(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' +
      pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) + '.' + pad(d.getMilliseconds(), 3);
  }

  // "2024年5月20日 08:30" / "2024年5月20日" → 墙钟串；解析失败返回 null
  function parseCnTime(text) {
    var m = /(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/.exec(text || '');
    if (!m) return null;
    var d = new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
    return Number.isNaN(d.getTime()) ? null : toWallClock(d);
  }

  // 从内联脚本文本数组里找 ct="<10位秒级>"（微信发布时间兜底，无可见日期时用）
  function ctStampFromScripts(scripts) {
    var list = scripts || [];
    for (var i = 0; i < list.length; i++) {
      var m = /(?:^|[^A-Za-z0-9_$.:])ct\s*=\s*["'](\d{10})["']/.exec(list[i] || '');
      if (m) return m[1];
    }
    return '';
  }

  // X 路径形态：'article'（/i/article/<id> 或 /<user>/article/<id>）/ 'status' / ''
  function matchXPath(pathname) {
    var p = String(pathname || '');
    if (/^\/(?:i|[a-zA-Z0-9_]{1,15})\/article\/\d+\/?$/.test(p)) return 'article';
    if (/^\/[a-zA-Z0-9_]{1,15}\/status\/\d+\/?$/.test(p)) return 'status';
    return '';
  }

  // 微信图片 CDN 白名单（mp.weixin.qq.com 之外的转载站图片一律丢弃，避免抓到站点 logo）
  var WECHAT_MEDIA_CDN = /^https?:\/\/(mmbiz\.qpic\.cn|mmbiz\.qlogo\.cn|mmsns\.qpic\.cn|mmsns\.qlogo\.cn|shp\.qpic\.cn)/;
  function isWechatMediaUrl(url) {
    return !!url && (WECHAT_MEDIA_CDN.test(url) || url.indexOf('data:') === 0);
  }

  // 协议相对地址补 https:
  function normalizeSrc(src) {
    return src && src.indexOf('//') === 0 ? 'https:' + src : (src || '');
  }

  /* ==================== 微信原生视频（mpvideo）配置解析 ==================== */
  // 文章内联 JS 携带 video_page_infos：每个 video_id 下 mp_video_trans_info 有多档
  // 带签名的 mpvideo.qpic.cn mp4 直址。播放器 iframe auto=0 不自动起播，内层
  // <video> 往往不存在，须从配置解析 vid → 真实地址（方案 13 §4.1，双端同构）。

  var MPVIDEO_URL_RE = /https?:\/\/mpvideo\.qpic\.cn\/[^'\s]+/;

  // 脚本字符串里参数分隔符是 \x26 / \x26amp; 转义形态；签名参数原样保留，协议升 https（实测同参可下）
  function normalizeMpvideoUrl(url) {
    var u = String(url || '');
    u = u.replace(/\\x26amp;/g, '&').replace(/\\x26/g, '&').replace(/&amp;/g, '&');
    if (u.indexOf('http://') === 0) u = 'https://' + u.slice('http://'.length);
    return u;
  }

  function firstNum(re, text) {
    var m = re.exec(text);
    return m ? parseInt(m[1], 10) : 0;
  }

  // scripts：内联 script textContent 数组 → { 'wxv_x': {vid,url,width,height,filesize,duration_ms,deleted} }
  function parseWechatVideoConfig(scripts) {
    var map = {};
    var list = scripts || [];
    for (var s = 0; s < list.length; s++) {
      var text = list[s] || '';
      if (text.indexOf('video_id') === -1 || text.indexOf('mp_video_trans_info') === -1) continue;
      var marks = [];
      var re = /video_id:\s*'(wxv_[^']+)'/g, m;
      while ((m = re.exec(text))) marks.push({ vid: m[1], start: m.index });
      for (var i = 0; i < marks.length; i++) {
        var from = marks[i].start;
        var to = (i + 1 < marks.length) ? marks[i + 1].start : Math.min(text.length, from + 12000);
        var seg = text.slice(from, to);
        var best = null;
        var parts = seg.split("format_id:");
        for (var p = 1; p < parts.length; p++) {
          var chunk = parts[p];
          var um = /url:\s*'([^']+)'/.exec(chunk);
          if (!um || !MPVIDEO_URL_RE.test(um[1])) continue;
          var e = {
            url: normalizeMpvideoUrl(um[1]),
            width: firstNum(/width:\s*'(\d+)'/, chunk),
            height: firstNum(/height:\s*'(\d+)'/, chunk),
            filesize: firstNum(/filesize:\s*'(\d+)'/, chunk),
            duration_ms: firstNum(/duration_ms:\s*'(\d+)'/, chunk)
          };
          if (!best || e.filesize > best.filesize ||
            (!e.filesize && !best.filesize && e.width * e.height > best.width * best.height)) best = e;
        }
        if (!best) continue;
        var del = /is_mp_video_delete:\s*'(\d)'/.exec(seg);
        var forbid = /is_mp_video_forbid:\s*'(\d)'/.exec(seg);
        best.deleted = !!(del && del[1] !== '0') || !!(forbid && forbid[1] !== '0');
        best.vid = marks[i].vid;
        if (!map[marks[i].vid]) map[marks[i].vid] = best;
      }
    }
    return map;
  }

  // 从播放器 iframe 的 data-src（readtemplate?...&vid=wxv_x）兜底取 vid
  function vidFromPlayerSrc(src) {
    var m = /vid=(wxv_[\w]+)/.exec(String(src || ''));
    return m ? m[1] : '';
  }

  /* ==================== 通用小工具 ==================== */

  function tagOf(el) { return (el && el.tagName || '').toLowerCase(); }
  function txtOf(el) { return el ? (el.innerText || el.textContent || '').replace(/\u00a0/g, ' ').trim() : ''; }

  // 位置对象：loc 优先，否则从 doc 取（Node 冒烟时可传假 doc + loc）
  function locOf(doc, loc) {
    if (loc) return loc;
    if (doc && doc.location) return doc.location;
    if (typeof document !== 'undefined' && document.location) return document.location;
    return null;
  }

  function hostOf(loc) {
    return String(loc && loc.hostname || '').toLowerCase().replace(/:\d+$/, '').replace(/^www\./, '');
  }

  // extract 统一收口：original_url 归一化（服务端去重口径）
  function finalizeUrl(result, doc, loc) {
    var l = locOf(doc, loc);
    var href = l ? l.href : '';
    result.original_url = (SH.normalizeArticleUrl && SH.normalizeArticleUrl(href)) || href;
    return result;
  }

  // 微信浅色 callout 背景判定（rgba 解析）：够亮、非纯白、有色偏
  function isLightCalloutBg(bg) {
    var m = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)/.exec(bg || '');
    if (!m) return false;
    var r = +m[1], g = +m[2], b = +m[3];
    var alpha = m[4] === undefined ? 1 : +m[4];
    var mn = Math.min(r, g, b), mx = Math.max(r, g, b);
    return alpha >= 0.5 && mn >= 225 && !(r >= 252 && g >= 252 && b >= 252) && ((mx - mn) >= 4 || mn <= 245);
  }

  var SKIP_TAGS = ['script', 'style', 'button', 'svg', 'nav', 'link', 'noscript', 'iframe'];
  var BLOCK_TAGS = ['p', 'section', 'div', 'ul', 'ol', 'li', 'table', 'thead', 'tbody', 'tr', 'pre', 'figure', 'blockquote', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
  var KEEP_INLINE = ['a', 'code', 'strong', 'b', 'em', 'i', 'u', 's', 'br', 'span'];
  var PART_RE = /^\s*(?:part|篇)\s*[:：.\-—]?\s*[a-z0-9一二三四五六七八九十]{0,3}\s*$|^\s*第[一二三四五六七八九十0-9]+[章节部分]\s*$/i;

  function hasBlockChild(el) {
    for (var i = 0; i < el.children.length; i++) {
      var t = tagOf(el.children[i]);
      if (BLOCK_TAGS.indexOf(t) !== -1 || t.indexOf('mp-') === 0) return true;
    }
    return false;
  }
  function hasMediaDeep(el) { return !!el.querySelector('img, video, iframe, audio, mpvoice'); }

  // 内联 HTML 清洗：只保留 KEEP_INLINE 与 href，其余标签拆壳保留文本
  function inlineHtml(el) {
    var clone = el.cloneNode(true);
    var cleanNode = function (node) {
      var children = Array.prototype.slice.call(node.childNodes);
      children.forEach(function (child) {
        if (child.nodeType === 3) return;
        if (child.nodeType !== 1) { node.removeChild(child); return; }
        var t = tagOf(child);
        if (KEEP_INLINE.indexOf(t) === -1) {
          cleanNode(child);
          while (child.firstChild) node.insertBefore(child.firstChild, child);
          node.removeChild(child);
          return;
        }
        cleanNode(child);
        Array.prototype.slice.call(child.attributes).forEach(function (a) {
          if (a.name !== 'href') child.removeAttribute(a.name);
        });
      });
    };
    cleanNode(clone);
    return clone.innerHTML
      .replace(/<br\s*\/?>\s*(?=<\/(p|span|div|section)>)/gi, '')
      .replace(/^\s*(<br\s*\/?>\s*)+/gi, '')
      .replace(/(<br\s*\/?>\s*)+$/gi, '')
      .trim();
  }

  function leafParagraph(el) {
    var text = txtOf(el);
    if (!text || hasBlockChild(el) || hasMediaDeep(el)) return null;
    var html = inlineHtml(el);
    if (!html.replace(/<[^>]+>/g, '').trim()) return null;
    return { text: text, html: '<p>' + html + '</p>' };
  }

  function collectParagraphs(el, out) {
    for (var i = 0; i < el.children.length; i++) {
      var child = el.children[i];
      if (SKIP_TAGS.indexOf(tagOf(child)) !== -1) continue;
      var leaf = leafParagraph(child);
      if (leaf) { out.push(leaf); continue; }
      if (child.children.length) collectParagraphs(child, out);
    }
  }

  /* ==================== 微信适配器 ==================== */

  var WECHAT_SELECTORS = {
    root: ['#js_content', '[id="js_content"]'],
    title: ['#activity-name', '.rich_media_title'],
    titleMeta: 'meta[property="og:title"]',
    author: ['#js_name', '.rich_media_meta_text'],
    publishTime: ['#publish_time', '.rich_media_meta_text']
  };

  function q(doc, list) {
    for (var i = 0; i < list.length; i++) {
      var el = doc.querySelector(list[i]);
      if (el) return el;
    }
    return null;
  }

  var WECHAT_ADAPTER = {
    id: 'wechat',
    host: 'mp.weixin.qq.com',
    urlPatterns: [/^\/s(?:\/|$|\?)/, /^\/mp\/appmsg\//],
    selectors: WECHAT_SELECTORS,

    probe: function (doc, loc) {
      var l = locOf(doc, loc);
      if (!l) return { matched: false, reason: 'no-location' };
      if (hostOf(l) !== WECHAT_ADAPTER.host) return { matched: false, reason: 'host' };
      var byUrl = WECHAT_ADAPTER.urlPatterns.some(function (re) { return re.test(l.pathname || ''); });
      if (byUrl) return { matched: true, reason: 'url' };
      var hasRoot = !!(doc && doc.querySelector('#js_content'));
      return { matched: hasRoot, reason: hasRoot ? 'dom' : 'url' };
    },

    extract: function (doc, loc) {
      var rootEl = doc.querySelector('#js_content') || doc.querySelector('[id="js_content"]');
      if (!rootEl) throw new Error('未找到微信公众号文章内容，页面尚未加载完成或需要验证码');
      if (hostOf(locOf(doc, loc)) !== WECHAT_ADAPTER.host) throw new Error('当前页面不是微信公众号文章');

      // 标题兜底链：#activity-name → .rich_media_title → og:title → document.title 去「_」后缀
      var titleNode = q(doc, WECHAT_SELECTORS.title);
      var title = txtOf(titleNode) ||
        (doc.querySelector(WECHAT_SELECTORS.titleMeta) || {}).content ||
        (doc.title || '').replace(/_.*$/, '');

      // 作者
      var author = txtOf(doc.querySelector('#js_name')) || '';

      // 发布时间：页面文本（本地墙钟）优先，内联脚本 ct 秒级时间戳兜底
      var publishNode = doc.querySelector('#publish_time');
      var scripts = [];
      if (typeof doc.scripts !== 'undefined' && doc.scripts.length) {
        for (var i = 0; i < doc.scripts.length; i++) scripts.push(doc.scripts[i].textContent || '');
      } else {
        scripts.push(doc.documentElement ? (doc.documentElement.innerHTML || '') : '');
      }
      var ctStamp = ctStampFromScripts(scripts);
      var publishTime = parseCnTime(publishNode && (publishNode.textContent || '')) ||
        (ctStamp ? toWallClock(new Date(+ctStamp * 1000)) : null);

      // 原生视频配置表：vid → 最优档直址（解析失败不报错，走 iframe/占位兜底）
      var videoCfg = parseWechatVideoConfig(scripts);

      var blocks = [], media = [], seen = {};

      var addVideoFromConfig = function (cfg, el) {
        var poster = '';
        var cover = (el && el.getAttribute && el.getAttribute('data-cover')) || '';
        if (cover) {
          try { poster = decodeURIComponent(cover); } catch (e) { poster = cover; }
          poster = normalizeSrc(poster.replace(/^http:/, 'https:'));
        }
        var key = 'video:' + cfg.url;
        if (seen[key]) return;
        seen[key] = true;
        var i = media.length;
        media.push({
          url: cfg.url, kind: 'video', media_type: 'video', description: null, poster: poster || null,
          vid: cfg.vid || null, filesize: cfg.filesize || 0, duration_ms: cfg.duration_ms || 0
        });
        blocks.push({ kind: 'video', media_index: i, text: '', html: '' });
      };

      var addMedia = function (el, type) {
        var src = el.getAttribute('data-src') || el.currentSrc || el.src || '';
        if (!src && type === 'image') src = el.getAttribute('data-src') || '';
        if (!src && type === 'video') src = (el.querySelector('source') || {}).src || '';
        src = normalizeSrc(src);
        var poster = type === 'video' ? normalizeSrc(el.poster || el.getAttribute('poster') || '') || null : null;
        var key = type + ':' + (src || poster);
        if (seen[key]) return;
        seen[key] = true;
        // 非白名单且非 data: 的图片直接丢弃（外部站点 logo/统计像素）
        if (type === 'image' && src && !isWechatMediaUrl(src)) return;
        var i = media.length;
        media.push({ url: src, kind: type, media_type: type, description: el.alt || el.getAttribute('alt') || null, poster: poster });
        blocks.push({ kind: type, media_index: i, text: '', html: '' });
      };

      function walk(el) {
        if (!el || el.nodeType !== 1) return;
        var tag = tagOf(el);

        // 视频宿主判定必须先于 SKIP_TAGS：video_iframe 本身就是 <iframe>，
        // 早退会让未起播的原生视频整块丢失（历史缺陷）
        var cls = typeof el.className === 'string' ? el.className : '';
        var isVideoHost = tag.indexOf('mp-common-video') === 0 || tag === 'mpvideosnap' ||
          el.hasAttribute('vid') || (el.id || '').indexOf('js_mp_video_container') === 0 ||
          cls.indexOf('video_iframe') !== -1;
        if (SKIP_TAGS.indexOf(tag) !== -1 && !isVideoHost) return;

        if (isVideoHost) {
          // 优先内联配置解析（auto=0 播放器常无内层 <video>）；次选已起播的内层 <video>；
          // 都拿不到则保留 video_embed 占位并记录 vid，纳入缺口补齐口径。
          var vsrc = el.getAttribute('data-src') || el.src || '';
          var vid = el.getAttribute('data-mpvid') || el.getAttribute('vid') || vidFromPlayerSrc(vsrc);
          var cfg = vid ? videoCfg[vid] : null;
          if (cfg && cfg.url && !cfg.deleted) { addVideoFromConfig(cfg, el); return; }
          var innerVideo = tag === 'video' ? el : el.querySelector('video');
          if (innerVideo) { addMedia(innerVideo, 'video'); return; }
          if (vsrc) {
            blocks.push({
              kind: 'video_embed', text: '',
              html: '<iframe src="' + normalizeSrc(vsrc) + '" frameborder="0" allowfullscreen></iframe>',
              embed_url: normalizeSrc(vsrc), vid: vid || null
            });
          }
          return;
        }

        if (tag === 'iframe') {
          var src = el.src || el.getAttribute('data-src') || '';
          if (src && (src.indexOf('v.qq.com') !== -1 || src.indexOf('youku') !== -1 || src.indexOf('iframe') !== -1)) {
            blocks.push({ kind: 'video_embed', text: '', html: '<iframe src="' + src + '" frameborder="0" allowfullscreen></iframe>', embed_url: src });
          }
          return;
        }
        if (tag === 'video') { addMedia(el, 'video'); return; }
        if (tag === 'img') { addMedia(el, 'image'); return; }

        if (tag === 'mpvoice' || (el.classList && el.classList.contains('js_editor_appoint')) || el.getAttribute('name') === 'audio') {
          var audioSrc = el.getAttribute('voice_encode_fileid') || el.getAttribute('data-src') || '';
          if (audioSrc) {
            blocks.push({ kind: 'audio', text: '', html: '<audio controls src="https://res.wx.qq.com/voice/getvoice?mediaid=' + audioSrc + '"></audio>', embed_url: audioSrc });
          }
          return;
        }

        if (tag === 'pre' || (el.classList && el.classList.contains('code-snippet__fix'))) {
          var raw = (el.innerText || el.textContent || '').replace(/\u00a0/g, ' ');
          var lines = raw.replace(/\r\n?/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/^\n+|\n+$/g, '').split('\n');
          var linesHtml = lines.map(function (l) {
            return '<span class="cl">' + (l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') || ' ') + '</span>';
          }).join('');
          blocks.push({ kind: 'code', text: lines.join('\n'), html: '<pre class="wwcn-code"><code>' + linesHtml + '</code></pre>' });
          return;
        }

        if (tag === 'ul' || tag === 'ol') {
          var clone = el.cloneNode(true);
          clone.querySelectorAll('script,style,button,svg').forEach(function (n) { n.remove(); });
          clone.querySelectorAll('*').forEach(function (n) {
            Array.prototype.slice.call(n.attributes).forEach(function (a) { if (a.name !== 'href') n.removeAttribute(a.name); });
          });
          blocks.push({ kind: tag === 'ul' ? 'list' : 'ordered_list', text: txtOf(el), html: clone.outerHTML });
          return;
        }

        if (tag === 'table') {
          var tclone = el.cloneNode(true);
          tclone.querySelectorAll('script,style,button,svg').forEach(function (n) { n.remove(); });
          tclone.className = 'wwcn-table';
          tclone.querySelectorAll('*').forEach(function (n) {
            Array.prototype.slice.call(n.attributes).forEach(function (a) {
              if (['colspan', 'rowspan', 'start'].indexOf(a.name) === -1) n.removeAttribute(a.name);
            });
          });
          blocks.push({
            kind: 'table',
            text: txtOf(el),
            html: tclone.outerHTML,
            rows: Array.prototype.slice.call(el.querySelectorAll('tr')).map(function (tr) {
              return Array.prototype.slice.call(tr.querySelectorAll('th,td')).map(function (td) { return td.textContent.trim(); });
            })
          });
          return;
        }

        var text = txtOf(el);
        var cs = (el.ownerDocument.defaultView || root.self).getComputedStyle(el);

        if (isLightCalloutBg(cs.backgroundColor) && text && !hasMediaDeep(el) &&
          (tag === 'section' || tag === 'div' || tag === 'blockquote' || tag === 'p')) {
          var ps = [];
          collectParagraphs(el, ps);
          var inner = ps.length ? ps.map(function (p) { return p.html; }).join('') : '<p>' + inlineHtml(el) + '</p>';
          blocks.push({ kind: 'quote', text: text, html: '<div class="wwcn-callout">' + inner + '</div>' });
          return;
        }

        if ((tag === 'p' || tag === 'section' || tag === 'span') && !hasBlockChild(el) && PART_RE.test(text) && text.length <= 16) {
          blocks.push({ kind: 'paragraph', text: text, html: '<p class="wwcn-part">' + text + '</p>' });
          return;
        }

        var bold = parseInt(cs.fontWeight, 10) >= 600;
        var fontSize = parseFloat(cs.fontSize);
        if (bold && fontSize >= 17.5 && text && text.length <= 60 && !hasBlockChild(el) && !hasMediaDeep(el) && !PART_RE.test(text)) {
          blocks.push({ kind: 'heading', level: 2, text: text, html: '<h2 class="wwcn-title">' + (inlineHtml(el) || text) + '</h2>' });
          return;
        }

        var leaf = leafParagraph(el);
        if (leaf) { blocks.push({ kind: 'paragraph', text: leaf.text, html: leaf.html }); return; }

        if (!text && !hasMediaDeep(el) && !el.querySelector('ul,ol,table,pre,.code-snippet__fix')) return;

        Array.prototype.slice.call(el.childNodes).forEach(walk);
      }

      walk(rootEl);

      var warnings = [];
      if (!blocks.some(function (b) { return b.text; }) && !media.length) {
        throw new Error('微信公众号文章正文为空，可能内容被隐藏或需要登录');
      }
      if (!title) warnings.push('未找到文章标题');
      if (!author) warnings.push('未找到公众号作者信息');

      var result = {
        title: title,
        author_name: author,
        author_handle: '',
        publish_time: publishTime,
        original_url: (locOf(doc, loc) || {}).href || '',
        blocks: blocks,
        media: media,
        warnings: warnings,
        source_block_count: blocks.length,
        source: 'wechat'
      };
      return finalizeUrl(result, doc, loc);
    }
  };

  /* ==================== X / Twitter 适配器 ==================== */

  var X_SELECTORS = {
    tweetText: '[data-testid^="tweetText_"], [data-testid="tweetText"]',
    richText: '[data-testid="twitterArticleRichTextView"], [data-testid="longformRichTextComponent"], [data-testid="twitterArticleReadView"]',
    postMedia: 'article[data-testid="tweet"] [data-testid="tweetPhoto"] img, article[data-testid="tweet"] video',
    userName: ['[data-testid="User-Name"] div:first-child span', '[data-testid="User-Name"] > div span'],
    userHandle: ['[data-testid="User-Name"] a[role="link"] span', '[data-testid="User-Name"] span[href]'],
    articleTitle: '[data-testid="twitterArticleRichTextView"] h1, [data-testid="articleHeader"] h1',
    titleMeta: 'meta[property="og:title"]',
    time: 'time[datetime]'
  };

  var X_ADAPTER = {
    id: 'x',
    host: 'x.com',
    urlPatterns: [/^\/(?:i|[a-zA-Z0-9_]{1,15})\/article\/\d+\/?$/, /^\/[a-zA-Z0-9_]{1,15}\/status\/\d+\/?$/],
    selectors: X_SELECTORS,

    probe: function (doc, loc) {
      var l = locOf(doc, loc);
      if (!l) return { matched: false, reason: 'no-location' };
      var h = hostOf(l);
      if (h !== 'x.com' && h !== 'twitter.com') return { matched: false, reason: 'host' };
      var kind = matchXPath(l.pathname);
      if (kind) return { matched: true, reason: 'url', urlKind: kind };
      // DOM 兜底：页面上有推文正文根（hash 路由 / 软导航场景）
      var hasText = !!(doc && doc.querySelector(X_SELECTORS.tweetText));
      return { matched: hasText, reason: hasText ? 'dom' : 'url' };
    },

    extract: function (doc, loc) {
      var l = locOf(doc, loc);
      var urlKind = matchXPath(l && l.pathname);
      if (!urlKind) throw new Error('当前页面不是 X 文章或推文');

      var blocks = [], media = [], seen = {};

      // 作者信息
      var author = txtOf(q(doc, X_SELECTORS.userName)) || '';
      var authorHandle = txtOf(q(doc, X_SELECTORS.userHandle)) || '';

      // 标题（X Article 有标题，普通推文无标题）
      var title = '';
      if (urlKind === 'article') title = txtOf(doc.querySelector(X_SELECTORS.articleTitle)) || '';
      if (!title) {
        var ogTitle = doc.querySelector(X_SELECTORS.titleMeta);
        title = (ogTitle && ogTitle.content) || (doc.title || '').replace(/ on X$|\s*$/, '').trim();
      }

      var addMediaFromEl = function (el, type) {
        var src = normalizeSrc(el.getAttribute('src') || el.currentSrc || (el.querySelector('source') || {}).src || '');
        if (!src) return;
        var poster = type === 'video' ? normalizeSrc(el.poster || el.getAttribute('poster') || '') || null : null;
        var key = type + ':' + (src || poster);
        if (seen[key]) return;
        seen[key] = true;
        var i = media.length;
        media.push({ url: src, kind: type, media_type: type, description: el.alt || null, poster: poster });
        blocks.push({ kind: type, media_index: i, text: '', html: '' });
      };

      // 媒体：article[data-testid="tweet"] 内的图片/视频（帖子正文媒体，排除头像等）
      Array.prototype.slice.call(doc.querySelectorAll(X_SELECTORS.postMedia)).forEach(function (el) {
        if (tagOf(el) === 'video') addMediaFromEl(el, 'video');
        else addMediaFromEl(el, 'image');
      });

      var richRoot = doc.querySelector(X_SELECTORS.richText);

      if (urlKind === 'article' && richRoot) {
        var walkArticle = function (el) {
          if (!el || el.nodeType !== 1) return;
          var tag = tagOf(el);
          if (['script', 'style', 'button', 'svg', 'nav'].indexOf(tag) !== -1) return;
          if (tag === 'img') { addMediaFromEl(el, 'image'); return; }
          if (tag === 'video') { addMediaFromEl(el, 'video'); return; }

          var text = (el.innerText || '').trim();

          if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].indexOf(tag) !== -1 && text) {
            blocks.push({ kind: 'heading', level: parseInt(tag[1], 10), text: text, html: '<' + tag + '>' + text + '</' + tag + '>' });
            return;
          }
          if (tag === 'p' && text) {
            blocks.push({ kind: 'paragraph', text: text, html: '<p>' + text + '</p>' });
            return;
          }
          if (tag === 'ul' || tag === 'ol') {
            var clone = el.cloneNode(true);
            clone.querySelectorAll('script,style').forEach(function (n) { n.remove(); });
            blocks.push({ kind: tag === 'ul' ? 'list' : 'ordered_list', text: text, html: clone.outerHTML });
            return;
          }
          if (tag === 'blockquote') {
            blocks.push({ kind: 'quote', text: text, html: '<blockquote>' + text + '</blockquote>' });
            return;
          }
          if (tag === 'pre' || tag === 'code') {
            blocks.push({ kind: 'code', text: text, html: '<pre><code>' + text + '</code></pre>' });
            return;
          }
          // 有直接文本且无块级后代 → 段落
          if (text && !el.querySelector('p,div,section,h1,h2,h3,h4,ul,ol,blockquote,pre')) {
            blocks.push({ kind: 'paragraph', text: text, html: '<p>' + text + '</p>' });
            return;
          }
          Array.prototype.slice.call(el.childNodes).forEach(walkArticle);
        };
        walkArticle(richRoot);
      } else {
        // 普通推文模式：聚合所有 tweetText，按空行分段
        var tweetTexts = [];
        Array.prototype.slice.call(doc.querySelectorAll(X_SELECTORS.tweetText)).forEach(function (el) {
          var t = (el.innerText || '').trim();
          if (t) tweetTexts.push(t);
        });
        if (tweetTexts.length) {
          tweetTexts.join('\n\n').split('\n\n').forEach(function (para) {
            var p = para.trim();
            if (p) blocks.push({ kind: 'paragraph', text: p, html: '<p>' + p + '</p>' });
          });
        }
      }

      if (!blocks.length && !media.length) {
        throw new Error('未提取到 X 文章内容，页面可能未加载完成');
      }

      var timeEl = doc.querySelector(X_SELECTORS.time);
      var publishTime = (timeEl && timeEl.getAttribute('datetime')) || null;

      var result = {
        title: title,
        author_name: author,
        author_handle: authorHandle,
        publish_time: publishTime,
        original_url: (l && l.href) || '',
        source: 'x',
        source_block_count: blocks.length,
        blocks: blocks,
        media: media,
        warnings: []
      };
      return finalizeUrl(result, doc, loc);
    }
  };

  /* ==================== 注册表 ==================== */

  var ADAPTERS = [WECHAT_ADAPTER, X_ADAPTER];

  function pickAdapter(loc) {
    if (!loc) return null;
    var h = hostOf(loc);
    for (var i = 0; i < ADAPTERS.length; i++) {
      if (ADAPTERS[i].host === h) return ADAPTERS[i];
    }
    // twitter.com 与 x.com 同一适配器
    if (h === 'twitter.com') return X_ADAPTER;
    return null;
  }

  function probeAll(doc, loc) {
    return ADAPTERS.map(function (a) {
      return { id: a.id, probe: a.probe(doc, loc) };
    });
  }

  var api = {
    WECHAT_ADAPTER: WECHAT_ADAPTER,
    X_ADAPTER: X_ADAPTER,
    ADAPTERS: ADAPTERS,
    pickAdapter: pickAdapter,
    probeAll: probeAll,
    // 纯助手（单测入口）
    toWallClock: toWallClock,
    parseCnTime: parseCnTime,
    ctStampFromScripts: ctStampFromScripts,
    matchXPath: matchXPath,
    isWechatMediaUrl: isWechatMediaUrl,
    normalizeSrc: normalizeSrc,
    parseWechatVideoConfig: parseWechatVideoConfig,
    normalizeMpvideoUrl: normalizeMpvideoUrl,
    vidFromPlayerSrc: vidFromPlayerSrc,
    finalizeUrl: finalizeUrl
  };

  root.WxdocAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
