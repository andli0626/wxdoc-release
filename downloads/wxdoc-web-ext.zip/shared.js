/**
 * shared.js — 微文存阅浏览器扩展共享内核（WxdocShared UMD）
 *
 * 设计约束（方案 §5.1）：
 *  - 纯函数优先：本模块不触碰 chrome.* / DOM，除 getSettings/saveSettings/notify 三个
 *    需要存储与通知的入口外，全部可在 Node 中以 require() 直接单测（tests/shared.test.js）。
 *  - 常量与默认值收口在此：background / options / popup / content 一律经本模块读取，
 *    避免三处各写一份默认值导致「弹窗显示旧端口、设置页显示新端口」之类的漂移。
 *  - 旧地址迁移（16688/16689 → 16699）历史上在 options.js、background.js、popup.js 三处
 *    各有一份且口径不一，本模块以 migrateServerUrl 统一收口（方案 §5.10）。
 */
(function (root) {
  'use strict';

  /* ---------- 常量 ---------- */
  var DESKTOP_BASE_URL = 'http://127.0.0.1:17321'; // 桌面桥基址（与 wxdoc-desk 监听端口一致）
  var DIR_IMAGES = 'images';
  var DIR_VIDEOS = 'videos';
  var DEFAULT_SAVE_LOCATION = '微文存阅导出';
  var DEFAULT_DIR_TEMPLATE = '{title}_{ts}';
  var DEVICE_NAME = 'browser-extension'; // §4.2 推送信封 deviceName 固定值
  var MAX_TITLE_LEN = 60; // 目录名标题截断（与桌面端 dirPath 口径一致）
  var MAX_SAVE_LOCATION_LEN = 60;
  var ILLEGAL_CHARS = /[\\/:*?"<>|\u0000-\u001f]/g;

  // 旧内网后端地址迁移表：mac-epoint 换机（172.20.246.65 → 172.20.244.219），旧地址统一校正为当前默认地址
  var LEGACY_SERVER_URLS = {
    'http://172.20.246.65:16688': 'http://172.20.239.21:16688',
    'http://172.20.246.65:16689': 'http://172.20.239.21:16688',
    'http://172.20.246.65:16699': 'http://172.20.239.21:16688'
  };
  // 唯一迁移口径：trim + 去尾斜杠 + 忽略大小写查表；非表内值原样返回
  function migrateServerUrl(url) {
    var raw = String(url == null ? '' : url);
    var key = raw.replace(/\/+$/, '').toLowerCase();
    return LEGACY_SERVER_URLS[key] || raw;
  }

  /* ---------- 设置（与 background SETTINGS_DEFAULTS 双锁，tests/options.test.js 防漂移） ---------- */
  var SETTINGS_DEFAULTS = {
    // —— 同步通道（v2.0.0）：auto 按「后端→桌面→下载」择优；download 仅兜底，不设锁定项
    mode: 'auto', // auto | backend | desktop
    baseUrl: DESKTOP_BASE_URL, // 桌面桥基址
    token: '', // 桌面桥令牌
    serverUrl: '', // 后端基址（默认空：未部署后端时 auto 走桌面/下载）
    apiToken: '', // 后端同步令牌
    deviceId: '', // 首次推送时生成并持久化
    // —— 导出行为（download 链生效；其余通道复用同名语义）
    saveLocation: DEFAULT_SAVE_LOCATION,
    dirNameTemplate: DEFAULT_DIR_TEMPLATE,
    duplicatePolicy: 'overwrite', // overwrite | new
    zipPack: false, // 预留（disabled）
    fetchExternalImages: true,
    confirmBeforeExport: true,
    askEveryTime: false,
    notifyOnDone: true,
    showFloatingButton: true,
    autoSave: false // 默认关：避免未预期地自动推送/落盘
  };

  function hasChrome() {
    return typeof chrome !== 'undefined' && !!chrome.storage && !!chrome.storage.local;
  }

  function getSettings() {
    if (!hasChrome()) return Promise.resolve(Object.assign({}, SETTINGS_DEFAULTS));
    return Promise.resolve(chrome.storage.local.get(SETTINGS_DEFAULTS)).then(function (stored) {
      var s = Object.assign({}, SETTINGS_DEFAULTS, stored);
      // 历史值迁移：v1 的 'direct'（直连服务端）即 v2 的 'backend'
      if (s.mode === 'direct') s.mode = 'backend';
      if (s.mode !== 'auto' && s.mode !== 'backend' && s.mode !== 'desktop') s.mode = 'auto';
      // 旧地址迁移：读时即校正并回写，保证弹窗与设置页口径一致
      var migrated = migrateServerUrl(s.serverUrl);
      if (migrated !== s.serverUrl) {
        s.serverUrl = migrated;
        chrome.storage.local.set({ serverUrl: migrated });
      }
      return s;
    });
  }

  function saveSettings(patch) {
    if (!hasChrome()) return Promise.resolve();
    return Promise.resolve(chrome.storage.local.set(patch || {}));
  }

  /* ---------- URL ---------- */
  // 入口只认微信公众号：X/Twitter 站点不再作为支持来源（提取模块仍保留在 adapter.js，但不接入任何入口）
  var WECHAT_HOSTS = ['mp.weixin.qq.com'];
  // 微信长链仅保留四要素（契约与桌面端 task_manager.rs keep=["__biz","mid","idx","sn"] 一致）
  var WECHAT_KEEP_QUERY = ['__biz', 'mid', 'idx', 'sn'];

  function parseUrl(raw) {
    try {
      return new URL(String(raw == null ? '' : raw).trim());
    } catch (e) {
      return null;
    }
  }

  // host 归一化：小写、去端口、去前导 www（仅用于来源判定，不改写 URL 本身）
  function normalizeHost(host) {
    return String(host || '').toLowerCase().replace(/:\d+$/, '').replace(/^www\./, '');
  }

  function pickSource(host) {
    var h = normalizeHost(host);
    if (WECHAT_HOSTS.indexOf(h) !== -1) return 'wechat';
    return '';
  }

  function isSupportedUrl(raw) {
    var u = parseUrl(raw);
    return !!u && !!pickSource(u.hostname);
  }

  // 原样保留查询参数的键值串（不做编解码往返，保证同一 URL 归一化结果稳定，dedupKey 才可靠）
  function filterQueryKeepRaw(query, keep) {
    var q = String(query || '').replace(/^\?/, '');
    if (!q) return '';
    var kept = [];
    q.split('&').forEach(function (pair) {
      if (!pair) return;
      var eq = pair.indexOf('=');
      var k = eq === -1 ? pair : pair.slice(0, eq);
      var v = eq === -1 ? null : pair.slice(eq + 1);
      if (v != null && keep.indexOf(k) !== -1) kept.push(k + '=' + v);
    });
    return kept.join('&');
  }

  function stripTrailingSlash(path) {
    return path.replace(/\/+$/, '') || '/';
  }

  /**
   * 文章 URL 归一化（方案 §4.4，契约与桌面端一致）：
   *  - 微信：强制 mp.weixin.qq.com + https；短链 /s/<slug> 原样保留（去尾斜杠、去跟踪参数）；
   *    长链 /s?__biz=... 仅保留 __biz/mid/idx/sn；去 fragment。
   *  - 其他站点（含 X）：扩展不再支持，原样返回 trim 后的输入（不猜语义）。
   */
  function normalizeArticleUrl(raw) {
    var u = parseUrl(raw);
    if (!u) return String(raw == null ? '' : raw).trim();
    var source = pickSource(u.hostname);
    if (source === 'wechat') {
      var out = new URL(u.href);
      out.protocol = 'https:';
      out.host = 'mp.weixin.qq.com';
      out.pathname = stripTrailingSlash(out.pathname);
      var q = filterQueryKeepRaw(out.search, WECHAT_KEEP_QUERY);
      out.search = q ? '?' + q : '';
      out.hash = '';
      return out.toString();
    }
    return String(raw == null ? '' : raw).trim();
  }

  /* ---------- 路径 / 文件名 ---------- */
  function sanitizeTitle(title, max) {
    max = max || MAX_TITLE_LEN;
    var cleaned = String(title || '')
      .replace(/\s+/g, ' ').trim()
      .replace(ILLEGAL_CHARS, '_');
    return (cleaned.length > max ? cleaned.slice(0, max) : cleaned) || '未命名文章';
  }

  function sanitizeFilename(name) {
    return String(name == null ? '' : name)
      .replace(ILLEGAL_CHARS, '_').trim() || '未命名文件';
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function formatTs(d) {
    return '' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) +
      '_' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  }

  // 目录名渲染：{title}_{ts}；函数形式替换避免标题中的 $& / $' 被当作替换模式
  function renderDirName(template, meta) {
    meta = meta || {};
    var title = sanitizeTitle(meta.title);
    var ts = meta.ts instanceof Date ? meta.ts : new Date(meta.ts == null ? Date.now() : meta.ts);
    return (template || DEFAULT_DIR_TEMPLATE)
      .replace(/\{title\}/g, function () { return title; })
      .replace(/\{ts\}/g, function () { return formatTs(ts); });
  }

  function dedupeDir(base, usedDirs) {
    usedDirs = usedDirs || [];
    var cand = base, i = 1;
    while (usedDirs.indexOf(cand) !== -1) { cand = base + '_' + i; i += 1; }
    return cand;
  }

  // 保存位置校验（仅 download 链生效）：空→默认；>60 字符/绝对路径/盘符/空段/. /.. /非法字符→拒绝
  function validateSaveLocation(v) {
    var s = String(v == null ? '' : v).trim().replace(/\\/g, '/');
    if (!s) return { ok: true, value: DEFAULT_SAVE_LOCATION };
    if (s.length > MAX_SAVE_LOCATION_LEN) return { ok: false, error: '路径过长（≤' + MAX_SAVE_LOCATION_LEN + ' 字符）' };
    if (/^[A-Za-z]:/.test(s) || s.charAt(0) === '/') return { ok: false, error: '仅支持下载目录内的相对子目录，不支持绝对路径/盘符' };
    var segs = s.replace(/\/+$/g, '').split('/');
    for (var i = 0; i < segs.length; i++) {
      if (!segs[i] || segs[i] === '.') return { ok: false, error: '路径包含空段或 . 段' };
      if (segs[i] === '..') return { ok: false, error: '不允许 .. 上级路径' };
      if (/[<>:"|?*]/.test(segs[i])) return { ok: false, error: '包含非法字符 < > : " | ? *' };
    }
    return { ok: true, value: segs.join('/') || DEFAULT_SAVE_LOCATION };
  }

  // 下载相对路径的唯一安全收口：先校验存储值（非法回落默认），再丢弃空段
  function downloadPath(saveLocation, jobDir, sub, name) {
    var loc = validateSaveLocation(saveLocation);
    return [loc.ok ? loc.value : DEFAULT_SAVE_LOCATION, jobDir, sub, name]
      .filter(function (seg) { return seg !== '' && seg != null; }).join('/');
  }

  function dirForKind(kind) {
    return kind === 'video' ? DIR_VIDEOS : DIR_IMAGES;
  }

  /* ---------- 媒体文件名 / 扩展名推断（迁自 background.js） ---------- */
  function extFromUrl(url) {
    var m = /\/([^/?#]+)\.(jpe?g|png|webp|gif|bmp|mp4|m4v)([?#]|$)/i.exec(url || '');
    return m ? m[2].toLowerCase().replace('jpeg', 'jpg') : '';
  }
  function extFromMime(mime) {
    var m = /image\/(jpeg|png|webp|gif|bmp)|video\/(mp4|x-m4v|webm)/.exec(mime || '');
    return m ? (m[1] || m[2] || '').replace('jpeg', 'jpg').replace('x-m4v', 'm4v') : 'bin';
  }
  /**
   * 媒体落盘/上传文件名。media 为 v2 媒体项（{kind:'image'|'video', url}，兼容旧字段 media_type）。
   * JPEG 压缩产物（blob.type 为 image/jpeg）必须落 .jpg：否则 JPEG 字节被存成 .png/.gif，
   * 服务端按扩展名判类型会出错（与桌面端导出口径一致）。
   */
  function filenameFor(media, idx, blob) {
    var kind = (media && (media.kind || media.media_type)) || 'image';
    var mime = (blob && blob.type) || '';
    var mimeExt = extFromMime(mime);
    var ext = /^image\/jpe?g$/i.test(mime)
      ? 'jpg'
      : (extFromUrl(media && media.url) || (mimeExt === 'bin' ? '' : mimeExt) || 'img');
    return (kind === 'video' ? 'video' : 'image') + '_' + idx + '.' + ext;
  }

  /* ---------- 工具 ---------- */
  function toHex(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += (bytes[i] < 16 ? '0' : '') + bytes[i].toString(16);
    return s;
  }
  function sha256Hex(text) {
    var bytes = new TextEncoder().encode(String(text == null ? '' : text));
    var subtle = (typeof crypto !== 'undefined' && crypto.subtle)
      ? crypto.subtle
      : (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle);
    if (!subtle) return Promise.reject(new Error('当前环境不支持 crypto.subtle，无法计算文章 ID'));
    return Promise.resolve(subtle.digest('SHA-256', bytes)).then(function (buf) {
      return toHex(new Uint8Array(buf));
    });
  }

  // blob → dataURL（md/json 文本落盘用）。FileReader 优先；Node（测试）环境兜底手拼 base64。
  function blobToDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      if (!blob) { reject(new Error('blob 为空')); return; }
      if (typeof FileReader !== 'undefined') {
        var fr = new FileReader();
        fr.onload = function () { resolve(String(fr.result)); };
        fr.onerror = function () { reject(new Error('读取 blob 失败')); };
        fr.readAsDataURL(blob);
        return;
      }
      Promise.resolve(blob.arrayBuffer()).then(function (buf) {
        var bytes = new Uint8Array(buf), bin = '';
        for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
        resolve('data:' + (blob.type || 'application/octet-stream') + ';base64,' + btoa(bin));
      }).catch(reject);
    });
  }

  function newDeviceId() {
    var c = (typeof crypto !== 'undefined' && crypto) || (typeof globalThis !== 'undefined' && globalThis.crypto) || null;
    if (c && typeof c.randomUUID === 'function') return c.randomUUID();
    var bytes = new Uint8Array(16);
    if (c && typeof c.getRandomValues === 'function') c.getRandomValues(bytes);
    return 'ext-' + toHex(bytes);
  }

  // 统一中文错误包装：优先按 code 归一化，其余透出 message（sync-channel 抛出的 message 已是中文）
  function friendlyError(e) {
    if (!e) return '未知错误';
    var code = e.code || '';
    if (code === 'unauthorized') return '认证失败：Token 无效或已过期';
    return e.message || '未知错误';
  }

  // 完成通知，受 notifyOnDone 开关控制（方案 §5.8/§5.10）
  function notify(title, message) {
    if (typeof chrome === 'undefined' || !chrome.notifications) return Promise.resolve();
    return getSettings().then(function (s) {
      if (!s.notifyOnDone) return;
      return chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: String(title || '微文存阅'),
        message: String(message || '')
      });
    }).catch(function () { /* 通知失败不影响主流程 */ });
  }

  /* ---------- 后端地址归一化（options 与 background 共用一个口径） ---------- */
  function normalizeEndpoint(v) {
    var s = String(v == null ? '' : v).trim();
    if (!s) return { ok: true, value: '', pattern: '' };
    var u = parseUrl(s);
    if (!u) return { ok: false, error: '后端地址格式无效：' + s };
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return { ok: false, error: '后端地址仅支持 http/https' };
    return { ok: true, value: u.origin, pattern: u.origin + '/*' };
  }

  var api = {
    // 常量
    DESKTOP_BASE_URL: DESKTOP_BASE_URL,
    DIR_IMAGES: DIR_IMAGES,
    DIR_VIDEOS: DIR_VIDEOS,
    DEFAULT_SAVE_LOCATION: DEFAULT_SAVE_LOCATION,
    DEFAULT_DIR_TEMPLATE: DEFAULT_DIR_TEMPLATE,
    DEVICE_NAME: DEVICE_NAME,
    MAX_TITLE_LEN: MAX_TITLE_LEN,
    SETTINGS_DEFAULTS: SETTINGS_DEFAULTS,
    // 设置
    getSettings: getSettings,
    saveSettings: saveSettings,
    migrateServerUrl: migrateServerUrl,
    normalizeEndpoint: normalizeEndpoint,
    // URL
    parseUrl: parseUrl,
    pickSource: pickSource,
    isSupportedUrl: isSupportedUrl,
    normalizeArticleUrl: normalizeArticleUrl,
    // 路径 / 文件名
    sanitizeTitle: sanitizeTitle,
    sanitizeFilename: sanitizeFilename,
    formatTs: formatTs,
    renderDirName: renderDirName,
    dedupeDir: dedupeDir,
    validateSaveLocation: validateSaveLocation,
    downloadPath: downloadPath,
    dirForKind: dirForKind,
    // 媒体
    extFromUrl: extFromUrl,
    extFromMime: extFromMime,
    filenameFor: filenameFor,
    // 工具
    sha256Hex: sha256Hex,
    blobToDataUrl: blobToDataUrl,
    newDeviceId: newDeviceId,
    friendlyError: friendlyError,
    notify: notify
  };
  root.WxdocShared = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
